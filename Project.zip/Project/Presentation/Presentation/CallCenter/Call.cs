﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class LeaveApplications : Form
    {
        public LeaveApplications()
        {
            InitializeComponent();
            
            
        }

        public static bool applied = false;

        string fname = frmMain.loggedInFname;
        string lname = frmMain.loggedInLName;
        public static int id = frmMain.loggedInID;
        Socketwrapper soc;

        public frmMain main;


        //For animated panels direction
        string rightDirection = "right";

        //For animated panels timeout
        int RightTimeOut = 0;

        //For animated panels position
        int rightX;
        int rightY;

        //method to set fullscreen
        private void setFullScreen()
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            Location = new Point(0, 0);
            Size = new Size(x, y);
        }

        //method to set the position of the main panel that holds the controls to center of the form.
        private void setMainPanelPosition()
        {
            int mX = (Width - pnlMain.Width) / 2;
            int mY = (Height - pnlMain.Height) / 2;
            pnlMain.Location = new Point(mX, mY);
        }


        private void setRightOptionsPanelPosition()
        {
            int y = Height;
            rightY = 0;
            rightX = Width + pnlRightOptions.Width;
            pnlRightOptions.Size = new Size(pnlRightOptions.Width, y);
            pnlRightOptions.Location = new Point(rightX, rightY);
            int rX = pnlRightMain.Location.X;
            int rY = (pnlRightOptions.Height - pnlRightMain.Height) / 2;
            pnlRightMain.Location = new Point(rX, rY);
        }

        private void RightOptions_Tick(object sender, EventArgs e)
        {
            if (RightTimeOut < 1000)
            {
                RightTimeOut++;
            }
            if (RightTimeOut == 1000)
            {
                if (rightDirection == "left")
                {
                    rightDirection = "right";
                }
            }
            if (rightDirection == "left")
            {
                if (rightX > Width - pnlRightOptions.Width)
                {
                    rightX -= 2;
                    pnlRightOptions.Location = new Point(rightX, rightY);
                }
            }
            else
            {
                if (rightX < Width)
                {
                    rightX += 2;
                }
                pnlRightOptions.Location = new Point(rightX, rightY);
            }
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            soc.Disconnect();
            Application.Exit();
        }

        private void pbHome_Click(object sender, EventArgs e)
        {
            soc.Disconnect();
            main.Show();
            this.Close();
        }

        private void LeaveApplications_Load_1(object sender, EventArgs e)
        {
            setFullScreen();
            setRightOptionsPanelPosition();
            setMainPanelPosition();
            RightOptions.Start();

            ApplytxtFName.Text = frmMain.loggedInFname;
            ApplytxtLName.Text = frmMain.loggedInLName;
            soc = new Socketwrapper();
            
            
        }

        private void LeaveApplications_MouseMove_1(object sender, MouseEventArgs e)
        {
            if (e.Y >= Height - 15 && e.X < (Width - pnlRightOptions.Width))
            {
                rightDirection = "right";
            }
            if (e.X >= Width - 15)
            {
                rightDirection = "left";
                RightTimeOut = 0;
            }
            if (e.X < (Width - pnlRightOptions.Width))
            {
                rightDirection = "Left";
            }
        }

        private void ApplybtnApply_Click(object sender, EventArgs e)
        {
            if (ApplytxtFName.Text == "" || ApplytxtLName.Text == "" || ApplycmbReason.Text == "")
            {
                MessageBox.Show("Please Fill in all the details before applying");
            }
            else
            {
                if (ApplydtStart.Value.Date == DateTime.Now || ApplydtStart.Value.Date == ApplydtEnd.Value.Date || ApplydtEnd.Value.Date < ApplydtStart.Value.Date)
                {
                    MessageBox.Show("Please Select Appropiate dates for application");
                }
                else
	            {
                DateTime start = ApplydtStart.Value.Date;
                DateTime end = ApplydtEnd.Value.Date;
                try
                {
                    ApplyForLeave ap = new ApplyForLeave(ApplycmbReason.Text.ToString(), "Pending", fname,lname, start, end);
                    byte[] odat = new byte[1000];
                    odat = Serializer.SerializeThis(ap);
                    soc.Send(odat);

                    applied = true;
                    ApplycmbReason.SelectedIndex = -1;
                    MessageBox.Show("Application sent");

                    ApplybtnApply.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
	            }
                
            }
        }
    }
}
