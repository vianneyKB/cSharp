﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BussinessLogic;

namespace Presentation
{
    public partial class Login : Form
    {
        User user;

        public Login()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the login screen, enter username and password and if account is authenticated you will be taken to the appropriate deparment");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtLoginUserName.Text == "" || txtLoginPassword.Text == "")
            {
                MessageBox.Show("Please enter both username and password before attempting to login");
            }
            else
            {
                user = new User(txtLoginUserName.Text, txtLoginPassword.Text);
                user.Validation(user.Username, user.Password);

                if (user.validated = true)
                {

                    User userd = user.ReturnAllUserInfo(user.Username);

                    string department = userd.Department;
                    MessageBox.Show("Login successful");
                    if (department == "Manager")
                    {
                        Users users = new Users();
                        users.Show();
                        this.Hide();
                    }
                    else if (department == "Client Maintencance")
                    {
                        Clients clients = new Clients();
                        clients.Show();
                        this.Hide();
                    }
                    else if (department == "Contract Maintenance")
                    {
                        ContractMaintenaceMain cm = new ContractMaintenaceMain();
                        cm.Show();
                        this.Hide();
                    }
                    else if (department == "Call Centre")
                    {
                        IncomingCall inc = new IncomingCall();
                        inc.Show();
                        this.Hide();
                    }
                    else if (department == "Client Maintenance")
                    {
                        Clients cl = new Clients();
                        cl.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Login unsuccessful");
                }
            }
        }
    }
}
