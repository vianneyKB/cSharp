﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BussinessLogic;

namespace Presentation
{
    public partial class Clients : Form
    {
        IndividualClient individualclient;
        BusinessClient busclient;
        Contract contract;
        Package package;
        BusinessClient businessclient;

        DataTable ListOfIndividualClients;
        DataTable ListOfBusinessClients;
        DataTable ListOfPackages;

        public Clients()
        {
            InitializeComponent();
            ClientsTabControl.DrawItem += new DrawItemEventHandler(ClientsTabControl_DrawItem);

            individualclient = new IndividualClient();
            package = new Package();
            businessclient = new BusinessClient();
            ListOfPackages = package.GetListOPackages();
            ListOfIndividualClients = individualclient.GetListOfclients();
            ListOfBusinessClients = businessclient.GetListOfBusinessclients();

            IndcmbPackage.DataSource = ListOfPackages;
            IndcmbPackage.DisplayMember = "PackageName";
            indcmbClient.DataSource = ListOfIndividualClients;
            indcmbClient.DisplayMember = "ClientName";
            BusClientcmbBusinesses.DataSource = ListOfBusinessClients;
            BusClientcmbBusinesses.DisplayMember = "CompanyName";
            BusClientcmbPackage.DataSource = ListOfPackages;
            BusClientcmbPackage.DisplayMember = "PackageName";

        }

        private void ClientsTabControl_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = ClientsTabControl.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = ClientsTabControl.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {
                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Aqua);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", (float)10.0, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void ClientsbtnLogout_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void ClientsClose1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void ClientClose2_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void ClientsbtnLogout2_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void ClientsHelp1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the edit individual client page. Select a client from the dropdown then all their information  will appear in the form underneath which you can useto edit the client's details then save. At the bottom is the option to save changes or delete the client");
        }

        private void ClientsHelp2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the edit business client page. Select a client from the dropdown then all their information  will appear in the form underneath which you can use to edit the client's details then save. At the bottom is the option to save changes or delete the client");
        }

        //****************************************INDIVIDUAL CLIENT**************************************************
        //insert client
        private void IndbtnComplete_Click(object sender, EventArgs e)
        {
            if (IndcmbContractLevel.Text == "" || IndsClientFaxNumber.Text == "" || IndClientEmail.Text == "" || IndClientPhoneNumber.Text == "" || IndClientTelNumber.Text == "" || IndClientCountry.Text == "" || IndClientPosyalCode.Text == "" || IndCity.Text == "" || IndStreetName.Text == "" || IndClientLatName.Text == "" || IndFirstName.Text == "" || IndcmbPackage.Text == "" || IndBuildingNumber.Text == "" || IndProvince.Text == "" || IndStatus.Text == "" || IndCity.Text == "")
            {
                MessageBox.Show("Please fill in all fields before attempting to add client");
            }
            else
            {
                individualclient = new IndividualClient();
                contract = new Contract();

                string ex = individualclient.Existence(IndFirstName.Text, IndClientLatName.Text);

                if (ex == "true")
                {
                    MessageBox.Show("This client already exists");
                }
                else
                {
                    MessageBox.Show(individualclient.InsertClient(IndFirstName.Text, IndClientLatName.Text, IndClientDOB.Value, IndStatus.Text, IndClientPhoneNumber.Text,IndClientEmail.Text, IndsClientFaxNumber.Text, IndClientTelNumber.Text, IndStreetName.Text, IndCity.Text, IndProvince.Text, IndClientPosyalCode.Text, IndClientCountry.Text, IndBuildingNumber.Text));

                    MessageBox.Show(contract.InsertContract(IndcmbContractLevel.Text, IndcmbPackage.Text, IndcmbContractStartDate.Value, IndcmbContractEndDate.Value, IndFirstName.Text, IndClientLatName.Text));

                    //hide group boxes and buttons
                    indgbdetails.Visible = false;
                    IndContractGB.Visible = false;
                    IndbtnCancel.Visible = false;
                    IndbtnComplete.Visible = false;

                    //show controls
                    indcmbClient.Visible = true;
                    indbtnAddclient.Visible = true;
                    indbtnEditClient.Visible = true;
                    indlblclientname.Visible = true;
                    

                    //refresh list of individual clients
                    individualclient = new IndividualClient();
                    package = new Package();
                    ListOfPackages = package.GetListOPackages();
                    ListOfIndividualClients = individualclient.GetListOfclients();
                    indcmbClient.DataSource = ListOfIndividualClients;
                    indcmbClient.DisplayMember = "ClientName";
                    
                }
            }
        }
        
        //Add an individual client
        private void incbtnAddclient_Click(object sender, EventArgs e)
        {
            //empty fields
            IndcmbContractLevel.Text = "";
            IndsClientFaxNumber.Text = "";
            IndClientEmail.Text = "";
            IndClientPhoneNumber.Text = "";
            IndClientTelNumber.Text = "";
            IndClientCountry.Text = "";
            IndClientPosyalCode.Text = "";
            IndCity.Text = "";
            IndStreetName.Text = "";
            IndClientLatName.Text = "";
            IndFirstName.Text = "";
            IndcmbPackage.Text = "";
            IndBuildingNumber.Text = "";
            IndProvince.Text = "";
            IndStatus.Text = "";
            IndCity.Text = "";
        
            //Hide controls
            indcmbClient.Visible = false;
            indbtnAddclient.Visible = false;
            indbtnEditClient.Visible = false;
            indlblclientname.Visible = false;

            //show group boxes and buttons
            indgbdetails.Visible = true;
            IndContractGB.Visible = true;
            IndbtnCancel.Visible = true;
            IndbtnComplete.Visible = true;
        }
        
        //Cancel button
        private void IndbtnCancel_Click(object sender, EventArgs e)
        {
            //hide group boxes and buttons
            indgbdetails.Visible = false;
            IndContractGB.Visible = false;
            IndbtnCancel.Visible = false;
            IndbtnComplete.Visible = false;

            //show controls
            indcmbClient.Visible = true;
            indbtnAddclient.Visible = true;
            indbtnEditClient.Visible = true;
            indlblclientname.Visible = true;
        }

        //Edit individual client
        private void indbtnEditClient_Click(object sender, EventArgs e)
        {
            if (indcmbClient.Text == "")
            {
                MessageBox.Show("Please select a client to edit");
            }
            else
            {
                individualclient = new IndividualClient();
                contract = new Contract();

                string[] fullname = indcmbClient.Text.Split(' ');
                string firstname = fullname[0];
                string lastname = fullname[1];

                IndividualClient ind = individualclient.ReturnAllclientInfo(firstname, lastname);
                Contract cont = contract.ReturnAllContratInfo(firstname, lastname);

                //populate fields
                IndFirstName.Text = ind.Name;
                IndClientLatName.Text = ind.Name;
                IndcmbContractLevel.Text = cont.ContractLevel;
                IndcmbPackage.Text = cont.Package;
                IndsClientFaxNumber.Text = ind.Faxnumber;
                IndClientEmail.Text = ind.Email;
                IndClientPhoneNumber.Text = ind.Phonenumber;
                IndClientTelNumber.Text = ind.Telnumber;
                IndClientCountry.Text = ind.Country;
                IndClientPosyalCode.Text = ind.Postalcode;
                IndCity.Text = ind.City;
                IndStreetName.Text = ind.Streetname;
                IndClientLatName.Text = ind.Surname;
                IndFirstName.Text = ind.Name;
                IndBuildingNumber.Text = ind.Buildingnumber;
                IndProvince.Text = ind.Province;
                IndStatus.Text = ind.Status;
                IndCity.Text = ind.City;

                //Hide controls
                indcmbClient.Visible = false;
                indbtnAddclient.Visible = false;
                indbtnEditClient.Visible = false;
                indlblclientname.Visible = false;

                //show group boxes and buttons
                indgbdetails.Visible = true;
                IndContractGB.Visible = true;
                IndbtnDelete.Visible = true;
                IndbtnUpdate.Visible = true;
            }
        }


        private void IndbtnUpdate_Click(object sender, EventArgs e)
        {
            if (IndcmbContractLevel.Text == "" || IndsClientFaxNumber.Text == "" || IndClientEmail.Text == "" || IndClientPhoneNumber.Text == "" || IndClientTelNumber.Text == "" || IndClientCountry.Text == "" || IndClientPosyalCode.Text == "" || IndCity.Text == "" || IndStreetName.Text == "" || IndClientLatName.Text == "" || IndFirstName.Text == "" || IndcmbPackage.Text == "" || IndBuildingNumber.Text == "" || IndProvince.Text == "" || IndStatus.Text == "" || IndCity.Text == "")
            {
                MessageBox.Show("Please fill in all fields before attempting to add client");
            }
            else
            {
                IndFirstName.Enabled = true;
                IndClientLatName.Enabled = true;

                individualclient = new IndividualClient();
                contract = new Contract();

                MessageBox.Show(individualclient.UpdateIndividualClient(IndFirstName.Text, IndClientLatName.Text, IndClientDOB.Value, IndStatus.Text, IndClientPhoneNumber.Text, IndClientEmail.Text, IndsClientFaxNumber.Text, IndClientTelNumber.Text, IndStreetName.Text, IndCity.Text, IndProvince.Text, IndClientPosyalCode.Text, IndClientCountry.Text, IndBuildingNumber.Text));

                MessageBox.Show(contract.UpdateContract(IndcmbContractLevel.Text, IndcmbPackage.Text, IndcmbContractStartDate.Value, IndcmbContractEndDate.Value, IndFirstName.Text, IndClientLatName.Text));

                    //hide group boxes and buttons
                    indgbdetails.Visible = false;
                    IndContractGB.Visible = false;
                    IndbtnCancel.Visible = false;
                    IndbtnComplete.Visible = false;

                    //show controls
                    indcmbClient.Visible = true;
                    indbtnAddclient.Visible = true;
                    indbtnEditClient.Visible = true;
                    indlblclientname.Visible = true;


                    //refresh list of individual clients
                    indcmbClient.DataSource = ListOfIndividualClients;
                    indcmbClient.DisplayMember = "ClientName";

            }
        }

        private void IndbtnDelete_Click(object sender, EventArgs e)
        {

                 MessageBox.Show(contract.DeleteContract(IndFirstName.Text, IndClientLatName.Text));
                MessageBox.Show(individualclient.DeleteIndividualClient(IndFirstName.Text, IndClientLatName.Text));


                //hide group boxes and buttons
                indgbdetails.Visible = false;
                IndContractGB.Visible = false;
                IndbtnCancel.Visible = false;
                IndbtnComplete.Visible = false;

                //show controls
                indcmbClient.Visible = true;
                indbtnAddclient.Visible = true;
                indbtnEditClient.Visible = true;
                indlblclientname.Visible = true;


                //refresh list of individual clients
                individualclient = new IndividualClient();
                package = new Package();
                ListOfPackages = package.GetListOPackages();
                ListOfIndividualClients = individualclient.GetListOfclients();
                indcmbClient.DataSource = ListOfIndividualClients;
                indcmbClient.DisplayMember = "ClientName";

            }
        //**********************************************BUSINESS CLIENTS*************************************************************
        private void BusClientbtnaddclient_Click(object sender, EventArgs e)
        {
            //Hide controls
            BusClientlblbusinesses.Visible = false;
            BusClientcmbBusinesses.Visible = false;
            BusClientbtneditbusiness.Visible = false;
            BusClientbtnaddclient.Visible = false;

            //Empty fields
            BusClientSuperVisorNumber.Text = "";
            BusClientSupervisor.Text = "";
            BusClientManagerNumber.Text = "";
            BusClienttextManage.Text = "";
            BusClientFaxNumber.Text = "";
            BusClientEmail.Text = "";
            BusClientPhoneNumber.Text = "";
            BusClientTelNumber.Text = "";
            BusClientCountry.Text = "";
            BusClientPosyalCode.Text = "";
            BusClientCity.Text = "";
            BusClientStreetName.Text = "";
            BusClientCompany.Text = "";
            BusClientProvince.Text = "";
            BusClientbuildingnumber.Text = "";

            //Show controls
            BusClientSaveClient.Visible = true;
            BusClientgbcontract.Visible = true;
            BusClientgbdetails.Visible = true;
            BusClientbtncance.Visible = true;
         
         
        }

        private void ClientsTabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Hide controls
            BusClientlblbusinesses.Visible = true;
            BusClientcmbBusinesses.Visible = true;
            BusClientbtneditbusiness.Visible = true;
            BusClientbtnaddclient.Visible = true;

            //Empty fields
            BusClientSuperVisorNumber.Text = "";
            BusClientSupervisor.Text = "";
            BusClientManagerNumber.Text = "";
            BusClienttextManage.Text = "";
            BusClientFaxNumber.Text = "";
            BusClientEmail.Text = "";
            BusClientPhoneNumber.Text = "";
            BusClientTelNumber.Text = "";
            BusClientCountry.Text = "";
            BusClientPosyalCode.Text = "";
            BusClientCity.Text = "";
            BusClientStreetName.Text = "";
            BusClientCompany.Text = "";
            BusClientProvince.Text = "";
            BusClientbuildingnumber.Text = "";

            //Show controls
            BusClientSaveClient.Visible = false;
            BusClientgbcontract.Visible = false;
            BusClientgbdetails.Visible = false;
            BusClientbtncance.Visible = false;

            //empty fields
            IndcmbContractLevel.Text = "";
            IndsClientFaxNumber.Text = "";
            IndClientEmail.Text = "";
            IndClientPhoneNumber.Text = "";
            IndClientTelNumber.Text = "";
            IndClientCountry.Text = "";
            IndClientPosyalCode.Text = "";
            IndCity.Text = "";
            IndStreetName.Text = "";
            IndClientLatName.Text = "";
            IndFirstName.Text = "";
            IndcmbPackage.Text = "";
            IndBuildingNumber.Text = "";
            IndProvince.Text = "";
            IndStatus.Text = "";
            IndCity.Text = "";

            //hide group boxes and buttons
            indgbdetails.Visible = false;
            IndContractGB.Visible = false;
            IndbtnCancel.Visible = false;
            IndbtnComplete.Visible = false;

            //show controls
            indcmbClient.Visible = true;
            indbtnAddclient.Visible = true;
            indbtnEditClient.Visible = true;
            indlblclientname.Visible = true;


            //refresh list of individual clients
            indcmbClient.DataSource = ListOfIndividualClients;
            indcmbClient.DisplayMember = "ClientName";
        }

        //Add business client
        private void BusClientSaveClient_Click(object sender, EventArgs e)
        {
   
            if (BusClientSuperVisorNumber.Text == "" || BusClientSupervisor.Text == "" || BusClientManagerNumber.Text == "" || BusClienttextManage.Text == "" || BusClientFaxNumber.Text == "" || BusClientEmail.Text == "" || BusClientPhoneNumber.Text == "" || BusClientTelNumber.Text == "" || BusClientCountry.Text == "" || BusClientPosyalCode.Text == "" || BusClientCity.Text == "" || BusClientStreetName.Text == "" || BusClientCompany.Text == "" || BusClientProvince.Text == "" || BusClientbuildingnumber.Text == "" || BusClientStatus.Text == "" || BusClientcmbContract.Text == "" || BusClientcmbPackage.Text == "" || BusClientCompany.Text =="") 
            {
                MessageBox.Show("Please fill in all fields before attempting to add client");
            }
            else
            {
                busclient = new BusinessClient();
                contract = new Contract();

                string ex = busclient.Existence(BusClientCompany.Text);

                if (ex == "true")
                {
                    MessageBox.Show("This client already exists");
                }
                else
                {
                    MessageBox.Show(busclient.InsertBusinessClient(BusClientCompany.Text,BusClientStatus.Text,BusClienttextManage.Text,BusClientSupervisor.Text,BusClientManagerNumber.Text,BusClientSuperVisorNumber.Text,BusClientPhoneNumber.Text, BusClientEmail.Text, BusClientFaxNumber.Text,BusClientTelNumber.Text, BusClientStreetName.Text,BusClientCity.Text,BusClientProvince.Text,BusClientPosyalCode.Text,BusClientCountry.Text,BusClientbuildingnumber.Text));

                    MessageBox.Show(contract.InsertBusinessContract( BusClientcmbContract.Text, BusClientcmbPackage.Text, BusClientStartDate.Value, BusClientenddate.Value, BusClientCompany.Text));

                    //Hide controls
                    BusClientlblbusinesses.Visible = true;
                    BusClientcmbBusinesses.Visible = true;
                    BusClientbtneditbusiness.Visible = true;
                    BusClientbtnaddclient.Visible = true;

                    //Empty fields
                    BusClientSuperVisorNumber.Text = "";
                    BusClientSupervisor.Text = "";
                    BusClientManagerNumber.Text = "";
                    BusClienttextManage.Text = "";
                    BusClientFaxNumber.Text = "";
                    BusClientEmail.Text = "";
                    BusClientPhoneNumber.Text = "";
                    BusClientTelNumber.Text = "";
                    BusClientCountry.Text = "";
                    BusClientPosyalCode.Text = "";
                    BusClientCity.Text = "";
                    BusClientStreetName.Text = "";
                    BusClientCompany.Text = "";
                    BusClientProvince.Text = "";
                    BusClientbuildingnumber.Text = "";

                    //Show controls
                    BusClientSaveClient.Visible = false;
                    BusClientgbcontract.Visible = false;
                    BusClientgbdetails.Visible = false;
                    BusClientbtncance.Visible = false;

                    //refresh list of business clients
                    ListOfPackages = package.GetListOPackages();
                    ListOfBusinessClients = businessclient.GetListOfBusinessclients();

                    BusClientcmbBusinesses.DataSource = ListOfBusinessClients;
                    BusClientcmbBusinesses.DisplayMember = "CompanyName";
                    BusClientcmbPackage.DataSource = ListOfPackages;
                    BusClientcmbPackage.DisplayMember = "PackageName";

                }
            }
        }

        private void BusClientbtncance_Click(object sender, EventArgs e)
        {
            //Hide controls
            BusClientlblbusinesses.Visible = true;
            BusClientcmbBusinesses.Visible = true;
            BusClientbtneditbusiness.Visible = true;
            BusClientbtnaddclient.Visible = true;

            //Empty fields
            BusClientSuperVisorNumber.Text = "";
            BusClientSupervisor.Text = "";
            BusClientManagerNumber.Text = "";
            BusClienttextManage.Text = "";
            BusClientFaxNumber.Text = "";
            BusClientEmail.Text = "";
            BusClientPhoneNumber.Text = "";
            BusClientTelNumber.Text = "";
            BusClientCountry.Text = "";
            BusClientPosyalCode.Text = "";
            BusClientCity.Text = "";
            BusClientStreetName.Text = "";
            BusClientCompany.Text = "";
            BusClientProvince.Text = "";
            BusClientbuildingnumber.Text = "";

            //Show controls
            BusClientSaveClient.Visible = false;
            BusClientgbcontract.Visible = false;
            BusClientgbdetails.Visible = false;
            BusClientbtncance.Visible = false;
        }

        //Update business client
        private void BusClientUpdate_Click(object sender, EventArgs e)
        {
            if (BusClientSuperVisorNumber.Text == "" || BusClientSupervisor.Text == "" || BusClientManagerNumber.Text == "" || BusClienttextManage.Text == "" || BusClientFaxNumber.Text == "" || BusClientEmail.Text == "" || BusClientPhoneNumber.Text == "" || BusClientTelNumber.Text == "" || BusClientCountry.Text == "" || BusClientPosyalCode.Text == "" || BusClientCity.Text == "" || BusClientStreetName.Text == "" || BusClientCompany.Text == "" || BusClientProvince.Text == "" || BusClientbuildingnumber.Text == "" || BusClientStatus.Text == "" || BusClientcmbContract.Text == "" || BusClientcmbPackage.Text == "" || BusClientCompany.Text =="") 
            {
                MessageBox.Show("Please fill in all fields before attempting to update client");
            }
            else
            {
                busclient = new BusinessClient();
                contract = new Contract();

                MessageBox.Show(busclient.UpdateBusinessClient(BusClientCompany.Text, BusClientStatus.Text, BusClienttextManage.Text, BusClientSupervisor.Text, BusClientManagerNumber.Text, BusClientSuperVisorNumber.Text, BusClientPhoneNumber.Text, BusClientEmail.Text, BusClientFaxNumber.Text, BusClientTelNumber.Text, BusClientStreetName.Text, BusClientCity.Text, BusClientProvince.Text, BusClientPosyalCode.Text, BusClientCountry.Text, BusClientbuildingnumber.Text));

                    MessageBox.Show(contract.UpdateBusinessContract( BusClientcmbContract.Text, BusClientcmbPackage.Text, BusClientStartDate.Value, BusClientenddate.Value, BusClientCompany.Text));

                    //hide group boxes and buttons
                    indgbdetails.Visible = false;
                    IndContractGB.Visible = false;
                    IndbtnCancel.Visible = false;
                    IndbtnComplete.Visible = false;

                    //show controls
                    indcmbClient.Visible = true;
                    indbtnAddclient.Visible = true;
                    indbtnEditClient.Visible = true;
                    indlblclientname.Visible = true;


                    //refresh list of business clients
                    ListOfPackages = package.GetListOPackages();
                    ListOfBusinessClients = businessclient.GetListOfBusinessclients();

                    BusClientcmbBusinesses.DataSource = ListOfBusinessClients;
                    BusClientcmbBusinesses.DisplayMember = "CompanyName";
                    BusClientcmbPackage.DataSource = ListOfPackages;
                    BusClientcmbPackage.DisplayMember = "PackageName";
            }
        }

        //Delete business client
        private void BusClientDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show(contract.UpdateBusinessContract( BusClientcmbContract.Text, BusClientcmbPackage.Text, BusClientStartDate.Value, BusClientenddate.Value, BusClientCompany.Text));
            MessageBox.Show(busclient.DeleteBusinessClient(BusClientCompany.Text));

             

            //hide group boxes and buttons
            indgbdetails.Visible = false;
            IndContractGB.Visible = false;
            IndbtnCancel.Visible = false;
            IndbtnComplete.Visible = false;

            //show controls
            indcmbClient.Visible = true;
            indbtnAddclient.Visible = true;
            indbtnEditClient.Visible = true;
            indlblclientname.Visible = true;


            //refresh list of business clients
            ListOfPackages = package.GetListOPackages();
            ListOfBusinessClients = businessclient.GetListOfBusinessclients();

            BusClientcmbBusinesses.DataSource = ListOfBusinessClients;
            BusClientcmbBusinesses.DisplayMember = "CompanyName";
            BusClientcmbPackage.DataSource = ListOfPackages;
            BusClientcmbPackage.DisplayMember = "PackageName";
        }
        }
}
