﻿namespace Presentation
{
    partial class Clients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {            
            this.pnlTemplate = new System.Windows.Forms.Panel();
            this.ClientsTabControl = new System.Windows.Forms.TabControl();
            this.TbIndividualClients = new System.Windows.Forms.TabPage();
            this.IndbtnCancel = new System.Windows.Forms.Button();
            this.IndbtnUpdate = new System.Windows.Forms.Button();
            this.indbtnAddclient = new System.Windows.Forms.Button();
            this.indbtnEditClient = new System.Windows.Forms.Button();
            this.ClientsbtnLogout = new System.Windows.Forms.Button();
            this.IndbtnDelete = new System.Windows.Forms.Button();
            this.IndContractGB = new System.Windows.Forms.GroupBox();
            this.IndcmbContractEndDate = new System.Windows.Forms.DateTimePicker();
            this.label35 = new System.Windows.Forms.Label();
            this.IndcmbContractStartDate = new System.Windows.Forms.DateTimePicker();
            this.label34 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.IndcmbPackage = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.IndcmbContractLevel = new System.Windows.Forms.ComboBox();
            this.indgbdetails = new System.Windows.Forms.GroupBox();
            this.IndStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.IndProvince = new System.Windows.Forms.TextBox();
            this.UserslblBuidingNumber = new System.Windows.Forms.Label();
            this.IndBuildingNumber = new System.Windows.Forms.TextBox();
            this.UserslbProvince = new System.Windows.Forms.Label();
            this.IndsClientFaxNumber = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.IndClientEmail = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.IndClientPhoneNumber = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.IndClientDOB = new System.Windows.Forms.DateTimePicker();
            this.IndClientTelNumber = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.IndClientCountry = new System.Windows.Forms.TextBox();
            this.IndClientPosyalCode = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.IndCity = new System.Windows.Forms.TextBox();
            this.IndStreetName = new System.Windows.Forms.TextBox();
            this.IndClientLatName = new System.Windows.Forms.TextBox();
            this.IndFirstName = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.IndbtnComplete = new System.Windows.Forms.Button();
            this.indcmbClient = new System.Windows.Forms.ComboBox();
            this.ClientsClose1 = new System.Windows.Forms.PictureBox();
            this.ClientsHelp1 = new System.Windows.Forms.PictureBox();
            this.indlblclientname = new System.Windows.Forms.Label();
            this.TbBusinessClients = new System.Windows.Forms.TabPage();
            this.BusClientDelete = new System.Windows.Forms.Button();
            this.BusClientbtnaddclient = new System.Windows.Forms.Button();
            this.BusClientbtneditbusiness = new System.Windows.Forms.Button();
            this.BusClientUpdate = new System.Windows.Forms.Button();
            this.BusClientcmbBusinesses = new System.Windows.Forms.ComboBox();
            this.BusClientlblbusinesses = new System.Windows.Forms.Label();
            this.ClientsbtnLogout2 = new System.Windows.Forms.Button();
            this.BusClientbtncance = new System.Windows.Forms.Button();
            this.BusClientgbdetails = new System.Windows.Forms.GroupBox();
            this.BusClientStatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BusClientProvince = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BusClientbuildingnumber = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.BusClientSuperVisorNumber = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.BusClientSupervisor = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.BusClientManagerNumber = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.BusClienttextManage = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.BusClientFaxNumber = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.BusClientEmail = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.BusClientPhoneNumber = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.BusClientTelNumber = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.BusClientCountry = new System.Windows.Forms.TextBox();
            this.BusClientPosyalCode = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.BusClientCity = new System.Windows.Forms.TextBox();
            this.BusClientStreetName = new System.Windows.Forms.TextBox();
            this.BusClientCompany = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.BusClientgbcontract = new System.Windows.Forms.GroupBox();
            this.BusClientenddate = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.BusClientStartDate = new System.Windows.Forms.DateTimePicker();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.BusClientcmbPackage = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.BusClientcmbContract = new System.Windows.Forms.ComboBox();
            this.BusClientSaveClient = new System.Windows.Forms.Button();
            this.ClientClose2 = new System.Windows.Forms.PictureBox();
            this.ClientsHelp2 = new System.Windows.Forms.PictureBox();
            this.pnlTemplate.SuspendLayout();
            this.ClientsTabControl.SuspendLayout();
            this.TbIndividualClients.SuspendLayout();
            this.IndContractGB.SuspendLayout();
            this.indgbdetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClientsClose1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientsHelp1)).BeginInit();
            this.TbBusinessClients.SuspendLayout();
            this.BusClientgbdetails.SuspendLayout();
            this.BusClientgbcontract.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClientClose2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientsHelp2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTemplate
            // 
            this.pnlTemplate.BackColor = System.Drawing.Color.Transparent;
            this.pnlTemplate.Controls.Add(this.ClientsTabControl);
            this.pnlTemplate.Location = new System.Drawing.Point(0, 0);
            this.pnlTemplate.Name = "pnlTemplate";
            this.pnlTemplate.Size = new System.Drawing.Size(1024, 648);
            this.pnlTemplate.TabIndex = 13;
            // 
            // ClientsTabControl
            // 
            this.ClientsTabControl.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.ClientsTabControl.Controls.Add(this.TbIndividualClients);
            this.ClientsTabControl.Controls.Add(this.TbBusinessClients);
            this.ClientsTabControl.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.ClientsTabControl.ItemSize = new System.Drawing.Size(50, 200);
            this.ClientsTabControl.Location = new System.Drawing.Point(0, 2);
            this.ClientsTabControl.Multiline = true;
            this.ClientsTabControl.Name = "ClientsTabControl";
            this.ClientsTabControl.SelectedIndex = 0;
            this.ClientsTabControl.Size = new System.Drawing.Size(1024, 645);
            this.ClientsTabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.ClientsTabControl.TabIndex = 20;
            this.ClientsTabControl.SelectedIndexChanged += new System.EventHandler(this.ClientsTabControl_SelectedIndexChanged);
            // 
            // TbIndividualClients
            // 
            this.TbIndividualClients.Controls.Add(this.IndbtnCancel);
            this.TbIndividualClients.Controls.Add(this.IndbtnUpdate);
            this.TbIndividualClients.Controls.Add(this.indbtnAddclient);
            this.TbIndividualClients.Controls.Add(this.indbtnEditClient);
            this.TbIndividualClients.Controls.Add(this.ClientsbtnLogout);
            this.TbIndividualClients.Controls.Add(this.IndbtnDelete);
            this.TbIndividualClients.Controls.Add(this.IndContractGB);
            this.TbIndividualClients.Controls.Add(this.indgbdetails);
            this.TbIndividualClients.Controls.Add(this.IndbtnComplete);
            this.TbIndividualClients.Controls.Add(this.indcmbClient);
            this.TbIndividualClients.Controls.Add(this.ClientsClose1);
            this.TbIndividualClients.Controls.Add(this.ClientsHelp1);
            this.TbIndividualClients.Controls.Add(this.indlblclientname);
            this.TbIndividualClients.Location = new System.Drawing.Point(204, 4);
            this.TbIndividualClients.Name = "TbIndividualClients";
            this.TbIndividualClients.Padding = new System.Windows.Forms.Padding(3);
            this.TbIndividualClients.Size = new System.Drawing.Size(816, 637);
            this.TbIndividualClients.TabIndex = 0;
            this.TbIndividualClients.Text = "Individual Clients";
            this.TbIndividualClients.UseVisualStyleBackColor = true;
            // 
            // IndbtnCancel
            // 
            this.IndbtnCancel.Image = global::Presentation.Properties.Resources.delete_icon;
            this.IndbtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IndbtnCancel.Location = new System.Drawing.Point(600, 523);
            this.IndbtnCancel.Name = "IndbtnCancel";
            this.IndbtnCancel.Size = new System.Drawing.Size(192, 49);
            this.IndbtnCancel.TabIndex = 41;
            this.IndbtnCancel.Text = "Cancel";
            this.IndbtnCancel.UseVisualStyleBackColor = true;
            this.IndbtnCancel.Visible = false;
            this.IndbtnCancel.Click += new System.EventHandler(this.IndbtnCancel_Click);
            // 
            // IndbtnUpdate
            // 
            this.IndbtnUpdate.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.IndbtnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IndbtnUpdate.Location = new System.Drawing.Point(600, 453);
            this.IndbtnUpdate.Name = "IndbtnUpdate";
            this.IndbtnUpdate.Size = new System.Drawing.Size(192, 49);
            this.IndbtnUpdate.TabIndex = 40;
            this.IndbtnUpdate.Text = "Update";
            this.IndbtnUpdate.UseVisualStyleBackColor = true;
            this.IndbtnUpdate.Visible = false;
            this.IndbtnUpdate.Click += new System.EventHandler(this.IndbtnUpdate_Click);
            // 
            // indbtnAddclient
            // 
            this.indbtnAddclient.Location = new System.Drawing.Point(556, 38);
            this.indbtnAddclient.Name = "indbtnAddclient";
            this.indbtnAddclient.Size = new System.Drawing.Size(127, 38);
            this.indbtnAddclient.TabIndex = 39;
            this.indbtnAddclient.Text = "Add client";
            this.indbtnAddclient.UseVisualStyleBackColor = true;
            this.indbtnAddclient.Click += new System.EventHandler(this.incbtnAddclient_Click);
            // 
            // indbtnEditClient
            // 
            this.indbtnEditClient.Location = new System.Drawing.Point(410, 39);
            this.indbtnEditClient.Name = "indbtnEditClient";
            this.indbtnEditClient.Size = new System.Drawing.Size(127, 38);
            this.indbtnEditClient.TabIndex = 38;
            this.indbtnEditClient.Text = "Edit Client";
            this.indbtnEditClient.UseVisualStyleBackColor = true;
            this.indbtnEditClient.Click += new System.EventHandler(this.indbtnEditClient_Click);
            // 
            // ClientsbtnLogout
            // 
            this.ClientsbtnLogout.Image = global::Presentation.Properties.Resources.logout;
            this.ClientsbtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ClientsbtnLogout.Location = new System.Drawing.Point(600, 588);
            this.ClientsbtnLogout.Name = "ClientsbtnLogout";
            this.ClientsbtnLogout.Size = new System.Drawing.Size(192, 46);
            this.ClientsbtnLogout.TabIndex = 37;
            this.ClientsbtnLogout.Text = "LOGOUT";
            this.ClientsbtnLogout.UseVisualStyleBackColor = true;
            this.ClientsbtnLogout.Click += new System.EventHandler(this.ClientsbtnLogout_Click);
            // 
            // IndbtnDelete
            // 
            this.IndbtnDelete.Image = global::Presentation.Properties.Resources.delete_icon;
            this.IndbtnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IndbtnDelete.Location = new System.Drawing.Point(600, 523);
            this.IndbtnDelete.Name = "IndbtnDelete";
            this.IndbtnDelete.Size = new System.Drawing.Size(192, 49);
            this.IndbtnDelete.TabIndex = 36;
            this.IndbtnDelete.Text = "Delete Client";
            this.IndbtnDelete.UseVisualStyleBackColor = true;
            this.IndbtnDelete.Visible = false;
            this.IndbtnDelete.Click += new System.EventHandler(this.IndbtnDelete_Click);
            // 
            // IndContractGB
            // 
            this.IndContractGB.BackColor = System.Drawing.Color.Gainsboro;
            this.IndContractGB.Controls.Add(this.IndcmbContractEndDate);
            this.IndContractGB.Controls.Add(this.label35);
            this.IndContractGB.Controls.Add(this.IndcmbContractStartDate);
            this.IndContractGB.Controls.Add(this.label34);
            this.IndContractGB.Controls.Add(this.label24);
            this.IndContractGB.Controls.Add(this.IndcmbPackage);
            this.IndContractGB.Controls.Add(this.label25);
            this.IndContractGB.Controls.Add(this.IndcmbContractLevel);
            this.IndContractGB.Location = new System.Drawing.Point(0, 453);
            this.IndContractGB.Name = "IndContractGB";
            this.IndContractGB.Size = new System.Drawing.Size(591, 178);
            this.IndContractGB.TabIndex = 35;
            this.IndContractGB.TabStop = false;
            this.IndContractGB.Text = "Contract";
            this.IndContractGB.Visible = false;
            // 
            // IndcmbContractEndDate
            // 
            this.IndcmbContractEndDate.Location = new System.Drawing.Point(432, 101);
            this.IndcmbContractEndDate.Name = "IndcmbContractEndDate";
            this.IndcmbContractEndDate.Size = new System.Drawing.Size(147, 35);
            this.IndcmbContractEndDate.TabIndex = 48;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(318, 101);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(103, 30);
            this.label35.TabIndex = 47;
            this.label35.Text = "End Date:";
            // 
            // IndcmbContractStartDate
            // 
            this.IndcmbContractStartDate.Location = new System.Drawing.Point(162, 97);
            this.IndcmbContractStartDate.Name = "IndcmbContractStartDate";
            this.IndcmbContractStartDate.Size = new System.Drawing.Size(150, 35);
            this.IndcmbContractStartDate.TabIndex = 46;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(12, 98);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(110, 30);
            this.label34.TabIndex = 45;
            this.label34.Text = "Start Date:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(332, 34);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(94, 30);
            this.label24.TabIndex = 44;
            this.label24.Text = "Package:";
            // 
            // IndcmbPackage
            // 
            this.IndcmbPackage.FormattingEnabled = true;
            this.IndcmbPackage.Location = new System.Drawing.Point(432, 31);
            this.IndcmbPackage.Name = "IndcmbPackage";
            this.IndcmbPackage.Size = new System.Drawing.Size(147, 38);
            this.IndcmbPackage.TabIndex = 43;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 31);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(150, 30);
            this.label25.TabIndex = 42;
            this.label25.Text = "Contract Level:";
            // 
            // IndcmbContractLevel
            // 
            this.IndcmbContractLevel.FormattingEnabled = true;
            this.IndcmbContractLevel.Items.AddRange(new object[] {
            "Platinum",
            "Gold",
            "Silver",
            "Bronze"});
            this.IndcmbContractLevel.Location = new System.Drawing.Point(162, 31);
            this.IndcmbContractLevel.Name = "IndcmbContractLevel";
            this.IndcmbContractLevel.Size = new System.Drawing.Size(150, 38);
            this.IndcmbContractLevel.TabIndex = 15;
            // 
            // indgbdetails
            // 
            this.indgbdetails.BackColor = System.Drawing.Color.Gainsboro;
            this.indgbdetails.Controls.Add(this.IndStatus);
            this.indgbdetails.Controls.Add(this.label7);
            this.indgbdetails.Controls.Add(this.IndProvince);
            this.indgbdetails.Controls.Add(this.UserslblBuidingNumber);
            this.indgbdetails.Controls.Add(this.IndBuildingNumber);
            this.indgbdetails.Controls.Add(this.UserslbProvince);
            this.indgbdetails.Controls.Add(this.IndsClientFaxNumber);
            this.indgbdetails.Controls.Add(this.label21);
            this.indgbdetails.Controls.Add(this.IndClientEmail);
            this.indgbdetails.Controls.Add(this.label22);
            this.indgbdetails.Controls.Add(this.IndClientPhoneNumber);
            this.indgbdetails.Controls.Add(this.label23);
            this.indgbdetails.Controls.Add(this.IndClientDOB);
            this.indgbdetails.Controls.Add(this.IndClientTelNumber);
            this.indgbdetails.Controls.Add(this.label26);
            this.indgbdetails.Controls.Add(this.IndClientCountry);
            this.indgbdetails.Controls.Add(this.IndClientPosyalCode);
            this.indgbdetails.Controls.Add(this.label27);
            this.indgbdetails.Controls.Add(this.label28);
            this.indgbdetails.Controls.Add(this.label29);
            this.indgbdetails.Controls.Add(this.IndCity);
            this.indgbdetails.Controls.Add(this.IndStreetName);
            this.indgbdetails.Controls.Add(this.IndClientLatName);
            this.indgbdetails.Controls.Add(this.IndFirstName);
            this.indgbdetails.Controls.Add(this.label30);
            this.indgbdetails.Controls.Add(this.label31);
            this.indgbdetails.Controls.Add(this.label32);
            this.indgbdetails.Controls.Add(this.label33);
            this.indgbdetails.Location = new System.Drawing.Point(0, 83);
            this.indgbdetails.Name = "indgbdetails";
            this.indgbdetails.Size = new System.Drawing.Size(817, 364);
            this.indgbdetails.TabIndex = 34;
            this.indgbdetails.TabStop = false;
            this.indgbdetails.Text = "Client Details";
            this.indgbdetails.Visible = false;
            // 
            // IndStatus
            // 
            this.IndStatus.FormattingEnabled = true;
            this.IndStatus.Items.AddRange(new object[] {
            "Green",
            "Orange",
            "Red",
            "Blue"});
            this.IndStatus.Location = new System.Drawing.Point(580, 241);
            this.IndStatus.Name = "IndStatus";
            this.IndStatus.Size = new System.Drawing.Size(221, 38);
            this.IndStatus.TabIndex = 49;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(449, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 30);
            this.label7.TabIndex = 117;
            this.label7.Text = "Status:";
            // 
            // IndProvince
            // 
            this.IndProvince.Location = new System.Drawing.Point(580, 194);
            this.IndProvince.Name = "IndProvince";
            this.IndProvince.Size = new System.Drawing.Size(221, 35);
            this.IndProvince.TabIndex = 116;
            // 
            // UserslblBuidingNumber
            // 
            this.UserslblBuidingNumber.AutoSize = true;
            this.UserslblBuidingNumber.Location = new System.Drawing.Point(6, 317);
            this.UserslblBuidingNumber.Name = "UserslblBuidingNumber";
            this.UserslblBuidingNumber.Size = new System.Drawing.Size(175, 30);
            this.UserslblBuidingNumber.TabIndex = 115;
            this.UserslblBuidingNumber.Text = "Building Number:";
            // 
            // IndBuildingNumber
            // 
            this.IndBuildingNumber.Location = new System.Drawing.Point(187, 320);
            this.IndBuildingNumber.Name = "IndBuildingNumber";
            this.IndBuildingNumber.Size = new System.Drawing.Size(253, 35);
            this.IndBuildingNumber.TabIndex = 114;
            // 
            // UserslbProvince
            // 
            this.UserslbProvince.AutoSize = true;
            this.UserslbProvince.Location = new System.Drawing.Point(449, 192);
            this.UserslbProvince.Name = "UserslbProvince";
            this.UserslbProvince.Size = new System.Drawing.Size(97, 30);
            this.UserslbProvince.TabIndex = 113;
            this.UserslbProvince.Text = "Province:";
            // 
            // IndsClientFaxNumber
            // 
            this.IndsClientFaxNumber.Location = new System.Drawing.Point(187, 279);
            this.IndsClientFaxNumber.Name = "IndsClientFaxNumber";
            this.IndsClientFaxNumber.Size = new System.Drawing.Size(253, 35);
            this.IndsClientFaxNumber.TabIndex = 44;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 282);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(130, 30);
            this.label21.TabIndex = 43;
            this.label21.Text = "Fax Number:";
            // 
            // IndClientEmail
            // 
            this.IndClientEmail.Location = new System.Drawing.Point(136, 192);
            this.IndClientEmail.Name = "IndClientEmail";
            this.IndClientEmail.Size = new System.Drawing.Size(304, 35);
            this.IndClientEmail.TabIndex = 42;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 192);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 30);
            this.label22.TabIndex = 41;
            this.label22.Text = "Email:";
            // 
            // IndClientPhoneNumber
            // 
            this.IndClientPhoneNumber.Location = new System.Drawing.Point(187, 238);
            this.IndClientPhoneNumber.Name = "IndClientPhoneNumber";
            this.IndClientPhoneNumber.Size = new System.Drawing.Size(253, 35);
            this.IndClientPhoneNumber.TabIndex = 40;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 241);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(159, 30);
            this.label23.TabIndex = 39;
            this.label23.Text = "Phone Number:";
            // 
            // IndClientDOB
            // 
            this.IndClientDOB.Location = new System.Drawing.Point(580, 64);
            this.IndClientDOB.Name = "IndClientDOB";
            this.IndClientDOB.Size = new System.Drawing.Size(221, 35);
            this.IndClientDOB.TabIndex = 38;
            // 
            // IndClientTelNumber
            // 
            this.IndClientTelNumber.Location = new System.Drawing.Point(580, 150);
            this.IndClientTelNumber.Name = "IndClientTelNumber";
            this.IndClientTelNumber.Size = new System.Drawing.Size(221, 35);
            this.IndClientTelNumber.TabIndex = 37;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(446, 153);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(125, 30);
            this.label26.TabIndex = 36;
            this.label26.Text = "Tel Number:";
            // 
            // IndClientCountry
            // 
            this.IndClientCountry.Location = new System.Drawing.Point(136, 154);
            this.IndClientCountry.Name = "IndClientCountry";
            this.IndClientCountry.Size = new System.Drawing.Size(304, 35);
            this.IndClientCountry.TabIndex = 35;
            // 
            // IndClientPosyalCode
            // 
            this.IndClientPosyalCode.Location = new System.Drawing.Point(580, 103);
            this.IndClientPosyalCode.Name = "IndClientPosyalCode";
            this.IndClientPosyalCode.Size = new System.Drawing.Size(221, 35);
            this.IndClientPosyalCode.TabIndex = 34;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(449, 70);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(136, 30);
            this.label27.TabIndex = 30;
            this.label27.Text = "Date of Birth:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 153);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(91, 30);
            this.label28.TabIndex = 32;
            this.label28.Text = "Country:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(449, 105);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(127, 30);
            this.label29.TabIndex = 33;
            this.label29.Text = "Postal Code:";
            // 
            // IndCity
            // 
            this.IndCity.Location = new System.Drawing.Point(136, 113);
            this.IndCity.Name = "IndCity";
            this.IndCity.Size = new System.Drawing.Size(304, 35);
            this.IndCity.TabIndex = 29;
            // 
            // IndStreetName
            // 
            this.IndStreetName.Location = new System.Drawing.Point(136, 72);
            this.IndStreetName.Name = "IndStreetName";
            this.IndStreetName.Size = new System.Drawing.Size(304, 35);
            this.IndStreetName.TabIndex = 28;
            // 
            // IndClientLatName
            // 
            this.IndClientLatName.Location = new System.Drawing.Point(580, 27);
            this.IndClientLatName.Name = "IndClientLatName";
            this.IndClientLatName.Size = new System.Drawing.Size(221, 35);
            this.IndClientLatName.TabIndex = 17;
            // 
            // IndFirstName
            // 
            this.IndFirstName.Location = new System.Drawing.Point(136, 31);
            this.IndFirstName.Name = "IndFirstName";
            this.IndFirstName.Size = new System.Drawing.Size(304, 35);
            this.IndFirstName.TabIndex = 16;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 31);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(118, 30);
            this.label30.TabIndex = 12;
            this.label30.Text = "First Name:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(449, 32);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 30);
            this.label31.TabIndex = 24;
            this.label31.Text = "Last Name:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(6, 118);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 30);
            this.label32.TabIndex = 25;
            this.label32.Text = "City:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 69);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(133, 30);
            this.label33.TabIndex = 26;
            this.label33.Text = "Street Name:";
            // 
            // IndbtnComplete
            // 
            this.IndbtnComplete.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.IndbtnComplete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IndbtnComplete.Location = new System.Drawing.Point(600, 453);
            this.IndbtnComplete.Name = "IndbtnComplete";
            this.IndbtnComplete.Size = new System.Drawing.Size(192, 49);
            this.IndbtnComplete.TabIndex = 33;
            this.IndbtnComplete.Text = "Save";
            this.IndbtnComplete.UseVisualStyleBackColor = true;
            this.IndbtnComplete.Visible = false;
            this.IndbtnComplete.Click += new System.EventHandler(this.IndbtnComplete_Click);
            // 
            // indcmbClient
            // 
            this.indcmbClient.FormattingEnabled = true;
            this.indcmbClient.Location = new System.Drawing.Point(145, 39);
            this.indcmbClient.Name = "indcmbClient";
            this.indcmbClient.Size = new System.Drawing.Size(246, 38);
            this.indcmbClient.TabIndex = 19;
            // 
            // ClientsClose1
            // 
            this.ClientsClose1.Image = global::Presentation.Properties.Resources.close;
            this.ClientsClose1.Location = new System.Drawing.Point(774, 8);
            this.ClientsClose1.Name = "ClientsClose1";
            this.ClientsClose1.Size = new System.Drawing.Size(34, 35);
            this.ClientsClose1.TabIndex = 18;
            this.ClientsClose1.TabStop = false;
            this.ClientsClose1.Click += new System.EventHandler(this.ClientsClose1_Click);
            // 
            // ClientsHelp1
            // 
            this.ClientsHelp1.Image = global::Presentation.Properties.Resources.help_icon;
            this.ClientsHelp1.Location = new System.Drawing.Point(732, 8);
            this.ClientsHelp1.Name = "ClientsHelp1";
            this.ClientsHelp1.Size = new System.Drawing.Size(36, 35);
            this.ClientsHelp1.TabIndex = 17;
            this.ClientsHelp1.TabStop = false;
            this.ClientsHelp1.Click += new System.EventHandler(this.ClientsHelp1_Click);
            // 
            // indlblclientname
            // 
            this.indlblclientname.AutoSize = true;
            this.indlblclientname.Location = new System.Drawing.Point(6, 39);
            this.indlblclientname.Name = "indlblclientname";
            this.indlblclientname.Size = new System.Drawing.Size(133, 30);
            this.indlblclientname.TabIndex = 6;
            this.indlblclientname.Text = "Client Name:";
            // 
            // TbBusinessClients
            // 
            this.TbBusinessClients.Controls.Add(this.BusClientDelete);
            this.TbBusinessClients.Controls.Add(this.BusClientbtnaddclient);
            this.TbBusinessClients.Controls.Add(this.BusClientbtneditbusiness);
            this.TbBusinessClients.Controls.Add(this.BusClientUpdate);
            this.TbBusinessClients.Controls.Add(this.BusClientcmbBusinesses);
            this.TbBusinessClients.Controls.Add(this.BusClientlblbusinesses);
            this.TbBusinessClients.Controls.Add(this.ClientsbtnLogout2);
            this.TbBusinessClients.Controls.Add(this.BusClientbtncance);
            this.TbBusinessClients.Controls.Add(this.BusClientgbdetails);
            this.TbBusinessClients.Controls.Add(this.BusClientgbcontract);
            this.TbBusinessClients.Controls.Add(this.BusClientSaveClient);
            this.TbBusinessClients.Controls.Add(this.ClientClose2);
            this.TbBusinessClients.Controls.Add(this.ClientsHelp2);
            this.TbBusinessClients.Location = new System.Drawing.Point(204, 4);
            this.TbBusinessClients.Name = "TbBusinessClients";
            this.TbBusinessClients.Padding = new System.Windows.Forms.Padding(3);
            this.TbBusinessClients.Size = new System.Drawing.Size(816, 637);
            this.TbBusinessClients.TabIndex = 1;
            this.TbBusinessClients.Text = "Business Clients";
            this.TbBusinessClients.UseVisualStyleBackColor = true;
            // 
            // BusClientDelete
            // 
            this.BusClientDelete.Image = global::Presentation.Properties.Resources.delete_icon;
            this.BusClientDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BusClientDelete.Location = new System.Drawing.Point(627, 536);
            this.BusClientDelete.Name = "BusClientDelete";
            this.BusClientDelete.Size = new System.Drawing.Size(171, 49);
            this.BusClientDelete.TabIndex = 49;
            this.BusClientDelete.Text = "Delete";
            this.BusClientDelete.UseVisualStyleBackColor = true;
            this.BusClientDelete.Visible = false;
            this.BusClientDelete.Click += new System.EventHandler(this.BusClientDelete_Click);
            // 
            // BusClientbtnaddclient
            // 
            this.BusClientbtnaddclient.Location = new System.Drawing.Point(565, 38);
            this.BusClientbtnaddclient.Name = "BusClientbtnaddclient";
            this.BusClientbtnaddclient.Size = new System.Drawing.Size(127, 38);
            this.BusClientbtnaddclient.TabIndex = 47;
            this.BusClientbtnaddclient.Text = "Add client";
            this.BusClientbtnaddclient.UseVisualStyleBackColor = true;
            this.BusClientbtnaddclient.Click += new System.EventHandler(this.BusClientbtnaddclient_Click);
            // 
            // BusClientbtneditbusiness
            // 
            this.BusClientbtneditbusiness.Location = new System.Drawing.Point(419, 39);
            this.BusClientbtneditbusiness.Name = "BusClientbtneditbusiness";
            this.BusClientbtneditbusiness.Size = new System.Drawing.Size(127, 38);
            this.BusClientbtneditbusiness.TabIndex = 46;
            this.BusClientbtneditbusiness.Text = "Edit Client";
            this.BusClientbtneditbusiness.UseVisualStyleBackColor = true;
            // 
            // BusClientUpdate
            // 
            this.BusClientUpdate.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.BusClientUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BusClientUpdate.Location = new System.Drawing.Point(627, 483);
            this.BusClientUpdate.Name = "BusClientUpdate";
            this.BusClientUpdate.Size = new System.Drawing.Size(171, 49);
            this.BusClientUpdate.TabIndex = 48;
            this.BusClientUpdate.Text = "Update";
            this.BusClientUpdate.UseVisualStyleBackColor = true;
            this.BusClientUpdate.Visible = false;
            this.BusClientUpdate.Click += new System.EventHandler(this.BusClientUpdate_Click);
            // 
            // BusClientcmbBusinesses
            // 
            this.BusClientcmbBusinesses.FormattingEnabled = true;
            this.BusClientcmbBusinesses.Location = new System.Drawing.Point(154, 39);
            this.BusClientcmbBusinesses.Name = "BusClientcmbBusinesses";
            this.BusClientcmbBusinesses.Size = new System.Drawing.Size(246, 38);
            this.BusClientcmbBusinesses.TabIndex = 45;
            // 
            // BusClientlblbusinesses
            // 
            this.BusClientlblbusinesses.AutoSize = true;
            this.BusClientlblbusinesses.Location = new System.Drawing.Point(15, 39);
            this.BusClientlblbusinesses.Name = "BusClientlblbusinesses";
            this.BusClientlblbusinesses.Size = new System.Drawing.Size(133, 30);
            this.BusClientlblbusinesses.TabIndex = 44;
            this.BusClientlblbusinesses.Text = "Client Name:";
            // 
            // ClientsbtnLogout2
            // 
            this.ClientsbtnLogout2.Image = global::Presentation.Properties.Resources.logout;
            this.ClientsbtnLogout2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ClientsbtnLogout2.Location = new System.Drawing.Point(627, 591);
            this.ClientsbtnLogout2.Name = "ClientsbtnLogout2";
            this.ClientsbtnLogout2.Size = new System.Drawing.Size(171, 46);
            this.ClientsbtnLogout2.TabIndex = 43;
            this.ClientsbtnLogout2.Text = "LOGOUT";
            this.ClientsbtnLogout2.UseVisualStyleBackColor = true;
            this.ClientsbtnLogout2.Click += new System.EventHandler(this.ClientsbtnLogout2_Click);
            // 
            // BusClientbtncance
            // 
            this.BusClientbtncance.Image = global::Presentation.Properties.Resources.delete_icon;
            this.BusClientbtncance.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BusClientbtncance.Location = new System.Drawing.Point(627, 536);
            this.BusClientbtncance.Name = "BusClientbtncance";
            this.BusClientbtncance.Size = new System.Drawing.Size(171, 49);
            this.BusClientbtncance.TabIndex = 42;
            this.BusClientbtncance.Text = "Cancel";
            this.BusClientbtncance.UseVisualStyleBackColor = true;
            this.BusClientbtncance.Visible = false;
            this.BusClientbtncance.Click += new System.EventHandler(this.BusClientbtncance_Click);
            // 
            // BusClientgbdetails
            // 
            this.BusClientgbdetails.BackColor = System.Drawing.Color.Gainsboro;
            this.BusClientgbdetails.Controls.Add(this.BusClientStatus);
            this.BusClientgbdetails.Controls.Add(this.label1);
            this.BusClientgbdetails.Controls.Add(this.BusClientProvince);
            this.BusClientgbdetails.Controls.Add(this.label5);
            this.BusClientgbdetails.Controls.Add(this.BusClientbuildingnumber);
            this.BusClientgbdetails.Controls.Add(this.label16);
            this.BusClientgbdetails.Controls.Add(this.BusClientSuperVisorNumber);
            this.BusClientgbdetails.Controls.Add(this.label20);
            this.BusClientgbdetails.Controls.Add(this.BusClientSupervisor);
            this.BusClientgbdetails.Controls.Add(this.label19);
            this.BusClientgbdetails.Controls.Add(this.BusClientManagerNumber);
            this.BusClientgbdetails.Controls.Add(this.label18);
            this.BusClientgbdetails.Controls.Add(this.BusClienttextManage);
            this.BusClientgbdetails.Controls.Add(this.label17);
            this.BusClientgbdetails.Controls.Add(this.BusClientFaxNumber);
            this.BusClientgbdetails.Controls.Add(this.label15);
            this.BusClientgbdetails.Controls.Add(this.BusClientEmail);
            this.BusClientgbdetails.Controls.Add(this.label14);
            this.BusClientgbdetails.Controls.Add(this.BusClientPhoneNumber);
            this.BusClientgbdetails.Controls.Add(this.label13);
            this.BusClientgbdetails.Controls.Add(this.BusClientTelNumber);
            this.BusClientgbdetails.Controls.Add(this.label12);
            this.BusClientgbdetails.Controls.Add(this.BusClientCountry);
            this.BusClientgbdetails.Controls.Add(this.BusClientPosyalCode);
            this.BusClientgbdetails.Controls.Add(this.label10);
            this.BusClientgbdetails.Controls.Add(this.label11);
            this.BusClientgbdetails.Controls.Add(this.BusClientCity);
            this.BusClientgbdetails.Controls.Add(this.BusClientStreetName);
            this.BusClientgbdetails.Controls.Add(this.BusClientCompany);
            this.BusClientgbdetails.Controls.Add(this.label3);
            this.BusClientgbdetails.Controls.Add(this.label8);
            this.BusClientgbdetails.Controls.Add(this.label9);
            this.BusClientgbdetails.Location = new System.Drawing.Point(0, 83);
            this.BusClientgbdetails.Name = "BusClientgbdetails";
            this.BusClientgbdetails.Size = new System.Drawing.Size(820, 394);
            this.BusClientgbdetails.TabIndex = 41;
            this.BusClientgbdetails.TabStop = false;
            this.BusClientgbdetails.Text = "Client Details";
            this.BusClientgbdetails.Visible = false;
            // 
            // BusClientStatus
            // 
            this.BusClientStatus.FormattingEnabled = true;
            this.BusClientStatus.Items.AddRange(new object[] {
            "Green",
            "Orange",
            "Red",
            "Blue"});
            this.BusClientStatus.Location = new System.Drawing.Point(590, 300);
            this.BusClientStatus.Name = "BusClientStatus";
            this.BusClientStatus.Size = new System.Drawing.Size(218, 38);
            this.BusClientStatus.TabIndex = 122;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(402, 303);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 30);
            this.label1.TabIndex = 121;
            this.label1.Text = "Status:";
            // 
            // BusClientProvince
            // 
            this.BusClientProvince.Location = new System.Drawing.Point(590, 213);
            this.BusClientProvince.Name = "BusClientProvince";
            this.BusClientProvince.Size = new System.Drawing.Size(218, 35);
            this.BusClientProvince.TabIndex = 120;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(402, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(175, 30);
            this.label5.TabIndex = 119;
            this.label5.Text = "Building Number:";
            // 
            // BusClientbuildingnumber
            // 
            this.BusClientbuildingnumber.Location = new System.Drawing.Point(590, 254);
            this.BusClientbuildingnumber.Name = "BusClientbuildingnumber";
            this.BusClientbuildingnumber.Size = new System.Drawing.Size(218, 35);
            this.BusClientbuildingnumber.TabIndex = 118;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(402, 216);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 30);
            this.label16.TabIndex = 117;
            this.label16.Text = "Province:";
            // 
            // BusClientSuperVisorNumber
            // 
            this.BusClientSuperVisorNumber.Location = new System.Drawing.Point(590, 167);
            this.BusClientSuperVisorNumber.Name = "BusClientSuperVisorNumber";
            this.BusClientSuperVisorNumber.Size = new System.Drawing.Size(218, 35);
            this.BusClientSuperVisorNumber.TabIndex = 52;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(402, 167);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(192, 30);
            this.label20.TabIndex = 51;
            this.label20.Text = "Supervisor number:";
            // 
            // BusClientSupervisor
            // 
            this.BusClientSupervisor.Location = new System.Drawing.Point(590, 119);
            this.BusClientSupervisor.Name = "BusClientSupervisor";
            this.BusClientSupervisor.Size = new System.Drawing.Size(218, 35);
            this.BusClientSupervisor.TabIndex = 50;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(402, 124);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(114, 30);
            this.label19.TabIndex = 49;
            this.label19.Text = "Supervisor:";
            // 
            // BusClientManagerNumber
            // 
            this.BusClientManagerNumber.Location = new System.Drawing.Point(590, 78);
            this.BusClientManagerNumber.Name = "BusClientManagerNumber";
            this.BusClientManagerNumber.Size = new System.Drawing.Size(218, 35);
            this.BusClientManagerNumber.TabIndex = 48;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(402, 83);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(179, 30);
            this.label18.TabIndex = 47;
            this.label18.Text = "Manager number:";
            // 
            // BusClienttextManage
            // 
            this.BusClienttextManage.Location = new System.Drawing.Point(590, 34);
            this.BusClienttextManage.Name = "BusClienttextManage";
            this.BusClienttextManage.Size = new System.Drawing.Size(218, 35);
            this.BusClienttextManage.TabIndex = 46;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(405, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 30);
            this.label17.TabIndex = 45;
            this.label17.Text = "Manager:";
            // 
            // BusClientFaxNumber
            // 
            this.BusClientFaxNumber.Location = new System.Drawing.Point(154, 312);
            this.BusClientFaxNumber.Name = "BusClientFaxNumber";
            this.BusClientFaxNumber.Size = new System.Drawing.Size(231, 35);
            this.BusClientFaxNumber.TabIndex = 44;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 312);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(130, 30);
            this.label15.TabIndex = 43;
            this.label15.Text = "Fax Number:";
            // 
            // BusClientEmail
            // 
            this.BusClientEmail.Location = new System.Drawing.Point(154, 192);
            this.BusClientEmail.Name = "BusClientEmail";
            this.BusClientEmail.Size = new System.Drawing.Size(231, 35);
            this.BusClientEmail.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 192);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 30);
            this.label14.TabIndex = 41;
            this.label14.Text = "Email:";
            // 
            // BusClientPhoneNumber
            // 
            this.BusClientPhoneNumber.Location = new System.Drawing.Point(154, 271);
            this.BusClientPhoneNumber.Name = "BusClientPhoneNumber";
            this.BusClientPhoneNumber.Size = new System.Drawing.Size(231, 35);
            this.BusClientPhoneNumber.TabIndex = 40;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 271);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(159, 30);
            this.label13.TabIndex = 39;
            this.label13.Text = "Phone Number:";
            // 
            // BusClientTelNumber
            // 
            this.BusClientTelNumber.Location = new System.Drawing.Point(154, 233);
            this.BusClientTelNumber.Name = "BusClientTelNumber";
            this.BusClientTelNumber.Size = new System.Drawing.Size(231, 35);
            this.BusClientTelNumber.TabIndex = 37;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 233);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 30);
            this.label12.TabIndex = 36;
            this.label12.Text = "Tel Number:";
            // 
            // BusClientCountry
            // 
            this.BusClientCountry.Location = new System.Drawing.Point(154, 154);
            this.BusClientCountry.Name = "BusClientCountry";
            this.BusClientCountry.Size = new System.Drawing.Size(231, 35);
            this.BusClientCountry.TabIndex = 35;
            // 
            // BusClientPosyalCode
            // 
            this.BusClientPosyalCode.Location = new System.Drawing.Point(154, 355);
            this.BusClientPosyalCode.Name = "BusClientPosyalCode";
            this.BusClientPosyalCode.Size = new System.Drawing.Size(231, 35);
            this.BusClientPosyalCode.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 154);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 30);
            this.label10.TabIndex = 32;
            this.label10.Text = "Country:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 355);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(127, 30);
            this.label11.TabIndex = 33;
            this.label11.Text = "Postal Code:";
            // 
            // BusClientCity
            // 
            this.BusClientCity.Location = new System.Drawing.Point(154, 113);
            this.BusClientCity.Name = "BusClientCity";
            this.BusClientCity.Size = new System.Drawing.Size(231, 35);
            this.BusClientCity.TabIndex = 29;
            // 
            // BusClientStreetName
            // 
            this.BusClientStreetName.Location = new System.Drawing.Point(154, 72);
            this.BusClientStreetName.Name = "BusClientStreetName";
            this.BusClientStreetName.Size = new System.Drawing.Size(231, 35);
            this.BusClientStreetName.TabIndex = 28;
            // 
            // BusClientCompany
            // 
            this.BusClientCompany.Location = new System.Drawing.Point(154, 31);
            this.BusClientCompany.Name = "BusClientCompany";
            this.BusClientCompany.Size = new System.Drawing.Size(231, 35);
            this.BusClientCompany.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 30);
            this.label3.TabIndex = 12;
            this.label3.Text = "Company:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 113);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 30);
            this.label8.TabIndex = 25;
            this.label8.Text = "City:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 30);
            this.label9.TabIndex = 26;
            this.label9.Text = "Street Name:";
            // 
            // BusClientgbcontract
            // 
            this.BusClientgbcontract.BackColor = System.Drawing.Color.Gainsboro;
            this.BusClientgbcontract.Controls.Add(this.BusClientenddate);
            this.BusClientgbcontract.Controls.Add(this.label2);
            this.BusClientgbcontract.Controls.Add(this.BusClientStartDate);
            this.BusClientgbcontract.Controls.Add(this.label36);
            this.BusClientgbcontract.Controls.Add(this.label37);
            this.BusClientgbcontract.Controls.Add(this.BusClientcmbPackage);
            this.BusClientgbcontract.Controls.Add(this.label38);
            this.BusClientgbcontract.Controls.Add(this.BusClientcmbContract);
            this.BusClientgbcontract.Location = new System.Drawing.Point(0, 483);
            this.BusClientgbcontract.Name = "BusClientgbcontract";
            this.BusClientgbcontract.Size = new System.Drawing.Size(594, 147);
            this.BusClientgbcontract.TabIndex = 37;
            this.BusClientgbcontract.TabStop = false;
            this.BusClientgbcontract.Text = "Contract Details";
            this.BusClientgbcontract.Visible = false;
            // 
            // BusClientenddate
            // 
            this.BusClientenddate.Location = new System.Drawing.Point(438, 101);
            this.BusClientenddate.Name = "BusClientenddate";
            this.BusClientenddate.Size = new System.Drawing.Size(147, 35);
            this.BusClientenddate.TabIndex = 56;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(324, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 30);
            this.label2.TabIndex = 55;
            this.label2.Text = "End Date:";
            // 
            // BusClientStartDate
            // 
            this.BusClientStartDate.Location = new System.Drawing.Point(168, 97);
            this.BusClientStartDate.Name = "BusClientStartDate";
            this.BusClientStartDate.Size = new System.Drawing.Size(150, 35);
            this.BusClientStartDate.TabIndex = 54;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(18, 98);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(110, 30);
            this.label36.TabIndex = 53;
            this.label36.Text = "Start Date:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(338, 34);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(94, 30);
            this.label37.TabIndex = 52;
            this.label37.Text = "Package:";
            // 
            // BusClientcmbPackage
            // 
            this.BusClientcmbPackage.FormattingEnabled = true;
            this.BusClientcmbPackage.Items.AddRange(new object[] {
            "family responsibility",
            "maternity",
            "vacation",
            "personal",
            "annual leave",
            "medical. "});
            this.BusClientcmbPackage.Location = new System.Drawing.Point(438, 31);
            this.BusClientcmbPackage.Name = "BusClientcmbPackage";
            this.BusClientcmbPackage.Size = new System.Drawing.Size(147, 38);
            this.BusClientcmbPackage.TabIndex = 51;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(12, 31);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(150, 30);
            this.label38.TabIndex = 50;
            this.label38.Text = "Contract Level:";
            // 
            // BusClientcmbContract
            // 
            this.BusClientcmbContract.FormattingEnabled = true;
            this.BusClientcmbContract.Items.AddRange(new object[] {
            "Platinum",
            "Gold",
            "Silver",
            "Bronze"});
            this.BusClientcmbContract.Location = new System.Drawing.Point(168, 31);
            this.BusClientcmbContract.Name = "BusClientcmbContract";
            this.BusClientcmbContract.Size = new System.Drawing.Size(150, 38);
            this.BusClientcmbContract.TabIndex = 49;
            // 
            // BusClientSaveClient
            // 
            this.BusClientSaveClient.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.BusClientSaveClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BusClientSaveClient.Location = new System.Drawing.Point(627, 483);
            this.BusClientSaveClient.Name = "BusClientSaveClient";
            this.BusClientSaveClient.Size = new System.Drawing.Size(171, 49);
            this.BusClientSaveClient.TabIndex = 40;
            this.BusClientSaveClient.Text = "Save";
            this.BusClientSaveClient.UseVisualStyleBackColor = true;
            this.BusClientSaveClient.Visible = false;
            this.BusClientSaveClient.Click += new System.EventHandler(this.BusClientSaveClient_Click);
            // 
            // ClientClose2
            // 
            this.ClientClose2.Image = global::Presentation.Properties.Resources.close;
            this.ClientClose2.Location = new System.Drawing.Point(776, 6);
            this.ClientClose2.Name = "ClientClose2";
            this.ClientClose2.Size = new System.Drawing.Size(34, 35);
            this.ClientClose2.TabIndex = 39;
            this.ClientClose2.TabStop = false;
            this.ClientClose2.Click += new System.EventHandler(this.ClientClose2_Click);
            // 
            // ClientsHelp2
            // 
            this.ClientsHelp2.Image = global::Presentation.Properties.Resources.help_icon;
            this.ClientsHelp2.Location = new System.Drawing.Point(731, 6);
            this.ClientsHelp2.Name = "ClientsHelp2";
            this.ClientsHelp2.Size = new System.Drawing.Size(36, 35);
            this.ClientsHelp2.TabIndex = 38;
            this.ClientsHelp2.TabStop = false;
            this.ClientsHelp2.Click += new System.EventHandler(this.ClientsHelp2_Click);
            // 
            // Clients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.pnlTemplate);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "Clients";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnlTemplate.ResumeLayout(false);
            this.ClientsTabControl.ResumeLayout(false);
            this.TbIndividualClients.ResumeLayout(false);
            this.TbIndividualClients.PerformLayout();
            this.IndContractGB.ResumeLayout(false);
            this.IndContractGB.PerformLayout();
            this.indgbdetails.ResumeLayout(false);
            this.indgbdetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClientsClose1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientsHelp1)).EndInit();
            this.TbBusinessClients.ResumeLayout(false);
            this.TbBusinessClients.PerformLayout();
            this.BusClientgbdetails.ResumeLayout(false);
            this.BusClientgbdetails.PerformLayout();
            this.BusClientgbcontract.ResumeLayout(false);
            this.BusClientgbcontract.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ClientClose2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClientsHelp2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

       
        private System.Windows.Forms.Panel pnlTemplate;
        private System.Windows.Forms.TabControl ClientsTabControl;
        private System.Windows.Forms.TabPage TbIndividualClients;
        private System.Windows.Forms.PictureBox ClientsClose1;
        private System.Windows.Forms.PictureBox ClientsHelp1;
        private System.Windows.Forms.TabPage TbBusinessClients;
        private System.Windows.Forms.ComboBox indcmbClient;
        private System.Windows.Forms.Label indlblclientname;
        private System.Windows.Forms.GroupBox IndContractGB;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox IndcmbContractLevel;
        private System.Windows.Forms.GroupBox indgbdetails;
        private System.Windows.Forms.TextBox IndsClientFaxNumber;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox IndClientEmail;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox IndClientPhoneNumber;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DateTimePicker IndClientDOB;
        private System.Windows.Forms.TextBox IndClientTelNumber;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox IndClientCountry;
        private System.Windows.Forms.TextBox IndClientPosyalCode;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox IndCity;
        private System.Windows.Forms.TextBox IndStreetName;
        private System.Windows.Forms.TextBox IndClientLatName;
        private System.Windows.Forms.TextBox IndFirstName;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button IndbtnComplete;
        private System.Windows.Forms.Button BusClientSaveClient;
        private System.Windows.Forms.PictureBox ClientClose2;
        private System.Windows.Forms.PictureBox ClientsHelp2;
        private System.Windows.Forms.GroupBox BusClientgbcontract;
        private System.Windows.Forms.GroupBox BusClientgbdetails;
        private System.Windows.Forms.TextBox BusClientSuperVisorNumber;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox BusClientSupervisor;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox BusClientManagerNumber;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox BusClienttextManage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox BusClientFaxNumber;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox BusClientEmail;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox BusClientPhoneNumber;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox BusClientTelNumber;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox BusClientCountry;
        private System.Windows.Forms.TextBox BusClientPosyalCode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox BusClientCity;
        private System.Windows.Forms.TextBox BusClientStreetName;
        private System.Windows.Forms.TextBox BusClientCompany;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button BusClientbtncance;
        private System.Windows.Forms.Button IndbtnDelete;
        private System.Windows.Forms.Button ClientsbtnLogout;
        private System.Windows.Forms.Button ClientsbtnLogout2;
        private System.Windows.Forms.TextBox IndProvince;
        private System.Windows.Forms.Label UserslblBuidingNumber;
        private System.Windows.Forms.TextBox IndBuildingNumber;
        private System.Windows.Forms.Label UserslbProvince;
        private System.Windows.Forms.TextBox BusClientProvince;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox BusClientbuildingnumber;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button indbtnAddclient;
        private System.Windows.Forms.Button indbtnEditClient;
        private System.Windows.Forms.DateTimePicker IndcmbContractEndDate;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.DateTimePicker IndcmbContractStartDate;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox IndcmbPackage;
        private System.Windows.Forms.Button BusClientbtnaddclient;
        private System.Windows.Forms.Button BusClientbtneditbusiness;
        private System.Windows.Forms.ComboBox BusClientcmbBusinesses;
        private System.Windows.Forms.Label BusClientlblbusinesses;
        private System.Windows.Forms.DateTimePicker BusClientenddate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker BusClientStartDate;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox BusClientcmbPackage;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox BusClientcmbContract;
        private System.Windows.Forms.Button IndbtnCancel;
        private System.Windows.Forms.Button IndbtnUpdate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BusClientDelete;
        private System.Windows.Forms.Button BusClientUpdate;
        private System.Windows.Forms.ComboBox IndStatus;
        private System.Windows.Forms.ComboBox BusClientStatus;
        private System.Windows.Forms.Label label1;
    }
}