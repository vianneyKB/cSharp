﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class LeaveRecords : Form
    {
        public LeaveRecords()
        {
            InitializeComponent();
        }
        
        public frmMain main;

        Socketwrapper soc;

        //For animated panels direction
        string rightDirection = "right";

        //For animated panels timeout
        int RightTimeOut = 0;

        //For animated panels position
        int rightX;
        int rightY;

        //method to set fullscreen
        private void setFullScreen()
        {
            int x = Screen.PrimaryScreen.Bounds.Width;
            int y = Screen.PrimaryScreen.Bounds.Height;
            Location = new Point(0, 0);
            Size = new Size(x, y);
        }

        //method to set the position of the main panel that holds the controls to center of the form.
        private void setMainPanelPosition()
        {
            int mX = (Width - pnlMain.Width) / 2;
            int mY = (Height - pnlMain.Height) / 2;
            pnlMain.Location = new Point(mX, mY);
        }


        private void setRightOptionsPanelPosition()
        {
            int y = Height;
            rightY = 0;
            rightX = Width + pnlRightOptions.Width;
            pnlRightOptions.Size = new Size(pnlRightOptions.Width, y);
            pnlRightOptions.Location = new Point(rightX, rightY);
            int rX = pnlRightMain.Location.X;
            int rY = (pnlRightOptions.Height - pnlRightMain.Height) / 2;
            pnlRightMain.Location = new Point(rX, rY);
        }

        private void RightOptions_Tick(object sender, EventArgs e)
        {
            if (RightTimeOut < 1000)
            {
                RightTimeOut++;
            }
            if (RightTimeOut == 1000)
            {
                if (rightDirection == "left")
                {
                    rightDirection = "right";
                }
            }
            if (rightDirection == "left")
            {
                if (rightX > Width - pnlRightOptions.Width)
                {
                    rightX -= 2;
                    pnlRightOptions.Location = new Point(rightX, rightY);
                }
            }
            else
            {
                if (rightX < Width)
                {
                    rightX += 2;
                }
                pnlRightOptions.Location = new Point(rightX, rightY);
            }
        }

        private void pbExit_Click(object sender, EventArgs e)
        {
            soc.Disconnect();
            Application.Exit();
        }

        private void pbHome_Click(object sender, EventArgs e)
        {
            soc.Disconnect();

            main.Show();
            this.Close();
        }

        private void LeaveRecords_Load_1(object sender, EventArgs e)
        {
            setFullScreen();
            setRightOptionsPanelPosition();
            setMainPanelPosition();
            RightOptions.Start();

            soc = new Socketwrapper();

            DataTable dt = new DataTable();
            dt = DataAccess.Leave();
            LeaveRecordsDataGrid.DataSource = dt;


        }

        private void LeaveRecords_MouseMove_1(object sender, MouseEventArgs e)
        {
            if (e.Y >= Height - 15 && e.X < (Width - pnlRightOptions.Width))
            {
                rightDirection = "right";
            }
            if (e.X >= Width - 15)
            {
                rightDirection = "left";
                RightTimeOut = 0;
            }
            if (e.X < (Width - pnlRightOptions.Width))
            {
                rightDirection = "Left";
            }
        }

        private void LeaveRecordsRemoveRecord_Click(object sender, EventArgs e)
        {
            if (LeaveRecordstxtFirstName.Text == "" || LeaveRecordstxtLastName.Text == "")
            {
                MessageBox.Show("Please Fill in all the details before attempting to delete leave");
            }
            else
            {
                DeleteLeave dl = new DeleteLeave(LeaveRecordstxtFirstName.Text.ToString(), LeaveRecordstxtLastName.Text.ToString());
                try
                {

                    byte[] odat = new byte[1000];
                    odat = Serializer.SerializeThis(dl);
                    soc.Send(odat);
                    LeaveRecordstxtFirstName.Text = "";
                    LeaveRecordstxtLastName.Text = "";
                    LeaveRecordscmbReasin.SelectedIndex = -1;
                    MessageBox.Show("Leave application");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void LeaveRecordsDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.LeaveRecordsDataGrid.Rows[e.RowIndex];


                LeaveRecordstxtFirstName.Text = row.Cells["StaffFirstName"].Value.ToString();
                LeaveRecordstxtLastName.Text = row.Cells["StaffLastName"].Value.ToString();
                LeaveRecordscmbReasin.Text = row.Cells["Reason"].Value.ToString();
                LeaveRecordsdtStartDate.Value = (DateTime)row.Cells["LeaveStartDate"].Value;
                LeaveRecordsdtEndDate.Value = (DateTime)row.Cells["LeaveEndDate"].Value;
            }
        }

        private void LeaveRecordsbtnUpdate_Click(object sender, EventArgs e)
        {
            if (LeaveRecordstxtFirstName.Text == "" || LeaveRecordstxtLastName.Text == "" || LeaveRecordscmbReasin.Text == "")
            {
                MessageBox.Show("Please Fill in all the details before applying");
            }
            else
            {
                if (LeaveRecordsdtStartDate.Value.Date == DateTime.Now || LeaveRecordsdtStartDate.Value.Date == LeaveRecordsdtEndDate.Value.Date || LeaveRecordsdtEndDate.Value.Date < LeaveRecordsdtStartDate.Value.Date)
                {
                    MessageBox.Show("Please Select Appropiate dates for application");
                }
                else
                {
                    UpdateLeave up = new UpdateLeave(LeaveRecordscmbReasin.Text.ToString(), LeaveRecordstxtFirstName.Text.ToString(), LeaveRecordstxtLastName.Text.ToString(), LeaveRecordsdtStartDate.Value.Date, LeaveRecordsdtEndDate.Value.Date);
                    DateTime start = LeaveRecordsdtStartDate.Value.Date;
                    DateTime end = LeaveRecordsdtEndDate.Value.Date;
                    try
                    {
                       
                        byte[] odat = new byte[1000];
                        odat = Serializer.SerializeThis(up);
                        soc.Send(odat);
                        LeaveRecordstxtFirstName.Text = "";
                        LeaveRecordstxtLastName.Text = "";
                        LeaveRecordscmbReasin.SelectedIndex = -1;
                        MessageBox.Show("Leave application");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }

            }
        }
    }
}
