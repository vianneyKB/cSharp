﻿namespace Presentation
{
    partial class IncomingCall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {            
            this.label3 = new System.Windows.Forms.Label();
            this.pnlIncomingCall = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.CalllblClientName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.IncomingCallbtnca = new System.Windows.Forms.Button();
            this.IncomingCallAcc = new System.Windows.Forms.Button();
            this.IncomingCallClosebtn = new System.Windows.Forms.PictureBox();
            this.IncomingCallHelpPic = new System.Windows.Forms.PictureBox();
            this.IncomingClientPic = new System.Windows.Forms.PictureBox();
            this.IncomingbtnAccept = new System.Windows.Forms.Button();
            this.Inomingbtnanel = new System.Windows.Forms.Button();
            this.pnlIncomingCall.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingCallClosebtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingCallHelpPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingClientPic)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(400, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(171, 30);
            this.label3.TabIndex = 10;
            this.label3.Text = "INCOMING CALL";
            // 
            // pnlIncomingCall
            // 
            this.pnlIncomingCall.Controls.Add(this.pictureBox1);
            this.pnlIncomingCall.Controls.Add(this.button1);
            this.pnlIncomingCall.Controls.Add(this.CalllblClientName);
            this.pnlIncomingCall.Controls.Add(this.label4);
            this.pnlIncomingCall.Controls.Add(this.IncomingCallbtnca);
            this.pnlIncomingCall.Controls.Add(this.IncomingCallAcc);
            this.pnlIncomingCall.Controls.Add(this.IncomingCallClosebtn);
            this.pnlIncomingCall.Controls.Add(this.IncomingCallHelpPic);
            this.pnlIncomingCall.Location = new System.Drawing.Point(-1, -2);
            this.pnlIncomingCall.Name = "pnlIncomingCall";
            this.pnlIncomingCall.Size = new System.Drawing.Size(1026, 650);
            this.pnlIncomingCall.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Presentation.Properties.Resources.Profile;
            this.pictureBox1.Location = new System.Drawing.Point(404, 108);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(251, 269);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 37;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Image = global::Presentation.Properties.Resources.logout;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(859, 592);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 46);
            this.button1.TabIndex = 36;
            this.button1.Text = "LOGOUT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CalllblClientName
            // 
            this.CalllblClientName.AutoSize = true;
            this.CalllblClientName.Font = new System.Drawing.Font("Segoe UI", 75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalllblClientName.Location = new System.Drawing.Point(186, 380);
            this.CalllblClientName.Name = "CalllblClientName";
            this.CalllblClientName.Size = new System.Drawing.Size(918, 133);
            this.CalllblClientName.TabIndex = 35;
            this.CalllblClientName.Text = "CLIENT FULL NAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(440, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 30);
            this.label4.TabIndex = 5;
            this.label4.Text = "INCOMING CALL";
            // 
            // IncomingCallbtnca
            // 
            this.IncomingCallbtnca.Image = global::Presentation.Properties.Resources.RejectCall;
            this.IncomingCallbtnca.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IncomingCallbtnca.Location = new System.Drawing.Point(658, 504);
            this.IncomingCallbtnca.Name = "IncomingCallbtnca";
            this.IncomingCallbtnca.Size = new System.Drawing.Size(154, 46);
            this.IncomingCallbtnca.TabIndex = 4;
            this.IncomingCallbtnca.Text = "CANCEL";
            this.IncomingCallbtnca.UseVisualStyleBackColor = true;
            this.IncomingCallbtnca.Click += new System.EventHandler(this.IncomingCallbtnca_Click);
            // 
            // IncomingCallAcc
            // 
            this.IncomingCallAcc.Image = global::Presentation.Properties.Resources.AnserwCall;
            this.IncomingCallAcc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IncomingCallAcc.Location = new System.Drawing.Point(261, 504);
            this.IncomingCallAcc.Name = "IncomingCallAcc";
            this.IncomingCallAcc.Size = new System.Drawing.Size(164, 46);
            this.IncomingCallAcc.TabIndex = 3;
            this.IncomingCallAcc.Text = "ANSWER";
            this.IncomingCallAcc.UseVisualStyleBackColor = true;
            this.IncomingCallAcc.Click += new System.EventHandler(this.IncomingCallAcc_Click);
            // 
            // IncomingCallClosebtn
            // 
            this.IncomingCallClosebtn.Image = global::Presentation.Properties.Resources.close;
            this.IncomingCallClosebtn.Location = new System.Drawing.Point(961, 15);
            this.IncomingCallClosebtn.Name = "IncomingCallClosebtn";
            this.IncomingCallClosebtn.Size = new System.Drawing.Size(35, 34);
            this.IncomingCallClosebtn.TabIndex = 1;
            this.IncomingCallClosebtn.TabStop = false;
            this.IncomingCallClosebtn.Click += new System.EventHandler(this.IncomingCallClosebtn_Click);
            // 
            // IncomingCallHelpPic
            // 
            this.IncomingCallHelpPic.Image = global::Presentation.Properties.Resources.help_icon;
            this.IncomingCallHelpPic.Location = new System.Drawing.Point(912, 14);
            this.IncomingCallHelpPic.Name = "IncomingCallHelpPic";
            this.IncomingCallHelpPic.Size = new System.Drawing.Size(34, 35);
            this.IncomingCallHelpPic.TabIndex = 0;
            this.IncomingCallHelpPic.TabStop = false;
            this.IncomingCallHelpPic.Click += new System.EventHandler(this.IncomingCallHelpPic_Click);
            // 
            // IncomingClientPic
            // 
            this.IncomingClientPic.Location = new System.Drawing.Point(350, 112);
            this.IncomingClientPic.Name = "IncomingClientPic";
            this.IncomingClientPic.Size = new System.Drawing.Size(262, 263);
            this.IncomingClientPic.TabIndex = 11;
            this.IncomingClientPic.TabStop = false;
            // 
            // IncomingbtnAccept
            // 
            this.IncomingbtnAccept.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.IncomingbtnAccept.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.IncomingbtnAccept.Location = new System.Drawing.Point(275, 441);
            this.IncomingbtnAccept.Name = "IncomingbtnAccept";
            this.IncomingbtnAccept.Size = new System.Drawing.Size(154, 50);
            this.IncomingbtnAccept.TabIndex = 12;
            this.IncomingbtnAccept.Text = "Answer";
            this.IncomingbtnAccept.UseVisualStyleBackColor = true;
            // 
            // Inomingbtnanel
            // 
            this.Inomingbtnanel.Image = global::Presentation.Properties.Resources.delete_icon;
            this.Inomingbtnanel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Inomingbtnanel.Location = new System.Drawing.Point(526, 441);
            this.Inomingbtnanel.Name = "Inomingbtnanel";
            this.Inomingbtnanel.Size = new System.Drawing.Size(154, 50);
            this.Inomingbtnanel.TabIndex = 13;
            this.Inomingbtnanel.Text = "Cancel";
            this.Inomingbtnanel.UseVisualStyleBackColor = true;
            // 
            // IncomingCall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.pnlIncomingCall);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "IncomingCall";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnlIncomingCall.ResumeLayout(false);
            this.pnlIncomingCall.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingCallClosebtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingCallHelpPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IncomingClientPic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        
        private System.Windows.Forms.Button Inomingbtnanel;
        private System.Windows.Forms.Button IncomingbtnAccept;
        private System.Windows.Forms.PictureBox IncomingClientPic;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlIncomingCall;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button IncomingCallbtnca;
        private System.Windows.Forms.Button IncomingCallAcc;
        private System.Windows.Forms.PictureBox IncomingCallClosebtn;
        private System.Windows.Forms.PictureBox IncomingCallHelpPic;
        private System.Windows.Forms.Label CalllblClientName;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}