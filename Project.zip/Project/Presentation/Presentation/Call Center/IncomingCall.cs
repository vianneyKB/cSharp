﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BussinessLogic;

namespace Presentation
{
    public partial class IncomingCall : Form
    {
        IndividualClient individualclient;
        BusinessClient businessclient;

        private string incomingcallfname;

        public string Incomingcallfname
        {
            get { return incomingcallfname; }
            set { incomingcallfname = value; }
        }
        private string incomingcallLname;

        public string IncomingcallLname
        {
            get { return incomingcallLname; }
            set { incomingcallLname = value; }
        }
        private string incomingcallcompany;

        public string Incomingcallcompany
        {
            get { return incomingcallcompany; }
            set { incomingcallcompany = value; }
        }

        public IncomingCall()
        {
            InitializeComponent();

            Random ran = new Random();
            int r = ran.Next(1, 3);

            if (r == 1)
            {
                individualclient = new IndividualClient();
                IndividualClient ind = individualclient.RandomIndividualClientDetails();

                CalllblClientName.Text = ind.Name + " " + ind.Surname;
                incomingcallfname = ind.Name;
                incomingcallLname = ind.Surname;
            }
            else if (r == 2)
            {
                businessclient = new BusinessClient();
                BusinessClient bus = businessclient.RandomBusinessClientDetails();

                CalllblClientName.Text = bus.Companyname;
                Incomingcallcompany = bus.Companyname;
            }
            
        }

        private void IncomingCallHelpPic_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This page shows incoming calls which can be accepted or declined, acceptance will take you to the call page and declining cancels the call awaits a new call");
        }

        private void IncomingCallAcc_Click(object sender, EventArgs e)
        {
            Call ans = new Call();
            ans.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
            
        }

        private void IncomingCallClosebtn_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void IncomingCallbtnca_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to cancel this call?",
                                    "Cancel call",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                //Cancel Call
                Random ran = new Random();
                int r = ran.Next(1, 3);

                if (r == 1)
                {
                    individualclient = new IndividualClient();
                    IndividualClient ind = individualclient.RandomIndividualClientDetails();

                    CalllblClientName.Text = ind.Name + " " + ind.Surname;
                    incomingcallfname = ind.Name;
                    incomingcallLname = ind.Surname;
                }
                else if (r == 2)
                {
                    businessclient = new BusinessClient();
                    BusinessClient bus = businessclient.RandomBusinessClientDetails();

                    CalllblClientName.Text = bus.Companyname;
                    Incomingcallcompany = bus.Companyname;
                }
            }
            else
            {
                //Do nothing
            }
        }
    }
}
