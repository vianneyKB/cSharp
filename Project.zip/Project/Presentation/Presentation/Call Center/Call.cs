﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BussinessLogic;

namespace Presentation
{
    public partial class Call : Form
    {
        IndividualClient individualclient;
        IncomingCall inc = new IncomingCall();
        BusinessClient businessclient = new BusinessClient();
        DataTable Services_serviceList;

        Calls call = new Calls();

        public Call()
        {
            InitializeComponent();


            //Timer
            StartClockSeconds(ref CalllblTimerSeconds); //Seconds 
            StartClockMinutes(ref CalllblTimerMinutes); //Minutes

            Random ran = new Random();
            int r = ran.Next(1, 3);

            if (r == 1)
            {
                //Client Info
                string incomingcallfname = inc.Incomingcallfname;
                string incomingcallLname = inc.IncomingcallLname;

                individualclient = new IndividualClient();
                IndividualClient ind = individualclient.ReturnAllclientInfo(incomingcallfname, incomingcallLname);

               // dtvCallHistory.DataSource = call.IndividualCallTable(incomingcallfname, incomingcallLname);
                Contract contractdetails = new Contract();
                Contract cont = contractdetails.ReturnAllContratInfo(incomingcallfname, incomingcallLname);
                txtEmd.Text = cont.Startdate.ToString();
                txtStart.Text = cont.Enddate.ToString();
                txtlevel.Text = cont.ContractLevel;
                txtPackage.Text = cont.Package;

                ServicesProvided services = new ServicesProvided();
                Services_serviceList = services.GetListOfServices();
                CallcmbService.DataSource = Services_serviceList;
                CallcmbService.DisplayMember = "ServiceName";
            }
            else if( r == 2)
            {
                //Business info
                string incomingcallcompany = inc.Incomingcallcompany;

                businessclient = new BusinessClient();
                BusinessClient bus = businessclient.ReturnAllBusinessclientInfo(incomingcallcompany);

                Contract contractdetails = new Contract();
                Contract cont = contractdetails.ReturnAllBusinessContratInfo(incomingcallcompany);
                txtEmd.Text = cont.Startdate.ToString();
                txtStart.Text = cont.Enddate.ToString();
                txtlevel.Text = cont.ContractLevel;
                txtPackage.Text = cont.Package;

                //dtvCallHistory.DataSource = call.BusinessCallTable(incomingcallcompany);
                ServicesProvided services = new ServicesProvided();
                Services_serviceList = services.GetListOfServices();
                CallcmbService.DataSource = Services_serviceList;
                CallcmbService.DisplayMember = "ServiceName";
            }
        }

        //**************************************** TIMER **************************************************
        
        public void StartClockSeconds(ref Label l)
        {
            Timer t = new Timer();
            t.Interval = 1000;
            t.Enabled = true;
            t.Tag = l;
            t.Tick += new EventHandler(t_TickSeconds);
            t.Start();
        }

        public void StartClockMinutes(ref Label l)
        {
            Timer t = new Timer();
            t.Interval = 60000;
            t.Enabled = true;
            t.Tag = l;
            t.Tick += new EventHandler(t_TickMinutes);
            t.Start();
        }

        int seconds;
        int minutes;
        bool stop;
        void t_TickSeconds(object sender, EventArgs e)
        {
            if (stop)
            {
                ((Timer)sender).Stop();
                return;
            }
            else if (seconds == 59)
            {
                seconds = -1;
                ((Label)((Timer)sender).Tag).Text = (++seconds).ToString();
            }
            else
            {
                ((Label)((Timer)sender).Tag).Text = (++seconds).ToString();
            }
            
        }

        void t_TickMinutes(object sender, EventArgs e)
        {
            if (stop)
            {
                ((Timer)sender).Stop();
                return;
            }
            ((Label)((Timer)sender).Tag).Text = (++minutes).ToString();
        }

        internal void StopClock()
        {
            seconds = 0;
            minutes = 0;
            stop = true;
        }

        //Help button
        private void Callhelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the client call, the timer is the call duration, all the client's information is shown on this page. The clients service request is taken during his call, select the service from the combo box then send the request or cancel the call");
        }

        private void CallbtnCancel_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to end this call?",
                                    "End call",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                IncomingCall inc = new IncomingCall();
                inc.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            };

            
        }

        private void CallClose_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                     "Exit Program",
                                     MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

       }
}
