﻿namespace Presentation
{
    partial class Call
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRightMain = new System.Windows.Forms.Panel();
            this.pbExit = new System.Windows.Forms.PictureBox();
            this.pbHome = new System.Windows.Forms.PictureBox();
            this.pbLogout = new System.Windows.Forms.PictureBox();
            this.ApprovebtnDeny = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.ApprovebtnApprove = new System.Windows.Forms.Button();
            this.ApprovetxtLName = new System.Windows.Forms.TextBox();
            this.ApprovetxtFName = new System.Windows.Forms.TextBox();
            this.ApproveDataGrid = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlCall = new System.Windows.Forms.Panel();
            this.CalllblTimerMinutes = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CalllblClientName = new System.Windows.Forms.Label();
            this.CallbtnCancel = new System.Windows.Forms.Button();
            this.CallgroupCallHistory = new System.Windows.Forms.GroupBox();
            this.dtvCallHistory = new System.Windows.Forms.DataGridView();
            this.CalllblTimerSeconds = new System.Windows.Forms.Label();
            this.CallCallServiceRequest = new System.Windows.Forms.GroupBox();
            this.CallcmbService = new System.Windows.Forms.ComboBox();
            this.CalllblService = new System.Windows.Forms.Label();
            this.CallCallbtnSendRequest = new System.Windows.Forms.Button();
            this.CallgrpContactInfo = new System.Windows.Forms.GroupBox();
            this.txtEmd = new System.Windows.Forms.TextBox();
            this.txtPackage = new System.Windows.Forms.TextBox();
            this.txtStart = new System.Windows.Forms.TextBox();
            this.txtlevel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CalllblHeading = new System.Windows.Forms.Label();
            this.CallClose = new System.Windows.Forms.PictureBox();
            this.Callhelp = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ApproveDataGrid)).BeginInit();
            this.pnlCall.SuspendLayout();
            this.CallgroupCallHistory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtvCallHistory)).BeginInit();
            this.CallCallServiceRequest.SuspendLayout();
            this.CallgrpContactInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CallClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Callhelp)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlRightMain
            // 
            this.pnlRightMain.Location = new System.Drawing.Point(0, 0);
            this.pnlRightMain.Name = "pnlRightMain";
            this.pnlRightMain.Size = new System.Drawing.Size(200, 100);
            this.pnlRightMain.TabIndex = 0;
            // 
            // pbExit
            // 
            this.pbExit.Location = new System.Drawing.Point(0, 0);
            this.pbExit.Name = "pbExit";
            this.pbExit.Size = new System.Drawing.Size(100, 50);
            this.pbExit.TabIndex = 0;
            this.pbExit.TabStop = false;
            // 
            // pbHome
            // 
            this.pbHome.Location = new System.Drawing.Point(0, 0);
            this.pbHome.Name = "pbHome";
            this.pbHome.Size = new System.Drawing.Size(100, 50);
            this.pbHome.TabIndex = 0;
            this.pbHome.TabStop = false;
            // 
            // pbLogout
            // 
            this.pbLogout.Location = new System.Drawing.Point(0, 0);
            this.pbLogout.Name = "pbLogout";
            this.pbLogout.Size = new System.Drawing.Size(100, 50);
            this.pbLogout.TabIndex = 0;
            this.pbLogout.TabStop = false;
            // 
            // ApprovebtnDeny
            // 
            this.ApprovebtnDeny.Location = new System.Drawing.Point(0, 0);
            this.ApprovebtnDeny.Name = "ApprovebtnDeny";
            this.ApprovebtnDeny.Size = new System.Drawing.Size(75, 23);
            this.ApprovebtnDeny.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 0;
            // 
            // ApprovebtnApprove
            // 
            this.ApprovebtnApprove.Location = new System.Drawing.Point(0, 0);
            this.ApprovebtnApprove.Name = "ApprovebtnApprove";
            this.ApprovebtnApprove.Size = new System.Drawing.Size(75, 23);
            this.ApprovebtnApprove.TabIndex = 0;
            // 
            // ApprovetxtLName
            // 
            this.ApprovetxtLName.Location = new System.Drawing.Point(0, 0);
            this.ApprovetxtLName.Name = "ApprovetxtLName";
            this.ApprovetxtLName.Size = new System.Drawing.Size(100, 20);
            this.ApprovetxtLName.TabIndex = 0;
            // 
            // ApprovetxtFName
            // 
            this.ApprovetxtFName.Location = new System.Drawing.Point(0, 0);
            this.ApprovetxtFName.Name = "ApprovetxtFName";
            this.ApprovetxtFName.Size = new System.Drawing.Size(100, 20);
            this.ApprovetxtFName.TabIndex = 0;
            // 
            // ApproveDataGrid
            // 
            this.ApproveDataGrid.Location = new System.Drawing.Point(0, 0);
            this.ApproveDataGrid.Name = "ApproveDataGrid";
            this.ApproveDataGrid.Size = new System.Drawing.Size(240, 150);
            this.ApproveDataGrid.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 0;
            // 
            // pnlCall
            // 
            this.pnlCall.BackColor = System.Drawing.Color.Transparent;
            this.pnlCall.Controls.Add(this.CalllblTimerMinutes);
            this.pnlCall.Controls.Add(this.label3);
            this.pnlCall.Controls.Add(this.CalllblClientName);
            this.pnlCall.Controls.Add(this.CallbtnCancel);
            this.pnlCall.Controls.Add(this.CallgroupCallHistory);
            this.pnlCall.Controls.Add(this.CalllblTimerSeconds);
            this.pnlCall.Controls.Add(this.CallCallServiceRequest);
            this.pnlCall.Controls.Add(this.CallgrpContactInfo);
            this.pnlCall.Controls.Add(this.CalllblHeading);
            this.pnlCall.Controls.Add(this.CallClose);
            this.pnlCall.Controls.Add(this.Callhelp);
            this.pnlCall.Location = new System.Drawing.Point(0, 0);
            this.pnlCall.Name = "pnlCall";
            this.pnlCall.Size = new System.Drawing.Size(1024, 648);
            this.pnlCall.TabIndex = 13;
            // 
            // CalllblTimerMinutes
            // 
            this.CalllblTimerMinutes.AutoSize = true;
            this.CalllblTimerMinutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalllblTimerMinutes.Location = new System.Drawing.Point(290, 59);
            this.CalllblTimerMinutes.Name = "CalllblTimerMinutes";
            this.CalllblTimerMinutes.Size = new System.Drawing.Size(193, 135);
            this.CalllblTimerMinutes.TabIndex = 36;
            this.CalllblTimerMinutes.Text = "00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(451, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 135);
            this.label3.TabIndex = 35;
            this.label3.Text = ":";
            // 
            // CalllblClientName
            // 
            this.CalllblClientName.AutoSize = true;
            this.CalllblClientName.Location = new System.Drawing.Point(380, 187);
            this.CalllblClientName.Name = "CalllblClientName";
            this.CalllblClientName.Size = new System.Drawing.Size(196, 30);
            this.CalllblClientName.TabIndex = 34;
            this.CalllblClientName.Text = "CLIENT FULL NAME";
            // 
            // CallbtnCancel
            // 
            this.CallbtnCancel.Image = global::Presentation.Properties.Resources.RejectCall;
            this.CallbtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CallbtnCancel.Location = new System.Drawing.Point(399, 582);
            this.CallbtnCancel.Name = "CallbtnCancel";
            this.CallbtnCancel.Size = new System.Drawing.Size(210, 49);
            this.CallbtnCancel.TabIndex = 28;
            this.CallbtnCancel.Text = "Cancel Call";
            this.CallbtnCancel.UseVisualStyleBackColor = true;
            this.CallbtnCancel.Click += new System.EventHandler(this.CallbtnCancel_Click);
            // 
            // CallgroupCallHistory
            // 
            this.CallgroupCallHistory.BackColor = System.Drawing.Color.Gainsboro;
            this.CallgroupCallHistory.Controls.Add(this.dtvCallHistory);
            this.CallgroupCallHistory.Location = new System.Drawing.Point(521, 220);
            this.CallgroupCallHistory.Name = "CallgroupCallHistory";
            this.CallgroupCallHistory.Size = new System.Drawing.Size(503, 182);
            this.CallgroupCallHistory.TabIndex = 30;
            this.CallgroupCallHistory.TabStop = false;
            this.CallgroupCallHistory.Text = "CALL HISTORY";
            // 
            // dtvCallHistory
            // 
            this.dtvCallHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtvCallHistory.Location = new System.Drawing.Point(17, 34);
            this.dtvCallHistory.Name = "dtvCallHistory";
            this.dtvCallHistory.Size = new System.Drawing.Size(413, 129);
            this.dtvCallHistory.TabIndex = 0;
            // 
            // CalllblTimerSeconds
            // 
            this.CalllblTimerSeconds.AutoSize = true;
            this.CalllblTimerSeconds.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalllblTimerSeconds.Location = new System.Drawing.Point(515, 59);
            this.CalllblTimerSeconds.Name = "CalllblTimerSeconds";
            this.CalllblTimerSeconds.Size = new System.Drawing.Size(193, 135);
            this.CalllblTimerSeconds.TabIndex = 33;
            this.CalllblTimerSeconds.Text = "00";
            // 
            // CallCallServiceRequest
            // 
            this.CallCallServiceRequest.BackColor = System.Drawing.Color.Gainsboro;
            this.CallCallServiceRequest.Controls.Add(this.CallcmbService);
            this.CallCallServiceRequest.Controls.Add(this.CalllblService);
            this.CallCallServiceRequest.Controls.Add(this.CallCallbtnSendRequest);
            this.CallCallServiceRequest.Location = new System.Drawing.Point(0, 408);
            this.CallCallServiceRequest.Name = "CallCallServiceRequest";
            this.CallCallServiceRequest.Size = new System.Drawing.Size(1024, 168);
            this.CallCallServiceRequest.TabIndex = 31;
            this.CallCallServiceRequest.TabStop = false;
            this.CallCallServiceRequest.Text = "SERVICE REQUEST";
            // 
            // CallcmbService
            // 
            this.CallcmbService.FormattingEnabled = true;
            this.CallcmbService.Location = new System.Drawing.Point(260, 41);
            this.CallcmbService.Name = "CallcmbService";
            this.CallcmbService.Size = new System.Drawing.Size(468, 38);
            this.CallcmbService.TabIndex = 11;
            // 
            // CalllblService
            // 
            this.CalllblService.AutoSize = true;
            this.CalllblService.Location = new System.Drawing.Point(45, 44);
            this.CalllblService.Name = "CalllblService";
            this.CalllblService.Size = new System.Drawing.Size(163, 30);
            this.CalllblService.TabIndex = 6;
            this.CalllblService.Text = "Service Request:";
            // 
            // CallCallbtnSendRequest
            // 
            this.CallCallbtnSendRequest.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.CallCallbtnSendRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CallCallbtnSendRequest.Location = new System.Drawing.Point(399, 102);
            this.CallCallbtnSendRequest.Name = "CallCallbtnSendRequest";
            this.CallCallbtnSendRequest.Size = new System.Drawing.Size(210, 49);
            this.CallCallbtnSendRequest.TabIndex = 1;
            this.CallCallbtnSendRequest.Text = "Send Request";
            this.CallCallbtnSendRequest.UseVisualStyleBackColor = true;
            // 
            // CallgrpContactInfo
            // 
            this.CallgrpContactInfo.BackColor = System.Drawing.Color.Gainsboro;
            this.CallgrpContactInfo.Controls.Add(this.txtEmd);
            this.CallgrpContactInfo.Controls.Add(this.txtPackage);
            this.CallgrpContactInfo.Controls.Add(this.txtStart);
            this.CallgrpContactInfo.Controls.Add(this.txtlevel);
            this.CallgrpContactInfo.Controls.Add(this.label8);
            this.CallgrpContactInfo.Controls.Add(this.label7);
            this.CallgrpContactInfo.Controls.Add(this.label6);
            this.CallgrpContactInfo.Controls.Add(this.label4);
            this.CallgrpContactInfo.Location = new System.Drawing.Point(0, 220);
            this.CallgrpContactInfo.Name = "CallgrpContactInfo";
            this.CallgrpContactInfo.Size = new System.Drawing.Size(515, 182);
            this.CallgrpContactInfo.TabIndex = 29;
            this.CallgrpContactInfo.TabStop = false;
            this.CallgrpContactInfo.Text = "CONTRACT INFO";
            // 
            // txtEmd
            // 
            this.txtEmd.Enabled = false;
            this.txtEmd.Location = new System.Drawing.Point(342, 120);
            this.txtEmd.Name = "txtEmd";
            this.txtEmd.Size = new System.Drawing.Size(167, 35);
            this.txtEmd.TabIndex = 7;
            // 
            // txtPackage
            // 
            this.txtPackage.Enabled = false;
            this.txtPackage.Location = new System.Drawing.Point(342, 44);
            this.txtPackage.Name = "txtPackage";
            this.txtPackage.Size = new System.Drawing.Size(167, 35);
            this.txtPackage.TabIndex = 6;
            // 
            // txtStart
            // 
            this.txtStart.Enabled = false;
            this.txtStart.Location = new System.Drawing.Point(85, 120);
            this.txtStart.Name = "txtStart";
            this.txtStart.Size = new System.Drawing.Size(173, 35);
            this.txtStart.TabIndex = 5;
            // 
            // txtlevel
            // 
            this.txtlevel.Enabled = false;
            this.txtlevel.Location = new System.Drawing.Point(86, 47);
            this.txtlevel.Name = "txtlevel";
            this.txtlevel.Size = new System.Drawing.Size(173, 35);
            this.txtlevel.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 30);
            this.label8.TabIndex = 3;
            this.label8.Text = "Start:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(268, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 30);
            this.label7.TabIndex = 2;
            this.label7.Text = "End:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(255, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 30);
            this.label6.TabIndex = 1;
            this.label6.Text = "Package:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 30);
            this.label4.TabIndex = 0;
            this.label4.Text = "Level:";
            // 
            // CalllblHeading
            // 
            this.CalllblHeading.AutoSize = true;
            this.CalllblHeading.Location = new System.Drawing.Point(469, 29);
            this.CalllblHeading.Name = "CalllblHeading";
            this.CalllblHeading.Size = new System.Drawing.Size(60, 30);
            this.CalllblHeading.TabIndex = 27;
            this.CalllblHeading.Text = "CALL";
            // 
            // CallClose
            // 
            this.CallClose.Image = global::Presentation.Properties.Resources.close;
            this.CallClose.Location = new System.Drawing.Point(934, 29);
            this.CallClose.Name = "CallClose";
            this.CallClose.Size = new System.Drawing.Size(36, 36);
            this.CallClose.TabIndex = 9;
            this.CallClose.TabStop = false;
            this.CallClose.Click += new System.EventHandler(this.CallClose_Click);
            // 
            // Callhelp
            // 
            this.Callhelp.Image = global::Presentation.Properties.Resources.help_icon;
            this.Callhelp.Location = new System.Drawing.Point(878, 29);
            this.Callhelp.Name = "Callhelp";
            this.Callhelp.Size = new System.Drawing.Size(36, 36);
            this.Callhelp.TabIndex = 8;
            this.Callhelp.TabStop = false;
            this.Callhelp.Click += new System.EventHandler(this.Callhelp_Click);
            // 
            // Call
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.pnlCall);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "Call";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pbExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ApproveDataGrid)).EndInit();
            this.pnlCall.ResumeLayout(false);
            this.pnlCall.PerformLayout();
            this.CallgroupCallHistory.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtvCallHistory)).EndInit();
            this.CallCallServiceRequest.ResumeLayout(false);
            this.CallCallServiceRequest.PerformLayout();
            this.CallgrpContactInfo.ResumeLayout(false);
            this.CallgrpContactInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CallClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Callhelp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbExit;
        private System.Windows.Forms.PictureBox pbHome;
        private System.Windows.Forms.Panel pnlRightMain;
        private System.Windows.Forms.PictureBox pbLogout;
        private System.Windows.Forms.Button ApprovebtnDeny;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ApprovebtnApprove;
        private System.Windows.Forms.TextBox ApprovetxtLName;
        private System.Windows.Forms.TextBox ApprovetxtFName;
        private System.Windows.Forms.DataGridView ApproveDataGrid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlCall;
        private System.Windows.Forms.PictureBox CallClose;
        private System.Windows.Forms.PictureBox Callhelp;
        private System.Windows.Forms.Label CalllblClientName;
        private System.Windows.Forms.Button CallbtnCancel;
        private System.Windows.Forms.GroupBox CallgroupCallHistory;
        private System.Windows.Forms.Label CalllblTimerSeconds;
        private System.Windows.Forms.GroupBox CallCallServiceRequest;
        private System.Windows.Forms.ComboBox CallcmbService;
        private System.Windows.Forms.Label CalllblService;
        private System.Windows.Forms.Button CallCallbtnSendRequest;
        private System.Windows.Forms.GroupBox CallgrpContactInfo;
        private System.Windows.Forms.Label CalllblHeading;
        private System.Windows.Forms.Label CalllblTimerMinutes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtEmd;
        private System.Windows.Forms.TextBox txtPackage;
        private System.Windows.Forms.TextBox txtStart;
        private System.Windows.Forms.TextBox txtlevel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dtvCallHistory;
    }
}