﻿namespace Presentation
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {       
            this.ClienContab = new System.Windows.Forms.TabControl();
            this.TbUsers = new System.Windows.Forms.TabPage();
            this.UserstxtBuildingNumber = new System.Windows.Forms.TextBox();
            this.UserslblBuidingNumber = new System.Windows.Forms.Label();
            this.UserstxtProvince = new System.Windows.Forms.TextBox();
            this.UserslbProvince = new System.Windows.Forms.Label();
            this.UserstxtFaxNumber = new System.Windows.Forms.TextBox();
            this.UserslblFax = new System.Windows.Forms.Label();
            this.UserstxtEmail = new System.Windows.Forms.TextBox();
            this.Userslblemail = new System.Windows.Forms.Label();
            this.UserstxtPhoneNumber = new System.Windows.Forms.TextBox();
            this.Userslblphone = new System.Windows.Forms.Label();
            this.UserstxtTelNumber = new System.Windows.Forms.TextBox();
            this.Userslbltel = new System.Windows.Forms.Label();
            this.UserstxtCountry = new System.Windows.Forms.TextBox();
            this.UserstxtPostalCode = new System.Windows.Forms.TextBox();
            this.Userslblcountry = new System.Windows.Forms.Label();
            this.Userslblpostal = new System.Windows.Forms.Label();
            this.UserstxtCity = new System.Windows.Forms.TextBox();
            this.UserstxtStreetName = new System.Windows.Forms.TextBox();
            this.Userslblcity = new System.Windows.Forms.Label();
            this.Userslblstreet = new System.Windows.Forms.Label();
            this.UsersbtnCancel = new System.Windows.Forms.Button();
            this.UsersDatePicker = new System.Windows.Forms.DateTimePicker();
            this.UsersTxtFirstName = new System.Windows.Forms.TextBox();
            this.Userslblfname = new System.Windows.Forms.Label();
            this.UsersTxtSurname = new System.Windows.Forms.TextBox();
            this.Userslblsname = new System.Windows.Forms.Label();
            this.Userslbldob = new System.Windows.Forms.Label();
            this.UserbtnEdit = new System.Windows.Forms.Button();
            this.UserbtnAdd = new System.Windows.Forms.Button();
            this.UserbtnSave = new System.Windows.Forms.Button();
            this.UsersbtnDelete = new System.Windows.Forms.Button();
            this.UsersTxtUsername = new System.Windows.Forms.TextBox();
            this.UserslblUsername = new System.Windows.Forms.Label();
            this.UsersbtnUpdate = new System.Windows.Forms.Button();
            this.UsersCmbDepartment = new System.Windows.Forms.ComboBox();
            this.UserstxtPassword = new System.Windows.Forms.TextBox();
            this.UserslblDepartment = new System.Windows.Forms.Label();
            this.UserslblPassword = new System.Windows.Forms.Label();
            this.ContactClientbtnLogout = new System.Windows.Forms.Button();
            this.UsersCmbUsers = new System.Windows.Forms.ComboBox();
            this.UserslblClient = new System.Windows.Forms.Label();
            this.UsersCLose = new System.Windows.Forms.PictureBox();
            this.UsersHelp = new System.Windows.Forms.PictureBox();
            this.ClienContab.SuspendLayout();
            this.TbUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UsersCLose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UsersHelp)).BeginInit();
            this.SuspendLayout();
            // 
            // ClienContab
            // 
            this.ClienContab.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.ClienContab.Controls.Add(this.TbUsers);
            this.ClienContab.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.ClienContab.ItemSize = new System.Drawing.Size(50, 200);
            this.ClienContab.Location = new System.Drawing.Point(0, 2);
            this.ClienContab.Multiline = true;
            this.ClienContab.Name = "ClienContab";
            this.ClienContab.SelectedIndex = 0;
            this.ClienContab.Size = new System.Drawing.Size(1024, 645);
            this.ClienContab.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.ClienContab.TabIndex = 21;
            // 
            // TbUsers
            // 
            this.TbUsers.Controls.Add(this.UserstxtBuildingNumber);
            this.TbUsers.Controls.Add(this.UserslblBuidingNumber);
            this.TbUsers.Controls.Add(this.UserstxtProvince);
            this.TbUsers.Controls.Add(this.UserslbProvince);
            this.TbUsers.Controls.Add(this.UserstxtFaxNumber);
            this.TbUsers.Controls.Add(this.UserslblFax);
            this.TbUsers.Controls.Add(this.UserstxtEmail);
            this.TbUsers.Controls.Add(this.Userslblemail);
            this.TbUsers.Controls.Add(this.UserstxtPhoneNumber);
            this.TbUsers.Controls.Add(this.Userslblphone);
            this.TbUsers.Controls.Add(this.UserstxtTelNumber);
            this.TbUsers.Controls.Add(this.Userslbltel);
            this.TbUsers.Controls.Add(this.UserstxtCountry);
            this.TbUsers.Controls.Add(this.UserstxtPostalCode);
            this.TbUsers.Controls.Add(this.Userslblcountry);
            this.TbUsers.Controls.Add(this.Userslblpostal);
            this.TbUsers.Controls.Add(this.UserstxtCity);
            this.TbUsers.Controls.Add(this.UserstxtStreetName);
            this.TbUsers.Controls.Add(this.Userslblcity);
            this.TbUsers.Controls.Add(this.Userslblstreet);
            this.TbUsers.Controls.Add(this.UsersbtnCancel);
            this.TbUsers.Controls.Add(this.UsersDatePicker);
            this.TbUsers.Controls.Add(this.UsersTxtFirstName);
            this.TbUsers.Controls.Add(this.Userslblfname);
            this.TbUsers.Controls.Add(this.UsersTxtSurname);
            this.TbUsers.Controls.Add(this.Userslblsname);
            this.TbUsers.Controls.Add(this.Userslbldob);
            this.TbUsers.Controls.Add(this.UserbtnEdit);
            this.TbUsers.Controls.Add(this.UserbtnAdd);
            this.TbUsers.Controls.Add(this.UserbtnSave);
            this.TbUsers.Controls.Add(this.UsersbtnDelete);
            this.TbUsers.Controls.Add(this.UsersTxtUsername);
            this.TbUsers.Controls.Add(this.UserslblUsername);
            this.TbUsers.Controls.Add(this.UsersbtnUpdate);
            this.TbUsers.Controls.Add(this.UsersCmbDepartment);
            this.TbUsers.Controls.Add(this.UserstxtPassword);
            this.TbUsers.Controls.Add(this.UserslblDepartment);
            this.TbUsers.Controls.Add(this.UserslblPassword);
            this.TbUsers.Controls.Add(this.ContactClientbtnLogout);
            this.TbUsers.Controls.Add(this.UsersCmbUsers);
            this.TbUsers.Controls.Add(this.UserslblClient);
            this.TbUsers.Controls.Add(this.UsersCLose);
            this.TbUsers.Controls.Add(this.UsersHelp);
            this.TbUsers.Location = new System.Drawing.Point(204, 4);
            this.TbUsers.Name = "TbUsers";
            this.TbUsers.Padding = new System.Windows.Forms.Padding(3);
            this.TbUsers.Size = new System.Drawing.Size(816, 637);
            this.TbUsers.TabIndex = 0;
            this.TbUsers.Text = "Users";
            this.TbUsers.UseVisualStyleBackColor = true;
            // 
            // UserstxtBuildingNumber
            // 
            this.UserstxtBuildingNumber.Location = new System.Drawing.Point(581, 474);
            this.UserstxtBuildingNumber.Name = "UserstxtBuildingNumber";
            this.UserstxtBuildingNumber.Size = new System.Drawing.Size(231, 35);
            this.UserstxtBuildingNumber.TabIndex = 112;
            this.UserstxtBuildingNumber.Visible = false;
            // 
            // UserslblBuidingNumber
            // 
            this.UserslblBuidingNumber.AutoSize = true;
            this.UserslblBuidingNumber.Location = new System.Drawing.Point(408, 474);
            this.UserslblBuidingNumber.Name = "UserslblBuidingNumber";
            this.UserslblBuidingNumber.Size = new System.Drawing.Size(175, 30);
            this.UserslblBuidingNumber.TabIndex = 111;
            this.UserslblBuidingNumber.Text = "Building Number:";
            this.UserslblBuidingNumber.Visible = false;
            // 
            // UserstxtProvince
            // 
            this.UserstxtProvince.Location = new System.Drawing.Point(154, 486);
            this.UserstxtProvince.Name = "UserstxtProvince";
            this.UserstxtProvince.Size = new System.Drawing.Size(248, 35);
            this.UserstxtProvince.TabIndex = 110;
            this.UserstxtProvince.Visible = false;
            // 
            // UserslbProvince
            // 
            this.UserslbProvince.AutoSize = true;
            this.UserslbProvince.Location = new System.Drawing.Point(18, 489);
            this.UserslbProvince.Name = "UserslbProvince";
            this.UserslbProvince.Size = new System.Drawing.Size(97, 30);
            this.UserslbProvince.TabIndex = 109;
            this.UserslbProvince.Text = "Province:";
            this.UserslbProvince.Visible = false;
            // 
            // UserstxtFaxNumber
            // 
            this.UserstxtFaxNumber.Location = new System.Drawing.Point(154, 443);
            this.UserstxtFaxNumber.Name = "UserstxtFaxNumber";
            this.UserstxtFaxNumber.Size = new System.Drawing.Size(247, 35);
            this.UserstxtFaxNumber.TabIndex = 108;
            this.UserstxtFaxNumber.Visible = false;
            // 
            // UserslblFax
            // 
            this.UserslblFax.AutoSize = true;
            this.UserslblFax.Location = new System.Drawing.Point(18, 446);
            this.UserslblFax.Name = "UserslblFax";
            this.UserslblFax.Size = new System.Drawing.Size(130, 30);
            this.UserslblFax.TabIndex = 107;
            this.UserslblFax.Text = "Fax Number:";
            this.UserslblFax.Visible = false;
            // 
            // UserstxtEmail
            // 
            this.UserstxtEmail.Location = new System.Drawing.Point(581, 312);
            this.UserstxtEmail.Name = "UserstxtEmail";
            this.UserstxtEmail.Size = new System.Drawing.Size(231, 35);
            this.UserstxtEmail.TabIndex = 106;
            this.UserstxtEmail.Visible = false;
            // 
            // Userslblemail
            // 
            this.Userslblemail.AutoSize = true;
            this.Userslblemail.Location = new System.Drawing.Point(407, 312);
            this.Userslblemail.Name = "Userslblemail";
            this.Userslblemail.Size = new System.Drawing.Size(68, 30);
            this.Userslblemail.TabIndex = 105;
            this.Userslblemail.Text = "Email:";
            this.Userslblemail.Visible = false;
            // 
            // UserstxtPhoneNumber
            // 
            this.UserstxtPhoneNumber.Location = new System.Drawing.Point(581, 433);
            this.UserstxtPhoneNumber.Name = "UserstxtPhoneNumber";
            this.UserstxtPhoneNumber.Size = new System.Drawing.Size(231, 35);
            this.UserstxtPhoneNumber.TabIndex = 104;
            this.UserstxtPhoneNumber.Visible = false;
            // 
            // Userslblphone
            // 
            this.Userslblphone.AutoSize = true;
            this.Userslblphone.Location = new System.Drawing.Point(407, 439);
            this.Userslblphone.Name = "Userslblphone";
            this.Userslblphone.Size = new System.Drawing.Size(159, 30);
            this.Userslblphone.TabIndex = 103;
            this.Userslblphone.Text = "Phone Number:";
            this.Userslblphone.Visible = false;
            // 
            // UserstxtTelNumber
            // 
            this.UserstxtTelNumber.Location = new System.Drawing.Point(581, 394);
            this.UserstxtTelNumber.Name = "UserstxtTelNumber";
            this.UserstxtTelNumber.Size = new System.Drawing.Size(231, 35);
            this.UserstxtTelNumber.TabIndex = 102;
            this.UserstxtTelNumber.Visible = false;
            // 
            // Userslbltel
            // 
            this.Userslbltel.AutoSize = true;
            this.Userslbltel.Location = new System.Drawing.Point(406, 394);
            this.Userslbltel.Name = "Userslbltel";
            this.Userslbltel.Size = new System.Drawing.Size(125, 30);
            this.Userslbltel.TabIndex = 101;
            this.Userslbltel.Text = "Tel Number:";
            this.Userslbltel.Visible = false;
            // 
            // UserstxtCountry
            // 
            this.UserstxtCountry.Location = new System.Drawing.Point(581, 274);
            this.UserstxtCountry.Name = "UserstxtCountry";
            this.UserstxtCountry.Size = new System.Drawing.Size(231, 35);
            this.UserstxtCountry.TabIndex = 100;
            this.UserstxtCountry.Visible = false;
            // 
            // UserstxtPostalCode
            // 
            this.UserstxtPostalCode.Location = new System.Drawing.Point(581, 353);
            this.UserstxtPostalCode.Name = "UserstxtPostalCode";
            this.UserstxtPostalCode.Size = new System.Drawing.Size(231, 35);
            this.UserstxtPostalCode.TabIndex = 99;
            this.UserstxtPostalCode.Visible = false;
            // 
            // Userslblcountry
            // 
            this.Userslblcountry.AutoSize = true;
            this.Userslblcountry.Location = new System.Drawing.Point(407, 274);
            this.Userslblcountry.Name = "Userslblcountry";
            this.Userslblcountry.Size = new System.Drawing.Size(91, 30);
            this.Userslblcountry.TabIndex = 97;
            this.Userslblcountry.Text = "Country:";
            this.Userslblcountry.Visible = false;
            // 
            // Userslblpostal
            // 
            this.Userslblpostal.AutoSize = true;
            this.Userslblpostal.Location = new System.Drawing.Point(406, 355);
            this.Userslblpostal.Name = "Userslblpostal";
            this.Userslblpostal.Size = new System.Drawing.Size(127, 30);
            this.Userslblpostal.TabIndex = 98;
            this.Userslblpostal.Text = "Postal Code:";
            this.Userslblpostal.Visible = false;
            // 
            // UserstxtCity
            // 
            this.UserstxtCity.Location = new System.Drawing.Point(581, 233);
            this.UserstxtCity.Name = "UserstxtCity";
            this.UserstxtCity.Size = new System.Drawing.Size(231, 35);
            this.UserstxtCity.TabIndex = 96;
            this.UserstxtCity.Visible = false;
            // 
            // UserstxtStreetName
            // 
            this.UserstxtStreetName.Location = new System.Drawing.Point(581, 192);
            this.UserstxtStreetName.Name = "UserstxtStreetName";
            this.UserstxtStreetName.Size = new System.Drawing.Size(231, 35);
            this.UserstxtStreetName.TabIndex = 95;
            this.UserstxtStreetName.Visible = false;
            // 
            // Userslblcity
            // 
            this.Userslblcity.AutoSize = true;
            this.Userslblcity.Location = new System.Drawing.Point(407, 233);
            this.Userslblcity.Name = "Userslblcity";
            this.Userslblcity.Size = new System.Drawing.Size(53, 30);
            this.Userslblcity.TabIndex = 93;
            this.Userslblcity.Text = "City:";
            this.Userslblcity.Visible = false;
            // 
            // Userslblstreet
            // 
            this.Userslblstreet.AutoSize = true;
            this.Userslblstreet.Location = new System.Drawing.Point(407, 189);
            this.Userslblstreet.Name = "Userslblstreet";
            this.Userslblstreet.Size = new System.Drawing.Size(133, 30);
            this.Userslblstreet.TabIndex = 94;
            this.Userslblstreet.Text = "Street Name:";
            this.Userslblstreet.Visible = false;
            // 
            // UsersbtnCancel
            // 
            this.UsersbtnCancel.Image = global::Presentation.Properties.Resources.delete_icon;
            this.UsersbtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UsersbtnCancel.Location = new System.Drawing.Point(434, 584);
            this.UsersbtnCancel.Name = "UsersbtnCancel";
            this.UsersbtnCancel.Size = new System.Drawing.Size(141, 44);
            this.UsersbtnCancel.TabIndex = 92;
            this.UsersbtnCancel.Text = "Cancel";
            this.UsersbtnCancel.UseVisualStyleBackColor = true;
            this.UsersbtnCancel.Visible = false;
            this.UsersbtnCancel.Click += new System.EventHandler(this.UsersbtnCancel_Click);
            // 
            // UsersDatePicker
            // 
            this.UsersDatePicker.Location = new System.Drawing.Point(154, 274);
            this.UsersDatePicker.Name = "UsersDatePicker";
            this.UsersDatePicker.Size = new System.Drawing.Size(248, 35);
            this.UsersDatePicker.TabIndex = 91;
            this.UsersDatePicker.Visible = false;
            // 
            // UsersTxtFirstName
            // 
            this.UsersTxtFirstName.Location = new System.Drawing.Point(154, 192);
            this.UsersTxtFirstName.Name = "UsersTxtFirstName";
            this.UsersTxtFirstName.Size = new System.Drawing.Size(248, 35);
            this.UsersTxtFirstName.TabIndex = 90;
            this.UsersTxtFirstName.Visible = false;
            // 
            // Userslblfname
            // 
            this.Userslblfname.AutoSize = true;
            this.Userslblfname.Location = new System.Drawing.Point(22, 197);
            this.Userslblfname.Name = "Userslblfname";
            this.Userslblfname.Size = new System.Drawing.Size(114, 30);
            this.Userslblfname.TabIndex = 89;
            this.Userslblfname.Text = "First name:";
            this.Userslblfname.Visible = false;
            // 
            // UsersTxtSurname
            // 
            this.UsersTxtSurname.Location = new System.Drawing.Point(154, 233);
            this.UsersTxtSurname.Name = "UsersTxtSurname";
            this.UsersTxtSurname.Size = new System.Drawing.Size(248, 35);
            this.UsersTxtSurname.TabIndex = 88;
            this.UsersTxtSurname.Visible = false;
            // 
            // Userslblsname
            // 
            this.Userslblsname.AutoSize = true;
            this.Userslblsname.Location = new System.Drawing.Point(22, 238);
            this.Userslblsname.Name = "Userslblsname";
            this.Userslblsname.Size = new System.Drawing.Size(100, 30);
            this.Userslblsname.TabIndex = 87;
            this.Userslblsname.Text = "Surname:";
            this.Userslblsname.Visible = false;
            // 
            // Userslbldob
            // 
            this.Userslbldob.AutoSize = true;
            this.Userslbldob.Location = new System.Drawing.Point(22, 278);
            this.Userslbldob.Name = "Userslbldob";
            this.Userslbldob.Size = new System.Drawing.Size(136, 30);
            this.Userslbldob.TabIndex = 85;
            this.Userslbldob.Text = "Date of birth:";
            this.Userslbldob.Visible = false;
            // 
            // UserbtnEdit
            // 
            this.UserbtnEdit.Location = new System.Drawing.Point(523, 54);
            this.UserbtnEdit.Name = "UserbtnEdit";
            this.UserbtnEdit.Size = new System.Drawing.Size(141, 44);
            this.UserbtnEdit.TabIndex = 84;
            this.UserbtnEdit.Text = "Edit User";
            this.UserbtnEdit.UseVisualStyleBackColor = true;
            this.UserbtnEdit.Click += new System.EventHandler(this.UserbtnEdit_Click);
            // 
            // UserbtnAdd
            // 
            this.UserbtnAdd.Location = new System.Drawing.Point(312, 114);
            this.UserbtnAdd.Name = "UserbtnAdd";
            this.UserbtnAdd.Size = new System.Drawing.Size(141, 44);
            this.UserbtnAdd.TabIndex = 83;
            this.UserbtnAdd.Text = "Add User";
            this.UserbtnAdd.UseVisualStyleBackColor = true;
            this.UserbtnAdd.Click += new System.EventHandler(this.UserbtnAdd_Click);
            // 
            // UserbtnSave
            // 
            this.UserbtnSave.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.UserbtnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UserbtnSave.Location = new System.Drawing.Point(243, 584);
            this.UserbtnSave.Name = "UserbtnSave";
            this.UserbtnSave.Size = new System.Drawing.Size(141, 44);
            this.UserbtnSave.TabIndex = 82;
            this.UserbtnSave.Text = "SAVE";
            this.UserbtnSave.UseVisualStyleBackColor = true;
            this.UserbtnSave.Visible = false;
            this.UserbtnSave.Click += new System.EventHandler(this.UserbtnSave_Click);
            // 
            // UsersbtnDelete
            // 
            this.UsersbtnDelete.Image = global::Presentation.Properties.Resources.delete_icon;
            this.UsersbtnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UsersbtnDelete.Location = new System.Drawing.Point(434, 584);
            this.UsersbtnDelete.Name = "UsersbtnDelete";
            this.UsersbtnDelete.Size = new System.Drawing.Size(141, 44);
            this.UsersbtnDelete.TabIndex = 80;
            this.UsersbtnDelete.Text = "Delete ";
            this.UsersbtnDelete.UseVisualStyleBackColor = true;
            this.UsersbtnDelete.Visible = false;
            this.UsersbtnDelete.Click += new System.EventHandler(this.UsersbtnDelete_Click);
            // 
            // UsersTxtUsername
            // 
            this.UsersTxtUsername.Location = new System.Drawing.Point(154, 315);
            this.UsersTxtUsername.Name = "UsersTxtUsername";
            this.UsersTxtUsername.Size = new System.Drawing.Size(248, 35);
            this.UsersTxtUsername.TabIndex = 79;
            this.UsersTxtUsername.Visible = false;
            // 
            // UserslblUsername
            // 
            this.UserslblUsername.AutoSize = true;
            this.UserslblUsername.Location = new System.Drawing.Point(22, 318);
            this.UserslblUsername.Name = "UserslblUsername";
            this.UserslblUsername.Size = new System.Drawing.Size(111, 30);
            this.UserslblUsername.TabIndex = 78;
            this.UserslblUsername.Text = "Username:";
            this.UserslblUsername.Visible = false;
            // 
            // UsersbtnUpdate
            // 
            this.UsersbtnUpdate.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.UsersbtnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UsersbtnUpdate.Location = new System.Drawing.Point(243, 584);
            this.UsersbtnUpdate.Name = "UsersbtnUpdate";
            this.UsersbtnUpdate.Size = new System.Drawing.Size(141, 44);
            this.UsersbtnUpdate.TabIndex = 75;
            this.UsersbtnUpdate.Text = "Update";
            this.UsersbtnUpdate.UseVisualStyleBackColor = true;
            this.UsersbtnUpdate.Visible = false;
            this.UsersbtnUpdate.Click += new System.EventHandler(this.UsersbtnUpdate_Click);
            // 
            // UsersCmbDepartment
            // 
            this.UsersCmbDepartment.FormattingEnabled = true;
            this.UsersCmbDepartment.Items.AddRange(new object[] {
            "Manager",
            "Call Centre",
            "Client Maintenance",
            "Contract Maintenance",
            "Service Department",
            "Client Satisfaction"});
            this.UsersCmbDepartment.Location = new System.Drawing.Point(154, 399);
            this.UsersCmbDepartment.Name = "UsersCmbDepartment";
            this.UsersCmbDepartment.Size = new System.Drawing.Size(248, 38);
            this.UsersCmbDepartment.TabIndex = 74;
            this.UsersCmbDepartment.Visible = false;
            // 
            // UserstxtPassword
            // 
            this.UserstxtPassword.Location = new System.Drawing.Point(154, 356);
            this.UserstxtPassword.Name = "UserstxtPassword";
            this.UserstxtPassword.PasswordChar = '*';
            this.UserstxtPassword.Size = new System.Drawing.Size(248, 35);
            this.UserstxtPassword.TabIndex = 73;
            this.UserstxtPassword.Visible = false;
            // 
            // UserslblDepartment
            // 
            this.UserslblDepartment.AutoSize = true;
            this.UserslblDepartment.Location = new System.Drawing.Point(19, 399);
            this.UserslblDepartment.Name = "UserslblDepartment";
            this.UserslblDepartment.Size = new System.Drawing.Size(129, 30);
            this.UserslblDepartment.TabIndex = 70;
            this.UserslblDepartment.Text = "Department:";
            this.UserslblDepartment.Visible = false;
            // 
            // UserslblPassword
            // 
            this.UserslblPassword.AutoSize = true;
            this.UserslblPassword.Location = new System.Drawing.Point(22, 356);
            this.UserslblPassword.Name = "UserslblPassword";
            this.UserslblPassword.Size = new System.Drawing.Size(104, 30);
            this.UserslblPassword.TabIndex = 69;
            this.UserslblPassword.Text = "Password:";
            this.UserslblPassword.Visible = false;
            // 
            // ContactClientbtnLogout
            // 
            this.ContactClientbtnLogout.Image = global::Presentation.Properties.Resources.logout;
            this.ContactClientbtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContactClientbtnLogout.Location = new System.Drawing.Point(616, 584);
            this.ContactClientbtnLogout.Name = "ContactClientbtnLogout";
            this.ContactClientbtnLogout.Size = new System.Drawing.Size(192, 46);
            this.ContactClientbtnLogout.TabIndex = 38;
            this.ContactClientbtnLogout.Text = "LOGOUT";
            this.ContactClientbtnLogout.UseVisualStyleBackColor = true;
            this.ContactClientbtnLogout.Click += new System.EventHandler(this.ContactClientbtnLogout_Click);
            // 
            // UsersCmbUsers
            // 
            this.UsersCmbUsers.FormattingEnabled = true;
            this.UsersCmbUsers.Location = new System.Drawing.Point(173, 58);
            this.UsersCmbUsers.Name = "UsersCmbUsers";
            this.UsersCmbUsers.Size = new System.Drawing.Size(314, 38);
            this.UsersCmbUsers.TabIndex = 20;
            // 
            // UserslblClient
            // 
            this.UserslblClient.AutoSize = true;
            this.UserslblClient.Location = new System.Drawing.Point(92, 61);
            this.UserslblClient.Name = "UserslblClient";
            this.UserslblClient.Size = new System.Drawing.Size(71, 30);
            this.UserslblClient.TabIndex = 19;
            this.UserslblClient.Text = "Client:";
            // 
            // UsersCLose
            // 
            this.UsersCLose.Image = global::Presentation.Properties.Resources.close;
            this.UsersCLose.Location = new System.Drawing.Point(774, 8);
            this.UsersCLose.Name = "UsersCLose";
            this.UsersCLose.Size = new System.Drawing.Size(34, 35);
            this.UsersCLose.TabIndex = 18;
            this.UsersCLose.TabStop = false;
            this.UsersCLose.Click += new System.EventHandler(this.ConClientCLose_Click);
            // 
            // UsersHelp
            // 
            this.UsersHelp.Image = global::Presentation.Properties.Resources.help_icon;
            this.UsersHelp.Location = new System.Drawing.Point(732, 8);
            this.UsersHelp.Name = "UsersHelp";
            this.UsersHelp.Size = new System.Drawing.Size(36, 35);
            this.UsersHelp.TabIndex = 17;
            this.UsersHelp.TabStop = false;
            this.UsersHelp.Click += new System.EventHandler(this.ConlientHelp_Click);
            // 
            // Users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.ClienContab);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "Users";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ClienContab.ResumeLayout(false);
            this.TbUsers.ResumeLayout(false);
            this.TbUsers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UsersCLose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UsersHelp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl ClienContab;
        private System.Windows.Forms.TabPage TbUsers;
        private System.Windows.Forms.ComboBox UsersCmbUsers;
        private System.Windows.Forms.Label UserslblClient;
        private System.Windows.Forms.PictureBox UsersCLose;
        private System.Windows.Forms.PictureBox UsersHelp;
        private System.Windows.Forms.Button ContactClientbtnLogout;
        private System.Windows.Forms.Button UsersbtnDelete;
        private System.Windows.Forms.Button UsersbtnUpdate;
        private System.Windows.Forms.ComboBox UsersCmbDepartment;
        private System.Windows.Forms.Label UserslblDepartment;
        private System.Windows.Forms.Button UserbtnEdit;
        private System.Windows.Forms.Button UserbtnAdd;
        private System.Windows.Forms.Button UserbtnSave;
        private System.Windows.Forms.DateTimePicker UsersDatePicker;
        private System.Windows.Forms.TextBox UsersTxtFirstName;
        private System.Windows.Forms.Label Userslblfname;
        private System.Windows.Forms.TextBox UsersTxtSurname;
        private System.Windows.Forms.Label Userslblsname;
        private System.Windows.Forms.Label Userslbldob;
        private System.Windows.Forms.TextBox UsersTxtUsername;
        private System.Windows.Forms.Label UserslblUsername;
        private System.Windows.Forms.TextBox UserstxtPassword;
        private System.Windows.Forms.Label UserslblPassword;
        private System.Windows.Forms.Button UsersbtnCancel;
        private System.Windows.Forms.TextBox UserstxtFaxNumber;
        private System.Windows.Forms.Label UserslblFax;
        private System.Windows.Forms.TextBox UserstxtEmail;
        private System.Windows.Forms.Label Userslblemail;
        private System.Windows.Forms.TextBox UserstxtPhoneNumber;
        private System.Windows.Forms.Label Userslblphone;
        private System.Windows.Forms.TextBox UserstxtTelNumber;
        private System.Windows.Forms.Label Userslbltel;
        private System.Windows.Forms.TextBox UserstxtCountry;
        private System.Windows.Forms.TextBox UserstxtPostalCode;
        private System.Windows.Forms.Label Userslblcountry;
        private System.Windows.Forms.Label Userslblpostal;
        private System.Windows.Forms.TextBox UserstxtCity;
        private System.Windows.Forms.TextBox UserstxtStreetName;
        private System.Windows.Forms.Label Userslblcity;
        private System.Windows.Forms.Label Userslblstreet;
        private System.Windows.Forms.TextBox UserstxtProvince;
        private System.Windows.Forms.Label UserslbProvince;
        private System.Windows.Forms.TextBox UserstxtBuildingNumber;
        private System.Windows.Forms.Label UserslblBuidingNumber;

        
    }
}