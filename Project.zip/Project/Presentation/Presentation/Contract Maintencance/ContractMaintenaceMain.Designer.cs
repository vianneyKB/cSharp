﻿namespace Presentation
{
    partial class ContractMaintenaceMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {       
            this.pnlTemplate = new System.Windows.Forms.Panel();
            this.ContrMainTab = new System.Windows.Forms.TabControl();
            this.TbPakages = new System.Windows.Forms.TabPage();
            this.packbtndelete = new System.Windows.Forms.Button();
            this.packbtnUpdate = new System.Windows.Forms.Button();
            this.packbtnCancel = new System.Windows.Forms.Button();
            this.packcmbService4 = new System.Windows.Forms.ComboBox();
            this.packblbservice4 = new System.Windows.Forms.Label();
            this.packcmbService2 = new System.Windows.Forms.ComboBox();
            this.packcmbService1 = new System.Windows.Forms.ComboBox();
            this.packcmbService3 = new System.Windows.Forms.ComboBox();
            this.packblbservice3 = new System.Windows.Forms.Label();
            this.packbtnadd = new System.Windows.Forms.Button();
            this.packbtnedit = new System.Windows.Forms.Button();
            this.contrMainbtnLogout2 = new System.Windows.Forms.Button();
            this.packcmblevel = new System.Windows.Forms.ComboBox();
            this.packtxtname = new System.Windows.Forms.TextBox();
            this.packblbservice2 = new System.Windows.Forms.Label();
            this.packblbservice1 = new System.Windows.Forms.Label();
            this.packblblevel = new System.Windows.Forms.Label();
            this.packblbname = new System.Windows.Forms.Label();
            this.packbtnSave = new System.Windows.Forms.Button();
            this.packcmbpa = new System.Windows.Forms.ComboBox();
            this.packblbpa = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ContrMainHelp2 = new System.Windows.Forms.PictureBox();
            this.TbServices = new System.Windows.Forms.TabPage();
            this.servbtndelete = new System.Windows.Forms.Button();
            this.servbtnupdate = new System.Windows.Forms.Button();
            this.servbtncancel = new System.Windows.Forms.Button();
            this.servbtnsave = new System.Windows.Forms.Button();
            this.servbtnaddserve = new System.Windows.Forms.Button();
            this.servbtneditserv = new System.Windows.Forms.Button();
            this.servcmbserve = new System.Windows.Forms.ComboBox();
            this.servlblServe = new System.Windows.Forms.Label();
            this.contrMainbtnLogut3 = new System.Windows.Forms.Button();
            this.servdescription = new System.Windows.Forms.TextBox();
            this.servcmbpriority = new System.Windows.Forms.ComboBox();
            this.servcmbduration = new System.Windows.Forms.ComboBox();
            this.servtxtname = new System.Windows.Forms.TextBox();
            this.servlblPriority = new System.Windows.Forms.Label();
            this.servlblduration = new System.Windows.Forms.Label();
            this.servlbldescription = new System.Windows.Forms.Label();
            this.servlblname = new System.Windows.Forms.Label();
            this.ContrMainClose3 = new System.Windows.Forms.PictureBox();
            this.ContrMainHelp3 = new System.Windows.Forms.PictureBox();
            this.TbEquipment = new System.Windows.Forms.TabPage();
            this.pnlTemplate.SuspendLayout();
            this.ContrMainTab.SuspendLayout();
            this.TbPakages.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ContrMainHelp2)).BeginInit();
            this.TbServices.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContrMainClose3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ContrMainHelp3)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTemplate
            // 
            this.pnlTemplate.BackColor = System.Drawing.Color.Transparent;
            this.pnlTemplate.Controls.Add(this.ContrMainTab);
            this.pnlTemplate.Location = new System.Drawing.Point(-1, -3);
            this.pnlTemplate.Name = "pnlTemplate";
            this.pnlTemplate.Size = new System.Drawing.Size(1026, 651);
            this.pnlTemplate.TabIndex = 14;
            // 
            // ContrMainTab
            // 
            this.ContrMainTab.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.ContrMainTab.Controls.Add(this.TbPakages);
            this.ContrMainTab.Controls.Add(this.TbServices);
            this.ContrMainTab.Controls.Add(this.TbEquipment);
            this.ContrMainTab.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.ContrMainTab.ItemSize = new System.Drawing.Size(50, 200);
            this.ContrMainTab.Location = new System.Drawing.Point(0, 2);
            this.ContrMainTab.Multiline = true;
            this.ContrMainTab.Name = "ContrMainTab";
            this.ContrMainTab.SelectedIndex = 0;
            this.ContrMainTab.Size = new System.Drawing.Size(1024, 645);
            this.ContrMainTab.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.ContrMainTab.TabIndex = 20;
            this.ContrMainTab.Selected += new System.Windows.Forms.TabControlEventHandler(this.ContrMainTab_Selected);
            // 
            // TbPakages
            // 
            this.TbPakages.Controls.Add(this.packbtndelete);
            this.TbPakages.Controls.Add(this.packbtnUpdate);
            this.TbPakages.Controls.Add(this.packbtnCancel);
            this.TbPakages.Controls.Add(this.packcmbService4);
            this.TbPakages.Controls.Add(this.packblbservice4);
            this.TbPakages.Controls.Add(this.packcmbService2);
            this.TbPakages.Controls.Add(this.packcmbService1);
            this.TbPakages.Controls.Add(this.packcmbService3);
            this.TbPakages.Controls.Add(this.packblbservice3);
            this.TbPakages.Controls.Add(this.packbtnadd);
            this.TbPakages.Controls.Add(this.packbtnedit);
            this.TbPakages.Controls.Add(this.contrMainbtnLogout2);
            this.TbPakages.Controls.Add(this.packcmblevel);
            this.TbPakages.Controls.Add(this.packtxtname);
            this.TbPakages.Controls.Add(this.packblbservice2);
            this.TbPakages.Controls.Add(this.packblbservice1);
            this.TbPakages.Controls.Add(this.packblblevel);
            this.TbPakages.Controls.Add(this.packblbname);
            this.TbPakages.Controls.Add(this.packbtnSave);
            this.TbPakages.Controls.Add(this.packcmbpa);
            this.TbPakages.Controls.Add(this.packblbpa);
            this.TbPakages.Controls.Add(this.pictureBox1);
            this.TbPakages.Controls.Add(this.ContrMainHelp2);
            this.TbPakages.Location = new System.Drawing.Point(204, 4);
            this.TbPakages.Name = "TbPakages";
            this.TbPakages.Padding = new System.Windows.Forms.Padding(3);
            this.TbPakages.Size = new System.Drawing.Size(816, 637);
            this.TbPakages.TabIndex = 1;
            this.TbPakages.Text = "Packages";
            this.TbPakages.UseVisualStyleBackColor = true;
            // 
            // packbtndelete
            // 
            this.packbtndelete.Image = global::Presentation.Properties.Resources.delete_icon;
            this.packbtndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.packbtndelete.Location = new System.Drawing.Point(445, 585);
            this.packbtndelete.Name = "packbtndelete";
            this.packbtndelete.Size = new System.Drawing.Size(148, 44);
            this.packbtndelete.TabIndex = 49;
            this.packbtndelete.Text = "DELETE";
            this.packbtndelete.UseVisualStyleBackColor = true;
            this.packbtndelete.Visible = false;
            // 
            // packbtnUpdate
            // 
            this.packbtnUpdate.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.packbtnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.packbtnUpdate.Location = new System.Drawing.Point(272, 585);
            this.packbtnUpdate.Name = "packbtnUpdate";
            this.packbtnUpdate.Size = new System.Drawing.Size(148, 44);
            this.packbtnUpdate.TabIndex = 48;
            this.packbtnUpdate.Text = "UPDATE";
            this.packbtnUpdate.UseVisualStyleBackColor = true;
            this.packbtnUpdate.Visible = false;
            // 
            // packbtnCancel
            // 
            this.packbtnCancel.Image = global::Presentation.Properties.Resources.delete_icon;
            this.packbtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.packbtnCancel.Location = new System.Drawing.Point(445, 585);
            this.packbtnCancel.Name = "packbtnCancel";
            this.packbtnCancel.Size = new System.Drawing.Size(148, 44);
            this.packbtnCancel.TabIndex = 47;
            this.packbtnCancel.Text = "CANCEL";
            this.packbtnCancel.UseVisualStyleBackColor = true;
            this.packbtnCancel.Visible = false;
            // 
            // packcmbService4
            // 
            this.packcmbService4.FormattingEnabled = true;
            this.packcmbService4.Location = new System.Drawing.Point(380, 526);
            this.packcmbService4.Name = "packcmbService4";
            this.packcmbService4.Size = new System.Drawing.Size(248, 38);
            this.packcmbService4.TabIndex = 46;
            this.packcmbService4.Visible = false;
            // 
            // packblbservice4
            // 
            this.packblbservice4.AutoSize = true;
            this.packblbservice4.Location = new System.Drawing.Point(244, 526);
            this.packblbservice4.Name = "packblbservice4";
            this.packblbservice4.Size = new System.Drawing.Size(100, 30);
            this.packblbservice4.TabIndex = 45;
            this.packblbservice4.Text = "Service 4:";
            this.packblbservice4.Visible = false;
            // 
            // packcmbService2
            // 
            this.packcmbService2.FormattingEnabled = true;
            this.packcmbService2.Location = new System.Drawing.Point(380, 399);
            this.packcmbService2.Name = "packcmbService2";
            this.packcmbService2.Size = new System.Drawing.Size(248, 38);
            this.packcmbService2.TabIndex = 44;
            this.packcmbService2.Visible = false;
            // 
            // packcmbService1
            // 
            this.packcmbService1.FormattingEnabled = true;
            this.packcmbService1.Location = new System.Drawing.Point(380, 338);
            this.packcmbService1.Name = "packcmbService1";
            this.packcmbService1.Size = new System.Drawing.Size(248, 38);
            this.packcmbService1.TabIndex = 43;
            this.packcmbService1.Visible = false;
            // 
            // packcmbService3
            // 
            this.packcmbService3.FormattingEnabled = true;
            this.packcmbService3.Location = new System.Drawing.Point(380, 467);
            this.packcmbService3.Name = "packcmbService3";
            this.packcmbService3.Size = new System.Drawing.Size(248, 38);
            this.packcmbService3.TabIndex = 42;
            this.packcmbService3.Visible = false;
            // 
            // packblbservice3
            // 
            this.packblbservice3.AutoSize = true;
            this.packblbservice3.Location = new System.Drawing.Point(244, 467);
            this.packblbservice3.Name = "packblbservice3";
            this.packblbservice3.Size = new System.Drawing.Size(100, 30);
            this.packblbservice3.TabIndex = 41;
            this.packblbservice3.Text = "Service 3:";
            this.packblbservice3.Visible = false;
            // 
            // packbtnadd
            // 
            this.packbtnadd.Location = new System.Drawing.Point(584, 93);
            this.packbtnadd.Name = "packbtnadd";
            this.packbtnadd.Size = new System.Drawing.Size(151, 38);
            this.packbtnadd.TabIndex = 40;
            this.packbtnadd.Text = "Add package";
            this.packbtnadd.UseVisualStyleBackColor = true;
            this.packbtnadd.Click += new System.EventHandler(this.packbtnadd_Click);
            // 
            // packbtnedit
            // 
            this.packbtnedit.Location = new System.Drawing.Point(426, 92);
            this.packbtnedit.Name = "packbtnedit";
            this.packbtnedit.Size = new System.Drawing.Size(140, 40);
            this.packbtnedit.TabIndex = 39;
            this.packbtnedit.Text = "Edit package";
            this.packbtnedit.UseVisualStyleBackColor = true;
            this.packbtnedit.Click += new System.EventHandler(this.packbtnedit_Click);
            // 
            // contrMainbtnLogout2
            // 
            this.contrMainbtnLogout2.Image = global::Presentation.Properties.Resources.logout;
            this.contrMainbtnLogout2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.contrMainbtnLogout2.Location = new System.Drawing.Point(616, 585);
            this.contrMainbtnLogout2.Name = "contrMainbtnLogout2";
            this.contrMainbtnLogout2.Size = new System.Drawing.Size(192, 46);
            this.contrMainbtnLogout2.TabIndex = 38;
            this.contrMainbtnLogout2.Text = "LOGOUT";
            this.contrMainbtnLogout2.UseVisualStyleBackColor = true;
            this.contrMainbtnLogout2.Click += new System.EventHandler(this.contrMainbtnLogout2_Click);
            // 
            // packcmblevel
            // 
            this.packcmblevel.FormattingEnabled = true;
            this.packcmblevel.Items.AddRange(new object[] {
            "Platinum",
            "Gold",
            "Silver",
            "Bronze"});
            this.packcmblevel.Location = new System.Drawing.Point(380, 278);
            this.packcmblevel.Name = "packcmblevel";
            this.packcmblevel.Size = new System.Drawing.Size(248, 38);
            this.packcmblevel.TabIndex = 35;
            this.packcmblevel.Visible = false;
            this.packcmblevel.SelectedIndexChanged += new System.EventHandler(this.packcmblevel_SelectedIndexChanged);
            // 
            // packtxtname
            // 
            this.packtxtname.Location = new System.Drawing.Point(380, 211);
            this.packtxtname.Name = "packtxtname";
            this.packtxtname.Size = new System.Drawing.Size(248, 35);
            this.packtxtname.TabIndex = 34;
            this.packtxtname.Visible = false;
            // 
            // packblbservice2
            // 
            this.packblbservice2.AutoSize = true;
            this.packblbservice2.Location = new System.Drawing.Point(244, 407);
            this.packblbservice2.Name = "packblbservice2";
            this.packblbservice2.Size = new System.Drawing.Size(100, 30);
            this.packblbservice2.TabIndex = 33;
            this.packblbservice2.Text = "Service 2:";
            this.packblbservice2.Visible = false;
            // 
            // packblbservice1
            // 
            this.packblbservice1.AutoSize = true;
            this.packblbservice1.Location = new System.Drawing.Point(244, 346);
            this.packblbservice1.Name = "packblbservice1";
            this.packblbservice1.Size = new System.Drawing.Size(100, 30);
            this.packblbservice1.TabIndex = 32;
            this.packblbservice1.Text = "Service 1:";
            this.packblbservice1.Visible = false;
            // 
            // packblblevel
            // 
            this.packblblevel.AutoSize = true;
            this.packblblevel.Location = new System.Drawing.Point(197, 281);
            this.packblblevel.Name = "packblblevel";
            this.packblblevel.Size = new System.Drawing.Size(147, 30);
            this.packblblevel.TabIndex = 31;
            this.packblblevel.Text = "Package Level:";
            this.packblblevel.Visible = false;
            // 
            // packblbname
            // 
            this.packblbname.AutoSize = true;
            this.packblbname.Location = new System.Drawing.Point(188, 211);
            this.packblbname.Name = "packblbname";
            this.packblbname.Size = new System.Drawing.Size(156, 30);
            this.packblbname.TabIndex = 30;
            this.packblbname.Text = "Package Name:";
            this.packblbname.Visible = false;
            // 
            // packbtnSave
            // 
            this.packbtnSave.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.packbtnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.packbtnSave.Location = new System.Drawing.Point(287, 585);
            this.packbtnSave.Name = "packbtnSave";
            this.packbtnSave.Size = new System.Drawing.Size(133, 44);
            this.packbtnSave.TabIndex = 29;
            this.packbtnSave.Text = "SAVE";
            this.packbtnSave.UseVisualStyleBackColor = true;
            this.packbtnSave.Visible = false;
            this.packbtnSave.Click += new System.EventHandler(this.packbtnSave_Click);
            // 
            // packcmbpa
            // 
            this.packcmbpa.FormattingEnabled = true;
            this.packcmbpa.Location = new System.Drawing.Point(106, 92);
            this.packcmbpa.Name = "packcmbpa";
            this.packcmbpa.Size = new System.Drawing.Size(314, 38);
            this.packcmbpa.TabIndex = 22;
            // 
            // packblbpa
            // 
            this.packblbpa.AutoSize = true;
            this.packblbpa.Location = new System.Drawing.Point(6, 94);
            this.packblbpa.Name = "packblbpa";
            this.packblbpa.Size = new System.Drawing.Size(94, 30);
            this.packblbpa.TabIndex = 21;
            this.packblbpa.Text = "Package:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Presentation.Properties.Resources.close;
            this.pictureBox1.Location = new System.Drawing.Point(774, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 35);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // ContrMainHelp2
            // 
            this.ContrMainHelp2.Image = global::Presentation.Properties.Resources.help_icon;
            this.ContrMainHelp2.Location = new System.Drawing.Point(732, 9);
            this.ContrMainHelp2.Name = "ContrMainHelp2";
            this.ContrMainHelp2.Size = new System.Drawing.Size(36, 35);
            this.ContrMainHelp2.TabIndex = 19;
            this.ContrMainHelp2.TabStop = false;
            this.ContrMainHelp2.Click += new System.EventHandler(this.ContrMainHelp2_Click);
            // 
            // TbServices
            // 
            this.TbServices.Controls.Add(this.servbtndelete);
            this.TbServices.Controls.Add(this.servbtnupdate);
            this.TbServices.Controls.Add(this.servbtncancel);
            this.TbServices.Controls.Add(this.servbtnsave);
            this.TbServices.Controls.Add(this.servbtnaddserve);
            this.TbServices.Controls.Add(this.servbtneditserv);
            this.TbServices.Controls.Add(this.servcmbserve);
            this.TbServices.Controls.Add(this.servlblServe);
            this.TbServices.Controls.Add(this.contrMainbtnLogut3);
            this.TbServices.Controls.Add(this.servdescription);
            this.TbServices.Controls.Add(this.servcmbpriority);
            this.TbServices.Controls.Add(this.servcmbduration);
            this.TbServices.Controls.Add(this.servtxtname);
            this.TbServices.Controls.Add(this.servlblPriority);
            this.TbServices.Controls.Add(this.servlblduration);
            this.TbServices.Controls.Add(this.servlbldescription);
            this.TbServices.Controls.Add(this.servlblname);
            this.TbServices.Controls.Add(this.ContrMainClose3);
            this.TbServices.Controls.Add(this.ContrMainHelp3);
            this.TbServices.Location = new System.Drawing.Point(204, 4);
            this.TbServices.Name = "TbServices";
            this.TbServices.Size = new System.Drawing.Size(816, 637);
            this.TbServices.TabIndex = 2;
            this.TbServices.Text = "Services";
            this.TbServices.UseVisualStyleBackColor = true;
            // 
            // servbtndelete
            // 
            this.servbtndelete.Image = global::Presentation.Properties.Resources.delete_icon;
            this.servbtndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.servbtndelete.Location = new System.Drawing.Point(420, 575);
            this.servbtndelete.Name = "servbtndelete";
            this.servbtndelete.Size = new System.Drawing.Size(145, 44);
            this.servbtndelete.TabIndex = 53;
            this.servbtndelete.Text = "DELETE";
            this.servbtndelete.UseVisualStyleBackColor = true;
            this.servbtndelete.Visible = false;
            this.servbtndelete.Click += new System.EventHandler(this.servbtndelete_Click);
            // 
            // servbtnupdate
            // 
            this.servbtnupdate.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.servbtnupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.servbtnupdate.Location = new System.Drawing.Point(247, 575);
            this.servbtnupdate.Name = "servbtnupdate";
            this.servbtnupdate.Size = new System.Drawing.Size(148, 44);
            this.servbtnupdate.TabIndex = 52;
            this.servbtnupdate.Text = "UPDATE";
            this.servbtnupdate.UseVisualStyleBackColor = true;
            this.servbtnupdate.Visible = false;
            this.servbtnupdate.Click += new System.EventHandler(this.servbtnupdate_Click);
            // 
            // servbtncancel
            // 
            this.servbtncancel.Image = global::Presentation.Properties.Resources.delete_icon;
            this.servbtncancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.servbtncancel.Location = new System.Drawing.Point(420, 575);
            this.servbtncancel.Name = "servbtncancel";
            this.servbtncancel.Size = new System.Drawing.Size(145, 44);
            this.servbtncancel.TabIndex = 51;
            this.servbtncancel.Text = "CANCEL";
            this.servbtncancel.UseVisualStyleBackColor = true;
            this.servbtncancel.Visible = false;
            this.servbtncancel.Click += new System.EventHandler(this.servbtncancel_Click);
            // 
            // servbtnsave
            // 
            this.servbtnsave.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.servbtnsave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.servbtnsave.Location = new System.Drawing.Point(262, 575);
            this.servbtnsave.Name = "servbtnsave";
            this.servbtnsave.Size = new System.Drawing.Size(133, 44);
            this.servbtnsave.TabIndex = 50;
            this.servbtnsave.Text = "SAVE";
            this.servbtnsave.UseVisualStyleBackColor = true;
            this.servbtnsave.Visible = false;
            this.servbtnsave.Click += new System.EventHandler(this.servbtnsave_Click);
            // 
            // servbtnaddserve
            // 
            this.servbtnaddserve.Location = new System.Drawing.Point(610, 110);
            this.servbtnaddserve.Name = "servbtnaddserve";
            this.servbtnaddserve.Size = new System.Drawing.Size(151, 38);
            this.servbtnaddserve.TabIndex = 47;
            this.servbtnaddserve.Text = "Add service";
            this.servbtnaddserve.UseVisualStyleBackColor = true;
            this.servbtnaddserve.Click += new System.EventHandler(this.servbtnaddserve_Click);
            // 
            // servbtneditserv
            // 
            this.servbtneditserv.Location = new System.Drawing.Point(452, 109);
            this.servbtneditserv.Name = "servbtneditserv";
            this.servbtneditserv.Size = new System.Drawing.Size(140, 40);
            this.servbtneditserv.TabIndex = 46;
            this.servbtneditserv.Text = "Edit service";
            this.servbtneditserv.UseVisualStyleBackColor = true;
            this.servbtneditserv.Click += new System.EventHandler(this.servbtneditserv_Click);
            // 
            // servcmbserve
            // 
            this.servcmbserve.FormattingEnabled = true;
            this.servcmbserve.Location = new System.Drawing.Point(132, 109);
            this.servcmbserve.Name = "servcmbserve";
            this.servcmbserve.Size = new System.Drawing.Size(314, 38);
            this.servcmbserve.TabIndex = 45;
            // 
            // servlblServe
            // 
            this.servlblServe.AutoSize = true;
            this.servlblServe.Location = new System.Drawing.Point(32, 111);
            this.servlblServe.Name = "servlblServe";
            this.servlblServe.Size = new System.Drawing.Size(83, 30);
            this.servlblServe.TabIndex = 44;
            this.servlblServe.Text = "Service:";
            // 
            // contrMainbtnLogut3
            // 
            this.contrMainbtnLogut3.Image = global::Presentation.Properties.Resources.logout;
            this.contrMainbtnLogut3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.contrMainbtnLogut3.Location = new System.Drawing.Point(615, 576);
            this.contrMainbtnLogut3.Name = "contrMainbtnLogut3";
            this.contrMainbtnLogut3.Size = new System.Drawing.Size(192, 46);
            this.contrMainbtnLogut3.TabIndex = 43;
            this.contrMainbtnLogut3.Text = "LOGOUT";
            this.contrMainbtnLogut3.UseVisualStyleBackColor = true;
            this.contrMainbtnLogut3.Click += new System.EventHandler(this.contrMainbtnLogut3_Click);
            // 
            // servdescription
            // 
            this.servdescription.Location = new System.Drawing.Point(402, 268);
            this.servdescription.Multiline = true;
            this.servdescription.Name = "servdescription";
            this.servdescription.Size = new System.Drawing.Size(248, 80);
            this.servdescription.TabIndex = 42;
            this.servdescription.Visible = false;
            // 
            // servcmbpriority
            // 
            this.servcmbpriority.FormattingEnabled = true;
            this.servcmbpriority.Items.AddRange(new object[] {
            "High",
            "Medium",
            "Low"});
            this.servcmbpriority.Location = new System.Drawing.Point(402, 425);
            this.servcmbpriority.Name = "servcmbpriority";
            this.servcmbpriority.Size = new System.Drawing.Size(248, 38);
            this.servcmbpriority.TabIndex = 41;
            this.servcmbpriority.Visible = false;
            // 
            // servcmbduration
            // 
            this.servcmbduration.FormattingEnabled = true;
            this.servcmbduration.Items.AddRange(new object[] {
            "1-4 days",
            "1 week",
            "2 weeks",
            "3 weeks",
            "1 month"});
            this.servcmbduration.Location = new System.Drawing.Point(402, 366);
            this.servcmbduration.Name = "servcmbduration";
            this.servcmbduration.Size = new System.Drawing.Size(248, 38);
            this.servcmbduration.TabIndex = 39;
            this.servcmbduration.Visible = false;
            // 
            // servtxtname
            // 
            this.servtxtname.Location = new System.Drawing.Point(402, 209);
            this.servtxtname.Name = "servtxtname";
            this.servtxtname.Size = new System.Drawing.Size(248, 35);
            this.servtxtname.TabIndex = 38;
            this.servtxtname.Visible = false;
            // 
            // servlblPriority
            // 
            this.servlblPriority.AutoSize = true;
            this.servlblPriority.Location = new System.Drawing.Point(172, 425);
            this.servlblPriority.Name = "servlblPriority";
            this.servlblPriority.Size = new System.Drawing.Size(83, 30);
            this.servlblPriority.TabIndex = 37;
            this.servlblPriority.Text = "Priority:";
            this.servlblPriority.Visible = false;
            // 
            // servlblduration
            // 
            this.servlblduration.AutoSize = true;
            this.servlblduration.Location = new System.Drawing.Point(172, 369);
            this.servlblduration.Name = "servlblduration";
            this.servlblduration.Size = new System.Drawing.Size(99, 30);
            this.servlblduration.TabIndex = 36;
            this.servlblduration.Text = "Duration:";
            this.servlblduration.Visible = false;
            // 
            // servlbldescription
            // 
            this.servlbldescription.AutoSize = true;
            this.servlbldescription.Location = new System.Drawing.Point(172, 271);
            this.servlbldescription.Name = "servlbldescription";
            this.servlbldescription.Size = new System.Drawing.Size(194, 30);
            this.servlbldescription.TabIndex = 35;
            this.servlbldescription.Text = "Service Description:";
            this.servlbldescription.Visible = false;
            // 
            // servlblname
            // 
            this.servlblname.AutoSize = true;
            this.servlblname.Location = new System.Drawing.Point(172, 209);
            this.servlblname.Name = "servlblname";
            this.servlblname.Size = new System.Drawing.Size(145, 30);
            this.servlblname.TabIndex = 34;
            this.servlblname.Text = "Service Name:";
            this.servlblname.Visible = false;
            // 
            // ContrMainClose3
            // 
            this.ContrMainClose3.Image = global::Presentation.Properties.Resources.close;
            this.ContrMainClose3.Location = new System.Drawing.Point(773, 9);
            this.ContrMainClose3.Name = "ContrMainClose3";
            this.ContrMainClose3.Size = new System.Drawing.Size(34, 35);
            this.ContrMainClose3.TabIndex = 22;
            this.ContrMainClose3.TabStop = false;
            this.ContrMainClose3.Click += new System.EventHandler(this.ContrMainClose3_Click);
            // 
            // ContrMainHelp3
            // 
            this.ContrMainHelp3.Image = global::Presentation.Properties.Resources.help_icon;
            this.ContrMainHelp3.Location = new System.Drawing.Point(731, 9);
            this.ContrMainHelp3.Name = "ContrMainHelp3";
            this.ContrMainHelp3.Size = new System.Drawing.Size(36, 35);
            this.ContrMainHelp3.TabIndex = 21;
            this.ContrMainHelp3.TabStop = false;
            this.ContrMainHelp3.Click += new System.EventHandler(this.ContrMainHelp3_Click);
            // 
            // TbEquipment
            // 
            this.TbEquipment.Location = new System.Drawing.Point(204, 4);
            this.TbEquipment.Name = "TbEquipment";
            this.TbEquipment.Size = new System.Drawing.Size(816, 637);
            this.TbEquipment.TabIndex = 3;
            this.TbEquipment.Text = "Equipment";
            this.TbEquipment.UseVisualStyleBackColor = true;
            // 
            // ContractMaintenaceMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.pnlTemplate);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "ContractMaintenaceMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnlTemplate.ResumeLayout(false);
            this.ContrMainTab.ResumeLayout(false);
            this.TbPakages.ResumeLayout(false);
            this.TbPakages.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ContrMainHelp2)).EndInit();
            this.TbServices.ResumeLayout(false);
            this.TbServices.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContrMainClose3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ContrMainHelp3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTemplate;
        private System.Windows.Forms.TabControl ContrMainTab;
        private System.Windows.Forms.TabPage TbPakages;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox ContrMainHelp2;
        private System.Windows.Forms.TabPage TbServices;
        private System.Windows.Forms.PictureBox ContrMainClose3;
        private System.Windows.Forms.PictureBox ContrMainHelp3;
        private System.Windows.Forms.ComboBox packcmbpa;
        private System.Windows.Forms.Label packblbpa;
        private System.Windows.Forms.Button packbtnSave;
        private System.Windows.Forms.TextBox servdescription;
        private System.Windows.Forms.ComboBox servcmbpriority;
        private System.Windows.Forms.ComboBox servcmbduration;
        private System.Windows.Forms.TextBox servtxtname;
        private System.Windows.Forms.Label servlblPriority;
        private System.Windows.Forms.Label servlblduration;
        private System.Windows.Forms.Label servlbldescription;
        private System.Windows.Forms.Label servlblname;
        private System.Windows.Forms.ComboBox packcmblevel;
        private System.Windows.Forms.TextBox packtxtname;
        private System.Windows.Forms.Label packblbservice2;
        private System.Windows.Forms.Label packblbservice1;
        private System.Windows.Forms.Label packblblevel;
        private System.Windows.Forms.Label packblbname;
        private System.Windows.Forms.Button contrMainbtnLogout2;
        private System.Windows.Forms.Button contrMainbtnLogut3;
        private System.Windows.Forms.Button packbtnadd;
        private System.Windows.Forms.Button packbtnedit;
        private System.Windows.Forms.TabPage TbEquipment;
        private System.Windows.Forms.ComboBox packcmbService4;
        private System.Windows.Forms.Label packblbservice4;
        private System.Windows.Forms.ComboBox packcmbService2;
        private System.Windows.Forms.ComboBox packcmbService1;
        private System.Windows.Forms.ComboBox packcmbService3;
        private System.Windows.Forms.Label packblbservice3;
        private System.Windows.Forms.Button packbtnCancel;
        private System.Windows.Forms.Button packbtndelete;
        private System.Windows.Forms.Button packbtnUpdate;
        private System.Windows.Forms.Button servbtnaddserve;
        private System.Windows.Forms.Button servbtneditserv;
        private System.Windows.Forms.ComboBox servcmbserve;
        private System.Windows.Forms.Label servlblServe;
        private System.Windows.Forms.Button servbtndelete;
        private System.Windows.Forms.Button servbtnupdate;
        private System.Windows.Forms.Button servbtncancel;
        private System.Windows.Forms.Button servbtnsave;

        
    }
}