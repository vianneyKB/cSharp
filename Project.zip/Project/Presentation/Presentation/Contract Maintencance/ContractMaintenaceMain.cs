﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BussinessLogic;

namespace Presentation
{
    public partial class ContractMaintenaceMain : Form
    {
        ServicesProvided services;
        Package packages;
        DataTable Services_serviceList;
        DataTable Packages_service1;
        DataTable Packages_service2;
        DataTable Packages_service3;
        DataTable Packages_service4;
        DataTable Packages_packagelist;
        public ContractMaintenaceMain()
        {
            InitializeComponent();
            ContrMainTab.DrawItem += new DrawItemEventHandler(ContrMainTab_DrawItem);

            services = new ServicesProvided();
            packages = new Package();

            Services_serviceList = services.GetListOfServices();
            servcmbserve.DataSource = Services_serviceList;
            servcmbserve.DisplayMember = "ServiceName";

            Packages_service1 = services.GetListOfServices();
            Packages_service2 = services.GetListOfServices();
            Packages_service3 = services.GetListOfServices();
            Packages_service4 = services.GetListOfServices();
            
            
            packcmbService1.DataSource = Packages_service1;
            packcmbService2.DataSource = Packages_service2;
            packcmbService3.DataSource = Packages_service3;
            packcmbService4.DataSource = Packages_service4;
            packcmbService1.DisplayMember = "ServiceName";
            packcmbService2.DisplayMember = "ServiceName";
            packcmbService3.DisplayMember = "ServiceName";
            packcmbService4.DisplayMember = "ServiceName";

            Packages_packagelist = packages.GetListOPackages();
            packcmbpa.DataSource = Packages_packagelist;
            packcmbpa.DisplayMember = "PackageName";
        }

        private void ContrMainTab_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = ContrMainTab.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = ContrMainTab.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {
                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Aqua);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", (float)10.0, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void contrMainbtnLogout1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void contrMainbtnLogout2_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                     "Logout",
                                     MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void contrMainbtnLogut3_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void ContrMainClose1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void ContrMainClose3_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void ContrMainHelp1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the contracts maintenance page. Select a contract from the combobox then edit the details below and save it");
        }

        private void ContrMainHelp2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the packages maintenance page. Select a package from the combobox then edit the details below and save it");
        }

        private void ContrMainHelp3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the services maintenance page. Select a service from the combobox then edit the details below and save it");
        }

        //****************************************SERVICES**************************************************

        //Add a service
        private void servbtnaddserve_Click(object sender, EventArgs e)
        {
            //Hide controls
            servlblServe.Visible = false;
            servcmbserve.Visible = false;
            servbtneditserv.Visible = false;
            servbtnaddserve.Visible = false;

            //Show controls
            servlblname.Visible = true;
            servlbldescription.Visible = true;
            servlblduration.Visible = true;
            servlblPriority.Visible = true;
            servtxtname.Visible = true;
            servdescription.Visible = true;
            servcmbduration.Visible = true;
            servcmbpriority.Visible = true;
            servbtnsave.Visible = true;
            servbtncancel.Visible = true;
        }

        //Cancel Service Edit
        private void servbtncancel_Click(object sender, EventArgs e)
        {
            //Empty fields
            servtxtname.Text = "";
            servdescription.Text = "";

            //Hide controls
            servlblname.Visible = false;
            servlbldescription.Visible = false;
            servlblduration.Visible = false;
            servlblPriority.Visible = false;
            servtxtname.Visible = false;
            servdescription.Visible = false;
            servcmbduration.Visible = false;
            servcmbpriority.Visible = false;
            servbtnsave.Visible = false;
            servbtncancel.Visible = false;

            //Show controls
            servlblServe.Visible = true;
            servcmbserve.Visible = true;
            servbtneditserv.Visible = true;
            servbtnaddserve.Visible = true;


        }
        
        //Insert service
        private void servbtnsave_Click(object sender, EventArgs e)
        {
            if (servtxtname.Text == "" || servdescription.Text == "" || servcmbduration.Text == "" || servcmbpriority.Text == "")
            {
                MessageBox.Show("Please fill in all fields before attempting to add service");
            }
            else
            {
                ServicesProvided service = new ServicesProvided(servtxtname.Text, servdescription.Text, servcmbduration.Text, servcmbpriority.Text);
                string ex = service.Existence(servtxtname.Text);

                if (ex == "true")
                {
                    MessageBox.Show("This service already exists");
                }
                else
                {
                    MessageBox.Show(service.AddService(servtxtname.Text, servdescription.Text, servcmbduration.Text, servcmbpriority.Text));

                    //Empty fields
                    servtxtname.Text = "";
                    servdescription.Text = "";
                    servcmbduration.Text = "";
                    servcmbpriority.Text = "";

                    //Hide controls
                    servlblname.Visible = false;
                    servlbldescription.Visible = false;
                    servlblduration.Visible = false;
                    servlblPriority.Visible = false;
                    servtxtname.Visible = false;
                    servdescription.Visible = false;
                    servcmbduration.Visible = false;
                    servcmbpriority.Visible = false;
                    servbtnsave.Visible = false;
                    servbtncancel.Visible = false;

                    //Show controls
                    servlblServe.Visible = true;
                    servcmbserve.Visible = true;
                    servbtneditserv.Visible = true;
                    servbtnaddserve.Visible = true;

                    //refresh list of services
                    services = new ServicesProvided();

                    Services_serviceList = services.GetListOfServices();
                    servcmbserve.DataSource = Services_serviceList;
                    servcmbserve.DisplayMember = "ServiceName";

                    Packages_service1 = services.GetListOfServices();
                    Packages_service2 = services.GetListOfServices();
                    Packages_service3 = services.GetListOfServices();
                    Packages_service4 = services.GetListOfServices();


                    packcmbService1.DataSource = Packages_service1;
                    packcmbService2.DataSource = Packages_service2;
                    packcmbService3.DataSource = Packages_service3;
                    packcmbService4.DataSource = Packages_service4;
                    packcmbService1.DisplayMember = "ServiceName";
                    packcmbService2.DisplayMember = "ServiceName";
                    packcmbService3.DisplayMember = "ServiceName";
                    packcmbService4.DisplayMember = "ServiceName";
                }
            }
        }

        //Edit a Service
        private void servbtneditserv_Click(object sender, EventArgs e)
        {
            if (servcmbserve.Text == "")
            {
                MessageBox.Show("Please select a service to edit");
            }
            else
            {
                //Hide controls
                servlblServe.Visible = false;
                servcmbserve.Visible = false;
                servbtneditserv.Visible = false;
                servbtnaddserve.Visible = false;

                //Populate fields
                services = new ServicesProvided();

                string servicename = servcmbserve.Text;

                ServicesProvided serv = services.ReturnAllServiceInfo(servicename);

                servtxtname.Text = serv.servicename;
                servdescription.Text = serv.ServiceDescription;
                servcmbduration.Text = serv.Duration;
                servcmbpriority.Text = serv.Priority;

                servtxtname.ReadOnly = true;

                //Show controls
                servlblname.Visible = true;
                servlbldescription.Visible = true;
                servlblduration.Visible = true;
                servlblPriority.Visible = true;
                servtxtname.Visible = true;
                servdescription.Visible = true;
                servcmbduration.Visible = true;
                servcmbpriority.Visible = true;
                servbtnupdate.Visible = true;
                servbtndelete.Visible = true;
            }

            
        }
        
        //Update service
        private void servbtnupdate_Click(object sender, EventArgs e)
        {
            if (servtxtname.Text == "" || servdescription.Text == "" || servcmbduration.Text == "" || servcmbpriority.Text == "")
            {
                MessageBox.Show("Please fill in all fields before attempting to update service");
            }
            else
            {
                services = new ServicesProvided();
                MessageBox.Show(services.UpdateService(servtxtname.Text, servdescription.Text, servcmbduration.Text, servcmbpriority.Text));

                    //Empty fields
                    servtxtname.Text = "";
                    servdescription.Text = "";
                    servcmbduration.Text = "";
                    servcmbpriority.Text = "";

                    //Hide controls
                    servlblname.Visible = false;
                    servlbldescription.Visible = false;
                    servlblduration.Visible = false;
                    servlblPriority.Visible = false;
                    servtxtname.Visible = false;
                    servdescription.Visible = false;
                    servcmbduration.Visible = false;
                    servcmbpriority.Visible = false;
                    servbtnsave.Visible = false;
                    servbtncancel.Visible = false;

                    servtxtname.ReadOnly = false;

                    //Show controls
                    servlblServe.Visible = true;
                    servcmbserve.Visible = true;
                    servbtneditserv.Visible = true;
                    servbtnaddserve.Visible = true;

                    //refresh list of services
                    Services_serviceList = services.GetListOfServices();
                    servcmbserve.DataSource = Services_serviceList;
                    servcmbserve.DisplayMember = "ServiceName";
            }
        }

        //Delete Service
        private void servbtndelete_Click(object sender, EventArgs e)
        {
            if (servcmbserve.Text == "" )
            {
                MessageBox.Show("Please select a service to be deleted");
            }
            else
            {
                services = new ServicesProvided();
                MessageBox.Show(services.DeletService(servtxtname.Text));

                //Empty fields
                servtxtname.Text = "";
                servdescription.Text = "";
                servcmbduration.Text = "";
                servcmbpriority.Text = "";

                //Hide controls
                servlblname.Visible = false;
                servlbldescription.Visible = false;
                servlblduration.Visible = false;
                servlblPriority.Visible = false;
                servtxtname.Visible = false;
                servdescription.Visible = false;
                servcmbduration.Visible = false;
                servcmbpriority.Visible = false;
                servbtnsave.Visible = false;
                servbtncancel.Visible = false;

                //Show controls
                servlblServe.Visible = true;
                servcmbserve.Visible = true;
                servbtneditserv.Visible = true;
                servbtnaddserve.Visible = true;

                //refresh list of services
                Services_serviceList = services.GetListOfServices();
                servcmbserve.DataSource = Services_serviceList;
                servcmbserve.DisplayMember = "ServiceName";
            }
        }

        //****************************************PACKAGES*****************************************************
        //Add a pakage
        private void packbtnadd_Click(object sender, EventArgs e)
        {
            //Hide controls
            packblbpa.Visible = false;
            packcmbpa.Visible = false;
            packbtnadd.Visible = false;
            packbtnedit.Visible = false;

            //Empty fields
            packtxtname.Text = "";
            packcmblevel.Text = "";
            packcmbService1.Text = "";
            packcmbService2.Text = "";
            packcmbService3.Text = "";
            packcmbService4.Text = "";

            //Show Controls
            packblbname.Visible = true;
            packblblevel.Visible = true;

            packtxtname.Visible = true;
            packcmblevel.Visible = true;
            packbtnSave.Visible = true;
            packbtnCancel.Visible = true;

        }

        //edit a package
        private void packbtnedit_Click(object sender, EventArgs e)
        {
            if (packblbpa.Text == "")
            {
                MessageBox.Show("Please select a package to edit");
            }
            else
            {
                //Hide controls
                packblbpa.Visible = false;
                packcmbpa.Visible = false;
                packbtnadd.Visible = false;
                packbtnedit.Visible = false;

                //Populate fields
                packages = new Package();
                Package pack = packages.ReturnAllPackageInfo(packcmbpa.Text);

                packtxtname.Text = pack.Packagename;
                packcmblevel.Text = pack.Packagelevel;

                //Show controls
                packtxtname.ReadOnly = true;
                packtxtname.Visible = true;
                packblbname.Visible = true;
                packblblevel.Visible = true;
                packcmblevel.Visible = true;

                if (packcmblevel.Text == "Platinum")
	            {
                    packcmbService1.Text = pack.Service1;
                    packcmbService2.Text = pack.Service2;
                    packcmbService3.Text = pack.Service3;
                    packcmbService4.Text = pack.Service4;

                    packblbservice1.Visible = true;
                    packblbservice2.Visible = true;
                    packblbservice3.Visible = true;
                    packblbservice4.Visible = true;
                    packcmbService1.Visible = true;
                    packcmbService2.Visible = true;
                    packcmbService3.Visible = true;
                    packcmbService4.Visible = true;
	            }
                else if (packcmblevel.Text == "Gold")
	            {
                    packcmbService1.Text = pack.Service1;
                    packcmbService2.Text = pack.Service2;
                    packcmbService3.Text = pack.Service3;

                    packblbservice1.Visible = true;
                    packblbservice2.Visible = true;
                    packblbservice3.Visible = true;
                    packcmbService1.Visible = true;
                    packcmbService2.Visible = true;
                    packcmbService3.Visible = true;
	            }
                else if (packcmblevel.Text == "Silver")
	            {
                    packcmbService1.Text = pack.Service1;
                    packcmbService2.Text = pack.Service2;

                    packblbservice1.Visible = true;
                    packblbservice2.Visible = true;
                    packcmbService1.Visible = true;
                    packcmbService2.Visible = true;
	            }
                else if (packcmblevel.Text == "Bronze")
	            {
                    packcmbService1.Text = pack.Service1;

                    packblbservice1.Visible = true;
                    packcmbService1.Visible = true;
	            }

                packbtnSave.Visible = true;
                packbtnCancel.Visible = true;

            }
            
        }

        //Insert package
        private void packbtnSave_Click(object sender, EventArgs e)
        {
            if (packtxtname.Text == "" || packcmblevel.Text == "" || packcmbService1.Text == "" )
            {
                MessageBox.Show("Please fill in all fields before attempting to add service");
            }
            else
            {
                packages = new Package();
                string ex = packages.Existence(packtxtname.Text);

                if (ex == "true")
                {
                    MessageBox.Show("This package already exists");
                }
                else
                {
                    MessageBox.Show(packages.InsertPackage(packtxtname.Text, packcmblevel.Text, packcmbService1.Text, packcmbService2.Text, packcmbService3.Text, packcmbService4.Text));

                    //show controls
                    packblbpa.Visible = true;
                    packcmbpa.Visible = true;
                    packbtnadd.Visible = true;
                    packbtnedit.Visible = true;

                    //Empty fields
                    packtxtname.Text = "";
                    packcmblevel.Text = "";
                    packcmbService1.Text = "";
                    packcmbService2.Text = "";
                    packcmbService3.Text = "";
                    packcmbService4.Text = "";

                    //hide Controls
                    packblbname.Visible = false;
                    packblblevel.Visible = false;
                    packblbservice1.Visible = false;
                    packblbservice2.Visible = false;
                    packblbservice3.Visible = false;
                    packblbservice4.Visible = false;
                    packtxtname.Visible = false;
                    packcmblevel.Visible = false;
                    packbtnSave.Visible = false;
                    packbtnCancel.Visible = false;
                    packcmbService1.Visible = false;
                    packcmbService2.Visible = false;
                    packcmbService3.Visible = false;
                    packcmbService4.Visible = false;

                    //refresh list of pacckages
                    Packages_packagelist = packages.GetListOPackages();
                    packcmbpa.DataSource = Packages_packagelist;
                    packcmbpa.DisplayMember = "PackageName";
                }
            }
        }

        //
        private void packcmblevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (packcmblevel.Text == "Platinum")
            {
                packblbservice1.Visible = true;
                packblbservice2.Visible = true;
                packblbservice3.Visible = true;
                packblbservice4.Visible = true;
                packcmbService1.Visible = true;
                packcmbService2.Visible = true;
                packcmbService3.Visible = true;
                packcmbService4.Visible = true;
            }
            else if (packcmblevel.Text == "Gold")
            {
                packblbservice1.Visible = true;
                packblbservice2.Visible = true;
                packblbservice3.Visible = true;
                packcmbService1.Visible = true;
                packcmbService2.Visible = true;
                packcmbService3.Visible = true;

                packcmbService4.Text = "";
                packcmbService4.Visible = false;
                packblbservice4.Visible = false;

            }
            else if (packcmblevel.Text == "Silver")
            {
                packblbservice1.Visible = true;
                packblbservice2.Visible = true;
                packcmbService1.Visible = true;
                packcmbService2.Visible = true;

                packcmbService3.Text = "";
                packcmbService4.Text = "";
                packcmbService3.Visible = false;
                packcmbService4.Visible = false;
                packblbservice3.Visible = false;
                packblbservice4.Visible = false;
            }
            else if (packcmblevel.Text == "Bronze")
            {
                packblbservice1.Visible = true;
                packcmbService1.Visible = true;

                packcmbService2.Text = "";
                packcmbService3.Text = "";
                packcmbService4.Text = "";
                packcmbService2.Visible = false;
                packcmbService3.Visible = false;
                packcmbService4.Visible = false;
                packblbservice2.Visible = false;
                packblbservice3.Visible = false;
                packblbservice4.Visible = false;
            }
        }

        //****************************************EQUIPEMENT**************************************************

        //****************************************TAB CONTROLS**************************************************

        //On tab change
        private void ContrMainTab_Selected(object sender, TabControlEventArgs e)
        {
            //+++++++++++ services ++++++++++++++
            //Empty fields
            servtxtname.Text = "";
            servdescription.Text = "";

            //Hide controls
            servlblname.Visible = false;
            servlbldescription.Visible = false;
            servlblduration.Visible = false;
            servlblPriority.Visible = false;
            servtxtname.Visible = false;
            servdescription.Visible = false;
            servcmbduration.Visible = false;
            servcmbpriority.Visible = false;
            servbtnsave.Visible = false;
            servbtncancel.Visible = false;

            //Show controls
            servlblServe.Visible = true;
            servcmbserve.Visible = true;
            servbtneditserv.Visible = true;
            servbtnaddserve.Visible = true;

            //+++++++++++ packages ++++++++++++++

            //show controls
            packblbpa.Visible = true;
            packcmbpa.Visible = true;
            packbtnadd.Visible = true;
            packbtnedit.Visible = true;

            //Empty fields
            packtxtname.Text = "";
            packcmblevel.Text = "";
            packcmbService1.Text = "";
            packcmbService2.Text = "";
            packcmbService3.Text = "";
            packcmbService4.Text = "";

            //hide Controls
            packblbname.Visible = false;
            packblblevel.Visible = false;
            packblbservice1.Visible = false;
            packblbservice2.Visible = false;
            packblbservice3.Visible = false;
            packblbservice4.Visible = false;
            packtxtname.Visible = false;
            packcmblevel.Visible = false;
            packbtnSave.Visible = false;
            packbtnCancel.Visible = false;
        }

        

        

        
        

        
    }
}
