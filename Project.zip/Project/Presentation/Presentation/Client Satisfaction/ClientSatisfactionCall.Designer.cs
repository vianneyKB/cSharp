﻿namespace Presentation
{
    partial class ClientSatisfactionCall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {       
            this.CalllblClientName = new System.Windows.Forms.Label();
            this.CalllblTimer = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CSCallHelpClose = new System.Windows.Forms.PictureBox();
            this.CSCallHelp = new System.Windows.Forms.PictureBox();
            this.CallCallbtnSendRequest = new System.Windows.Forms.Button();
            this.ClientSatbtnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.CSCallHelpClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CSCallHelp)).BeginInit();
            this.SuspendLayout();
            // 
            // CalllblClientName
            // 
            this.CalllblClientName.AutoSize = true;
            this.CalllblClientName.Location = new System.Drawing.Point(468, 195);
            this.CalllblClientName.Name = "CalllblClientName";
            this.CalllblClientName.Size = new System.Drawing.Size(186, 30);
            this.CalllblClientName.TabIndex = 41;
            this.CalllblClientName.Text = "CLIENT FUL NAME";
            // 
            // CalllblTimer
            // 
            this.CalllblTimer.AutoSize = true;
            this.CalllblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalllblTimer.Location = new System.Drawing.Point(395, 45);
            this.CalllblTimer.Name = "CalllblTimer";
            this.CalllblTimer.Size = new System.Drawing.Size(363, 135);
            this.CalllblTimer.TabIndex = 40;
            this.CalllblTimer.Text = "00:00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(149, 252);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 30);
            this.label1.TabIndex = 42;
            this.label1.Text = "Call Details:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(325, 252);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(432, 188);
            this.textBox1.TabIndex = 43;
            // 
            // CSCallHelpClose
            // 
            this.CSCallHelpClose.Image = global::Presentation.Properties.Resources.close;
            this.CSCallHelpClose.Location = new System.Drawing.Point(933, 23);
            this.CSCallHelpClose.Name = "CSCallHelpClose";
            this.CSCallHelpClose.Size = new System.Drawing.Size(36, 36);
            this.CSCallHelpClose.TabIndex = 37;
            this.CSCallHelpClose.TabStop = false;
            this.CSCallHelpClose.Click += new System.EventHandler(this.CSCallHelpClose_Click);
            // 
            // CSCallHelp
            // 
            this.CSCallHelp.Image = global::Presentation.Properties.Resources.help_icon;
            this.CSCallHelp.Location = new System.Drawing.Point(877, 23);
            this.CSCallHelp.Name = "CSCallHelp";
            this.CSCallHelp.Size = new System.Drawing.Size(36, 36);
            this.CSCallHelp.TabIndex = 36;
            this.CSCallHelp.TabStop = false;
            this.CSCallHelp.Click += new System.EventHandler(this.CSCallHelp_Click);
            // 
            // CallCallbtnSendRequest
            // 
            this.CallCallbtnSendRequest.Image = global::Presentation.Properties.Resources.Accept_icon;
            this.CallCallbtnSendRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CallCallbtnSendRequest.Location = new System.Drawing.Point(311, 460);
            this.CallCallbtnSendRequest.Name = "CallCallbtnSendRequest";
            this.CallCallbtnSendRequest.Size = new System.Drawing.Size(210, 49);
            this.CallCallbtnSendRequest.TabIndex = 35;
            this.CallCallbtnSendRequest.Text = "Send Request";
            this.CallCallbtnSendRequest.UseVisualStyleBackColor = true;
            // 
            // ClientSatbtnCancel
            // 
            this.ClientSatbtnCancel.Image = global::Presentation.Properties.Resources.RejectCall;
            this.ClientSatbtnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ClientSatbtnCancel.Location = new System.Drawing.Point(574, 460);
            this.ClientSatbtnCancel.Name = "ClientSatbtnCancel";
            this.ClientSatbtnCancel.Size = new System.Drawing.Size(183, 49);
            this.ClientSatbtnCancel.TabIndex = 38;
            this.ClientSatbtnCancel.Text = "Cancel Call";
            this.ClientSatbtnCancel.UseVisualStyleBackColor = true;
            this.ClientSatbtnCancel.Click += new System.EventHandler(this.ClientSatbtnCancel_Click);
            // 
            // ClientSatisfactionCall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CalllblClientName);
            this.Controls.Add(this.CalllblTimer);
            this.Controls.Add(this.CSCallHelpClose);
            this.Controls.Add(this.CSCallHelp);
            this.Controls.Add(this.CallCallbtnSendRequest);
            this.Controls.Add(this.ClientSatbtnCancel);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "ClientSatisfactionCall";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.CSCallHelpClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CSCallHelp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CalllblClientName;
        private System.Windows.Forms.Label CalllblTimer;
        private System.Windows.Forms.PictureBox CSCallHelpClose;
        private System.Windows.Forms.PictureBox CSCallHelp;
        private System.Windows.Forms.Button CallCallbtnSendRequest;
        private System.Windows.Forms.Button ClientSatbtnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;

        
    }
}