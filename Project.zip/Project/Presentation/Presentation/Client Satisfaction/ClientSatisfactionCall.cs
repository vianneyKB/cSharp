﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentation
{
    public partial class ClientSatisfactionCall : Form
    {
        public ClientSatisfactionCall()
        {
            InitializeComponent();
        }

        private void ClientSatbtnCancel_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to cancel this call?",
                                    "Cancel call",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                ContactClient cc = new ContactClient();
                cc.Show();
                this.Show();
            }
            else
            {
                //Do nothing
            }

            
        }

        private void CSCallHelpClose_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void CSCallHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the client satisfaction department client call page. Listen to the needs of the client and type them down hen save the details of the call");
        }
    }
}
