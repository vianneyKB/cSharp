﻿namespace Presentation
{
    partial class ContactClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {       
            this.ClienContab = new System.Windows.Forms.TabControl();
            this.TbClientContacts = new System.Windows.Forms.TabPage();
            this.ContactClientbtnLogout = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.ContCLientbtnCall = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ConClientCLose = new System.Windows.Forms.PictureBox();
            this.ConlientHelp = new System.Windows.Forms.PictureBox();
            this.ClienContab.SuspendLayout();
            this.TbClientContacts.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ConClientCLose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConlientHelp)).BeginInit();
            this.SuspendLayout();
            // 
            // ClienContab
            // 
            this.ClienContab.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.ClienContab.Controls.Add(this.TbClientContacts);
            this.ClienContab.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.ClienContab.ItemSize = new System.Drawing.Size(50, 200);
            this.ClienContab.Location = new System.Drawing.Point(0, 2);
            this.ClienContab.Multiline = true;
            this.ClienContab.Name = "ClienContab";
            this.ClienContab.SelectedIndex = 0;
            this.ClienContab.Size = new System.Drawing.Size(1024, 645);
            this.ClienContab.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.ClienContab.TabIndex = 21;
            // 
            // TbClientContacts
            // 
            this.TbClientContacts.Controls.Add(this.ContactClientbtnLogout);
            this.TbClientContacts.Controls.Add(this.panel1);
            this.TbClientContacts.Controls.Add(this.comboBox1);
            this.TbClientContacts.Controls.Add(this.label1);
            this.TbClientContacts.Controls.Add(this.ConClientCLose);
            this.TbClientContacts.Controls.Add(this.ConlientHelp);
            this.TbClientContacts.Location = new System.Drawing.Point(204, 4);
            this.TbClientContacts.Name = "TbClientContacts";
            this.TbClientContacts.Padding = new System.Windows.Forms.Padding(3);
            this.TbClientContacts.Size = new System.Drawing.Size(816, 637);
            this.TbClientContacts.TabIndex = 0;
            this.TbClientContacts.Text = "Client Contact";
            this.TbClientContacts.UseVisualStyleBackColor = true;
            // 
            // ContactClientbtnLogout
            // 
            this.ContactClientbtnLogout.Image = global::Presentation.Properties.Resources.logout;
            this.ContactClientbtnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContactClientbtnLogout.Location = new System.Drawing.Point(616, 584);
            this.ContactClientbtnLogout.Name = "ContactClientbtnLogout";
            this.ContactClientbtnLogout.Size = new System.Drawing.Size(192, 46);
            this.ContactClientbtnLogout.TabIndex = 38;
            this.ContactClientbtnLogout.Text = "LOGOUT";
            this.ContactClientbtnLogout.UseVisualStyleBackColor = true;
            this.ContactClientbtnLogout.Click += new System.EventHandler(this.ContactClientbtnLogout_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.ContCLientbtnCall);
            this.panel1.Location = new System.Drawing.Point(0, 227);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(820, 122);
            this.panel1.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(342, 72);
            this.label2.TabIndex = 0;
            this.label2.Text = "Client Name";
            // 
            // ContCLientbtnCall
            // 
            this.ContCLientbtnCall.Image = global::Presentation.Properties.Resources.MakeCall;
            this.ContCLientbtnCall.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ContCLientbtnCall.Location = new System.Drawing.Point(605, 36);
            this.ContCLientbtnCall.Name = "ContCLientbtnCall";
            this.ContCLientbtnCall.Size = new System.Drawing.Size(194, 44);
            this.ContCLientbtnCall.TabIndex = 27;
            this.ContCLientbtnCall.Text = "Call";
            this.ContCLientbtnCall.UseVisualStyleBackColor = true;
            this.ContCLientbtnCall.Click += new System.EventHandler(this.ContCLientbtnCall_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(320, 81);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(314, 38);
            this.comboBox1.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(189, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 30);
            this.label1.TabIndex = 19;
            this.label1.Text = "Client:";
            // 
            // ConClientCLose
            // 
            this.ConClientCLose.Image = global::Presentation.Properties.Resources.close;
            this.ConClientCLose.Location = new System.Drawing.Point(774, 8);
            this.ConClientCLose.Name = "ConClientCLose";
            this.ConClientCLose.Size = new System.Drawing.Size(34, 35);
            this.ConClientCLose.TabIndex = 18;
            this.ConClientCLose.TabStop = false;
            this.ConClientCLose.Click += new System.EventHandler(this.ConClientCLose_Click);
            // 
            // ConlientHelp
            // 
            this.ConlientHelp.Image = global::Presentation.Properties.Resources.help_icon;
            this.ConlientHelp.Location = new System.Drawing.Point(732, 8);
            this.ConlientHelp.Name = "ConlientHelp";
            this.ConlientHelp.Size = new System.Drawing.Size(36, 35);
            this.ConlientHelp.TabIndex = 17;
            this.ConlientHelp.TabStop = false;
            this.ConlientHelp.Click += new System.EventHandler(this.ConlientHelp_Click);
            // 
            // ContactClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1024, 648);
            this.Controls.Add(this.ClienContab);
            this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "ContactClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ClienContab.ResumeLayout(false);
            this.TbClientContacts.ResumeLayout(false);
            this.TbClientContacts.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ConClientCLose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConlientHelp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl ClienContab;
        private System.Windows.Forms.TabPage TbClientContacts;
        private System.Windows.Forms.Button ContCLientbtnCall;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox ConClientCLose;
        private System.Windows.Forms.PictureBox ConlientHelp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ContactClientbtnLogout;

        
    }
}