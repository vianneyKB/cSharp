﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentation
{
    public partial class ContactClient : Form
    {
        public ContactClient()
        {
            InitializeComponent();
            ClienContab.DrawItem += new DrawItemEventHandler(ClienContab_DrawItem);
        }

        private void ClienContab_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = ClienContab.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = ClienContab.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {
                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Aqua);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", (float)10.0, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void ContactClientbtnLogout_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void ConClientCLose_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void ConlientHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This page contains contract details of clients thaT allows you to call clients");
        }

        private void ContCLientbtnCall_Click(object sender, EventArgs e)
        {
            ClientSatisfactionCall cs = new ClientSatisfactionCall();
            cs.Show();
            this.Hide();
        }
    }
}
