﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BussinessLogic;

namespace Presentation
{
    public partial class Users : Form
    {
        User user;
        DataTable dt;
        public Users()
        {
            InitializeComponent();
            ClienContab.DrawItem += new DrawItemEventHandler(ClienContab_DrawItem);

            user = new User();
            dt = user.GetListOfUsers();
            UsersCmbUsers.DataSource = dt;
            UsersCmbUsers.DisplayMember = "Username";
        }

        private void ClienContab_DrawItem(object sender, DrawItemEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush _textBrush;

            // Get the item from the collection.
            TabPage _tabPage = ClienContab.TabPages[e.Index];

            // Get the real bounds for the tab rectangle.
            Rectangle _tabBounds = ClienContab.GetTabRect(e.Index);

            if (e.State == DrawItemState.Selected)
            {
                // Draw a different background color, and don't paint a focus rectangle.
                _textBrush = new SolidBrush(Color.Aqua);
                g.FillRectangle(Brushes.Gray, e.Bounds);
            }
            else
            {
                _textBrush = new System.Drawing.SolidBrush(e.ForeColor);
                e.DrawBackground();
            }

            // Use our own font.
            Font _tabFont = new Font("Arial", (float)10.0, FontStyle.Bold, GraphicsUnit.Pixel);

            // Draw string. Center the text.
            StringFormat _stringFlags = new StringFormat();
            _stringFlags.Alignment = StringAlignment.Center;
            _stringFlags.LineAlignment = StringAlignment.Center;
            g.DrawString(_tabPage.Text, _tabFont, _textBrush, _tabBounds, new StringFormat(_stringFlags));
        }

        private void ContactClientbtnLogout_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to logout?",
                                    "Logout",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Login log = new Login();
                log.Show();
                this.Hide();
            }
            else
            {
                //Do nothing
            }
        }

        private void ConClientCLose_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit the program?",
                                    "Exit Program",
                                    MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                //Do nothing
            }
        }

        private void ConlientHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This page contains contract details of clients thaT allows you to call clients");
        }

        private void ContCLientbtnCall_Click(object sender, EventArgs e)
        {
            ClientSatisfactionCall cs = new ClientSatisfactionCall();
            cs.Show();
            this.Hide();
        }

        private void UserbtnEdit_Click(object sender, EventArgs e)
        {
            if (UsersCmbUsers.Text == "")
            {
                MessageBox.Show("Please select a user");
            }
            else
            {
                //Populate fields
                user = new User();

                string username = UsersCmbUsers.Text;

                User userd = user.ReturnAllUserInfo(username);
                UserstxtPassword.Text = userd.Password;
                UsersTxtUsername.Text = userd.Username;
                UserstxtFaxNumber.Text = userd.Faxnumber;
                UserstxtStreetName.Text = userd.Streetname;
                UserstxtCity.Text = userd.City;
                UserstxtCountry.Text = userd.Country;
                UserstxtEmail.Text = userd.Email;
                UserstxtPostalCode.Text = userd.Postalcode;
                UserstxtTelNumber.Text = userd.Telnumber;
                UserstxtPhoneNumber.Text = userd.Phonenumber;
                UsersTxtFirstName.Text = userd.Name;
                UsersTxtSurname.Text = userd.Surname;


                //Show controls
                UsersbtnDelete.Visible = true;
                UserslblDepartment.Visible = true;
                UserslblPassword.Visible = true;
                UserslblUsername.Visible = true;
                UserstxtPassword.Visible = true;
                UsersTxtUsername.Visible = true;
                UsersCmbDepartment.Visible = true;
                UsersbtnDelete.Visible = true;
                UsersbtnUpdate.Visible = true;
                UserbtnAdd.Visible = false;
                Userslblfname.Visible = true;
                Userslbldob.Visible = true;
                Userslblsname.Visible = true;
                UsersTxtFirstName.Visible = true;
                UsersTxtSurname.Visible = true;
                UsersDatePicker.Visible = true;
                UserstxtFaxNumber.Visible = true;
                UserstxtStreetName.Visible = true;
                UserstxtCity.Visible = true;
                UserstxtCountry.Visible = true;
                UserstxtEmail.Visible = true;
                UserstxtPostalCode.Visible = true;
                UserstxtTelNumber.Visible = true;
                UserstxtPhoneNumber.Visible = true;
                UserslblFax.Visible = true;
                Userslblstreet.Visible = true;
                Userslblcity.Visible = true;
                Userslblcountry.Visible = true;
                Userslblemail.Visible = true;
                Userslblpostal.Visible = true;
                Userslbltel.Visible = true;
                Userslblphone.Visible = true;
            }
        }

        private void UserbtnAdd_Click(object sender, EventArgs e)
        {

            //Hide controls
            UserbtnEdit.Visible = false;
            UserslblClient.Visible = false;
            UsersCmbUsers.Visible = false;

            //Show controls
            UserslblDepartment.Visible = true;
            UserslblPassword.Visible = true;
            UserslblUsername.Visible = true;
            UserstxtPassword.Visible = true;
            UsersTxtUsername.Visible = true;
            UsersCmbDepartment.Visible = true;
            UserbtnAdd.Visible = true;
            Userslblfname.Visible = true;
            Userslbldob.Visible = true;
            Userslblsname.Visible = true;
            UsersTxtFirstName.Visible = true;
            UsersTxtSurname.Visible = true;
            UsersDatePicker.Visible = true;
            UserbtnSave.Visible = true;
            UsersbtnCancel.Visible = true;
            UserstxtFaxNumber.Visible = true;
            UserstxtStreetName.Visible = true;
            UserstxtCity.Visible = true;
            UserstxtCountry.Visible = true;
            UserstxtEmail.Visible = true;
            UserstxtPostalCode.Visible = true;
            UserstxtTelNumber.Visible = true;
            UserstxtPhoneNumber.Visible = true;
            UserstxtProvince.Visible = true;
            UserslbProvince.Visible = true;
            UserslblFax.Visible = true;
            Userslblstreet.Visible = true;
            Userslblcity.Visible = true;
            Userslblcountry.Visible = true;
            Userslblemail.Visible = true;
            Userslblpostal.Visible = true;
            Userslbltel.Visible = true;
            Userslblphone.Visible = true;
            UserslbProvince.Visible = true;
            UserslblBuidingNumber.Visible = true;
            UserstxtBuildingNumber.Visible = true;
        }

        private void UserbtnSave_Click(object sender, EventArgs e)
        {
            if (UsersTxtUsername.Text == "" || UserstxtPassword.Text == "" || UsersCmbDepartment.Text == "" || UsersTxtFirstName.Text == "" ||  UsersTxtSurname.Text == "" || UserstxtFaxNumber.Text == "" || UserstxtStreetName.Text == "" || UserstxtCity.Text == "" || UserstxtCountry.Text == "" || UserstxtEmail.Text == "" || UserstxtPostalCode.Text == "" || UserstxtTelNumber.Text == "" || UserstxtPhoneNumber.Text == "")
            {
                MessageBox.Show("Please fill in all the fields before attempting to update");
            }
            else if (UsersDatePicker.Value == DateTime.Today)
            {
                MessageBox.Show("Date of birth cannot be today");
            }
            else
            {


                user = new User(UsersTxtUsername.Text, UserstxtPassword.Text, UsersCmbDepartment.Text, UsersTxtFirstName.Text, UsersTxtSurname.Text, UsersDatePicker.Value, UserstxtStreetName.Text, UserstxtCity.Text, UserstxtProvince.Text, UserstxtPostalCode.Text, UserstxtCountry.Text, UserstxtBuildingNumber.Text, UserstxtPhoneNumber.Text, UserstxtEmail.Text, UserstxtFaxNumber.Text, UserstxtTelNumber.Text);

                user.Existence(user.Username);
                if (user.exists == true)
                {
                    MessageBox.Show("This username already exists, please enter a different username and try again");
                }
                else
                {

                    MessageBox.Show(user.AddUser(user.Username, user.Password, user.Department, user.Name, user.Surname, user.Dateofbirth, user.Streetname, user.City, user.Province, user.Postalcode, user.Country, user.Buildingnumber, user.Phonenumber, user.Email, user.Faxnumber, user.Telnumber));

                    //Show controls
                    UserbtnEdit.Visible = true;
                    UserslblClient.Visible = true;
                    UsersCmbUsers.Visible = true;
                    UserbtnAdd.Visible = true;

                    //Empty Fileds
                    UsersTxtUsername.Text = "";
                    UserstxtPassword.Text = "";
                    UsersCmbDepartment.Text = "";
                    UsersTxtFirstName.Text = "";
                    UsersTxtSurname.Text = "";
                    UserstxtFaxNumber.Text = "";
                    UserstxtStreetName.Text = "";
                    UserstxtCity.Text = "";
                    UserstxtCountry.Text = "";
                    UserstxtEmail.Text = "";
                    UserstxtPostalCode.Text = "";
                    UserstxtTelNumber.Text = "";
                    UserstxtPhoneNumber.Text = "";

                    //Hide controls
                    UsersbtnDelete.Visible = false;
                    UserslblDepartment.Visible = false;
                    UserslblPassword.Visible = false;
                    UserslblUsername.Visible = false;
                    UserstxtPassword.Visible = false;
                    UsersTxtUsername.Visible = false;
                    UsersCmbDepartment.Visible = false;
                    UsersbtnDelete.Visible = false;
                    UsersbtnUpdate.Visible = false;
                    UserbtnSave.Visible = false;
                    UsersbtnCancel.Visible = false;
                    Userslblfname.Visible = false;
                    Userslbldob.Visible = false;
                    Userslblsname.Visible = false;
                    UsersTxtFirstName.Visible = false;
                    UsersTxtSurname.Visible = false;
                    UsersDatePicker.Visible = false;
                    UserstxtFaxNumber.Visible = false;
                    UserstxtStreetName.Visible = false;
                    UserstxtCity.Visible = false;
                    UserstxtCountry.Visible = false;
                    UserstxtEmail.Visible = false;
                    UserstxtPostalCode.Visible = false;
                    UserstxtTelNumber.Visible = false;
                    UserstxtPhoneNumber.Visible = false;
                    UserslblFax.Visible = false;
                    Userslblstreet.Visible = false;
                    Userslblcity.Visible = false;
                    Userslblcountry.Visible = false;
                    Userslblemail.Visible = false;
                    Userslblpostal.Visible = false;
                    Userslbltel.Visible = false;
                    Userslblphone.Visible = false;
                    UserstxtProvince.Visible = false;
                    UserslbProvince.Visible = false;
                    UserslblBuidingNumber.Visible = false;
                    UserstxtBuildingNumber.Visible = false;
                    
                    //Refresh list of users
                    dt = user.GetListOfUsers();
                    UsersCmbUsers.DataSource = dt;
                    UsersCmbUsers.DisplayMember = "Username";
                }
            }
        }

        private void UsersbtnUpdate_Click(object sender, EventArgs e)
        {
            if (UsersTxtUsername.Text == "" || UserstxtPassword.Text == "" || UsersCmbDepartment.Text == "" || UsersTxtFirstName.Text == "" || UsersTxtSurname.Text == "" || UserstxtFaxNumber.Text == "" || UserstxtStreetName.Text == "" || UserstxtCity.Text == "" || UserstxtCountry.Text == "" || UserstxtEmail.Text == "" || UserstxtPostalCode.Text == "" || UserstxtTelNumber.Text == "" || UserstxtPhoneNumber.Text == "")
            {
                MessageBox.Show("Please fill in all the fields before attempting to save");
            }
            else if (UsersDatePicker.Value == DateTime.Today)
            {
                MessageBox.Show("Date of birth cannot be today");
            }
            else
            {
                user = new User(UsersTxtUsername.Text, UserstxtPassword.Text, UsersCmbDepartment.Text, UsersTxtFirstName.Text, UsersTxtSurname.Text, UsersDatePicker.Value, UserstxtStreetName.Text, UserstxtCity.Text, UserstxtProvince.Text, UserstxtPostalCode.Text, UserstxtCountry.Text, UserstxtBuildingNumber.Text, UserstxtPhoneNumber.Text, UserstxtEmail.Text, UserstxtFaxNumber.Text, UserstxtTelNumber.Text);

                MessageBox.Show(user.UpdateUser(user.Username, user.Password, user.Department, user.Name, user.Surname, user.Dateofbirth, user.Streetname, user.City, user.Province, user.Postalcode, user.Country, user.Buildingnumber, user.Phonenumber, user.Email, user.Faxnumber, user.Telnumber));

                //Show controls
                UserbtnEdit.Visible = true;
                UserslblClient.Visible = true;
                UsersCmbUsers.Visible = true;
                UserbtnAdd.Visible = true;

                //Empty Fileds
                UsersTxtUsername.Text = "";
                UserstxtPassword.Text = "";
                UsersCmbDepartment.Text = "";
                UsersTxtFirstName.Text = "";
                UsersTxtSurname.Text = "";
                UserstxtFaxNumber.Text = "";
                UserstxtStreetName.Text = "";
                UserstxtCity.Text = "";
                UserstxtCountry.Text = "";
                UserstxtEmail.Text = "";
                UserstxtPostalCode.Text = "";
                UserstxtTelNumber.Text = "";
                UserstxtPhoneNumber.Text = "";

                //Hide controls
                UsersbtnDelete.Visible = false;
                UserslblDepartment.Visible = false;
                UserslblPassword.Visible = false;
                UserslblUsername.Visible = false;
                UserstxtPassword.Visible = false;
                UsersTxtUsername.Visible = false;
                UsersCmbDepartment.Visible = false;
                UsersbtnDelete.Visible = false;
                UsersbtnUpdate.Visible = false;
                UserbtnSave.Visible = false;
                UsersbtnCancel.Visible = false;
                Userslblfname.Visible = false;
                Userslbldob.Visible = false;
                Userslblsname.Visible = false;
                UsersTxtFirstName.Visible = false;
                UsersTxtSurname.Visible = false;
                UsersDatePicker.Visible = false;
                UserstxtFaxNumber.Visible = false;
                UserstxtStreetName.Visible = false;
                UserstxtCity.Visible = false;
                UserstxtCountry.Visible = false;
                UserstxtEmail.Visible = false;
                UserstxtPostalCode.Visible = false;
                UserstxtTelNumber.Visible = false;
                UserstxtPhoneNumber.Visible = false;
                UserslblFax.Visible = false;
                Userslblstreet.Visible = false;
                Userslblcity.Visible = false;
                Userslblcountry.Visible = false;
                Userslblemail.Visible = false;
                Userslblpostal.Visible = false;
                Userslbltel.Visible = false;
                Userslblphone.Visible = false;
                UserstxtProvince.Visible = false;
                UserslbProvince.Visible = false;
                UserslblBuidingNumber.Visible = false;
                UserstxtBuildingNumber.Visible = false;

                    //Refresh list of users
                    dt = user.GetListOfUsers();
                    UsersCmbUsers.DataSource = dt;
                    UsersCmbUsers.DisplayMember = "Username";
            }
        }

        private void UsersbtnDelete_Click(object sender, EventArgs e)
        {
            user = new User(UsersTxtUsername.Text, UserstxtPassword.Text);

            MessageBox.Show(user.DeletUser(user.Username));

            //Show controls
            UserbtnEdit.Visible = true;
            UserslblClient.Visible = true;
            UsersCmbUsers.Visible = true;
            UserbtnAdd.Visible = true;

            //Empty Fileds
            UsersTxtUsername.Text = "";
            UserstxtPassword.Text = "";
            UsersCmbDepartment.Text = "";
            UsersTxtFirstName.Text = "";
            UsersTxtSurname.Text = "";
            UserstxtFaxNumber.Text = "";
            UserstxtStreetName.Text = "";
            UserstxtCity.Text = "";
            UserstxtCountry.Text = "";
            UserstxtEmail.Text = "";
            UserstxtPostalCode.Text = "";
            UserstxtTelNumber.Text = "";
            UserstxtPhoneNumber.Text = "";

            //Hide controls
            UsersbtnDelete.Visible = false;
            UserslblDepartment.Visible = false;
            UserslblPassword.Visible = false;
            UserslblUsername.Visible = false;
            UserstxtPassword.Visible = false;
            UsersTxtUsername.Visible = false;
            UsersCmbDepartment.Visible = false;
            UsersbtnDelete.Visible = false;
            UsersbtnUpdate.Visible = false;
            UserbtnSave.Visible = false;
            UsersbtnCancel.Visible = false;
            Userslblfname.Visible = false;
            Userslbldob.Visible = false;
            Userslblsname.Visible = false;
            UsersTxtFirstName.Visible = false;
            UsersTxtSurname.Visible = false;
            UsersDatePicker.Visible = false;
            UserstxtFaxNumber.Visible = false;
            UserstxtStreetName.Visible = false;
            UserstxtCity.Visible = false;
            UserstxtCountry.Visible = false;
            UserstxtEmail.Visible = false;
            UserstxtPostalCode.Visible = false;
            UserstxtTelNumber.Visible = false;
            UserstxtPhoneNumber.Visible = false;
            UserslblFax.Visible = false;
            Userslblstreet.Visible = false;
            Userslblcity.Visible = false;
            Userslblcountry.Visible = false;
            Userslblemail.Visible = false;
            Userslblpostal.Visible = false;
            Userslbltel.Visible = false;
            Userslblphone.Visible = false;
            UserstxtProvince.Visible = false;
            UserslbProvince.Visible = false;
            UserslblBuidingNumber.Visible = false;
            UserstxtBuildingNumber.Visible = false;

            //Refresh list of users
            dt = user.GetListOfUsers();
            UsersCmbUsers.DataSource = dt;
            UsersCmbUsers.DisplayMember = "Username";
        }

        private void UsersbtnCancel_Click(object sender, EventArgs e)
        {
            //Show controls
            UserbtnEdit.Visible = true;
            UserslblClient.Visible = true;
            UsersCmbUsers.Visible = true;
            UserbtnAdd.Visible = true;

            //Empty Fileds
            UsersTxtUsername.Text = "";
            UserstxtPassword.Text = "";
            UsersCmbDepartment.Text = "";
            UsersTxtFirstName.Text = "";
            UsersTxtSurname.Text = "";
            UserstxtFaxNumber.Text = "";
            UserstxtStreetName.Text = "";
            UserstxtCity.Text = "";
            UserstxtCountry.Text = "";
            UserstxtEmail.Text = "";
            UserstxtPostalCode.Text = "";
            UserstxtTelNumber.Text = "";
            UserstxtPhoneNumber.Text = "";

            //Hide controls
            UsersbtnDelete.Visible = false;
            UserslblDepartment.Visible = false;
            UserslblPassword.Visible = false;
            UserslblUsername.Visible = false;
            UserstxtPassword.Visible = false;
            UsersTxtUsername.Visible = false;
            UsersCmbDepartment.Visible = false;
            UsersbtnDelete.Visible = false;
            UsersbtnUpdate.Visible = false;
            UserbtnSave.Visible = false;
            UsersbtnCancel.Visible = false;
            Userslblfname.Visible = false;
            Userslbldob.Visible = false;
            Userslblsname.Visible = false;
            UsersTxtFirstName.Visible = false;
            UsersTxtSurname.Visible = false;
            UsersDatePicker.Visible = false;
            UserstxtFaxNumber.Visible = false;
            UserstxtStreetName.Visible = false;
            UserstxtCity.Visible = false;
            UserstxtCountry.Visible = false;
            UserstxtEmail.Visible = false;
            UserstxtPostalCode.Visible = false;
            UserstxtTelNumber.Visible = false;
            UserstxtPhoneNumber.Visible = false;
            UserslblFax.Visible = false;
            Userslblstreet.Visible = false;
            Userslblcity.Visible = false;
            Userslblcountry.Visible = false;
            Userslblemail.Visible = false;
            Userslblpostal.Visible = false;
            Userslbltel.Visible = false;
            Userslblphone.Visible = false;
            UserstxtProvince.Visible = false;
            UserslbProvince.Visible = false;
            UserslblBuidingNumber.Visible = false;
            UserstxtBuildingNumber.Visible = false;
        }
    }
}
