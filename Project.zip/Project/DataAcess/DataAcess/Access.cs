﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace DataAcess
{
    public class Access
    {
        public static string constring = @"Data Source=MISHIKO\SQLEXPRESS;Initial Catalog=SHS;Integrated Security=True";
        public string query;
        public SqlCommand com;
        public SqlDataReader reader;
        public DataTable datatable;
        public SqlDataAdapter adapter;
        public DataSet dataset;
        public SqlConnection con = new SqlConnection(constring);
        
        public Access()
        {
 
        }

        //****************************************INDIVIDUAL CLIENT**************************************************

        //Insert new individual client
        public void InsertIndividualClient(string FirstName, string LastName, DateTime DateOfBirth, string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            //Generate ID
            Random rab = new Random();
            int idnum = rab.Next(1, 10000);
            string id = idnum.ToString();


            string addressquery = "INSERT INTO AddressTable([PK:AddressID],StreetName,City,Province,PostalCode,Country,BuildingNumber, [FK:PersonID]) VALUES(@addressid,@StreetName,@City,@Province,@PostalCode,@Country,@BuildingNumber, @personID)";
            string contactsquery = "INSERT INTO ContactsTable([PK:ContactID],PhoneNumber,Email,FaxNumber,TelNumber, [FK:PersonID]) VALUES(@contactID,@PhoneNumber,@Email,@FaxNumber,@TelNumber, @personID)";
            string personquery = "INSERT INTO PersonTable([PK:PersonID],Name,Surname,DateOBirth) VALUES(@personID,@name,@surname,@DateOBirth)";
            string clientquery = "INSERT INTO ClientTable([PK:ClientID],Status, [FK:PersonID]) VALUES(@ClientId,@Status,@personID)";
            string indclientquery = "INSERT INTO IndividualClientTable([FK:ClientID],[PK:IndClientID]) VALUES(@ClientID, @IndClientID)";

            con.Open();

            com = new SqlCommand(personquery, con);
            com.Parameters.AddWithValue("@personID", id);
            com.Parameters.AddWithValue("@name", FirstName);
            com.Parameters.AddWithValue("@surname", LastName);
            com.Parameters.AddWithValue("@DateOBirth", DateOfBirth);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            com = new SqlCommand(addressquery, con);
            com.Parameters.AddWithValue("@addressid", id);
            com.Parameters.AddWithValue("@StreetName", StreetName);
            com.Parameters.AddWithValue("@City", City);
            com.Parameters.AddWithValue("@Province", Province);
            com.Parameters.AddWithValue("@PostalCode", PostalCode);
            com.Parameters.AddWithValue("@Country", Country);
            com.Parameters.AddWithValue("@BuildingNumber", BuidingNumber);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            com = new SqlCommand(contactsquery, con);
            com.Parameters.AddWithValue("@contactID", id);
            com.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            com.Parameters.AddWithValue("@Email", Email);
            com.Parameters.AddWithValue("@FaxNumber", FaxNumber);
            com.Parameters.AddWithValue("@TelNumber", TelNumber);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();


            com = new SqlCommand(clientquery, con);
            com.Parameters.AddWithValue("@ClientId", id);
            com.Parameters.AddWithValue("@Status", Status);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            com = new SqlCommand(indclientquery, con);
            com.Parameters.AddWithValue("@ClientID", id);
            com.Parameters.AddWithValue("@IndClientID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();


            con.Close();
        }

        //Delete individual client
        public void DeleteIndividualClient(string FirstName, string LastName)
        {
            con.Open();
            com = new SqlCommand("DeleteIndidualClient", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@FirstName", FirstName);
            com.Parameters.AddWithValue("@LastName", LastName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //Update individual client
        public void UpdateIndividualClient(string FirstName, string LastName, DateTime DateOfBirth, string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            con.Open();
            com = new SqlCommand("UpdateIndividualClient", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@StreetName", StreetName);
            com.Parameters.AddWithValue("@City", City);
            com.Parameters.AddWithValue("@Province", Province);
            com.Parameters.AddWithValue("@PostalCode", PostalCode);
            com.Parameters.AddWithValue("@Country", Country);
            com.Parameters.AddWithValue("@BuildingNumber", BuidingNumber);
            com.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            com.Parameters.AddWithValue("@Email", Email);
            com.Parameters.AddWithValue("@FaxNumber", FaxNumber);
            com.Parameters.AddWithValue("@TelNumber", TelNumber);
            com.Parameters.AddWithValue("@name", FirstName);
            com.Parameters.AddWithValue("@surname", LastName);
            com.Parameters.AddWithValue("@DateOBirth", DateOfBirth);
            com.Parameters.AddWithValue("@Status", Status);
            reader = com.ExecuteReader();
            con.Close();
        }

        //****************************************BUSINESS CLIENT**************************************************

        public void InsertBusinessClient(string CompanyName, string Status, string ManagerName, string SupervisorName, string ManagerPhone, string SupervisorPhone, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            //Generate ID
            Random rab = new Random();
            int id = rab.Next(1, 1000);

            string addressquery = "INSERT INTO AddressTable([PK:AddressID],StreetName,City,Province,PostalCode,Country,BuildingNumber, [FK:PersonID]) VALUES(@addressid,@StreetName,@City,@Province,@PostalCode,@Country,@BuildingNumber, @personID)";
            string contactsquery = "INSERT INTO ContactsTable([PK:ContactID],PhoneNumber,Email,FaxNumber,TelNumber, [FK:PersonID]) VALUES(@contactID,@PhoneNumber,@Email,@FaxNumber,@TelNumber, @personID)";
            string personquery = "INSERT INTO PersonTable([PK:PersonID]) VALUES(@personID)";
            string clientquery = "INSERT INTO ClientTable([PK:ClientID],Status, [FK:PersonID]) VALUES(@ClientId,@Status,@personID)";
            string busclientquery = "INSERT INTO BusinessClientTable([FK:ClientID],[PK:BusClientID], ManagerName, ManagerNumber, SupervisorName, SupervisorNumber, CompanyName) VALUES(@ClientID, @BusClientID,  @ManagerName, @ManagerNumber, @SupervisorName, @SupervisorNumber, @Company)";

            con.Open();

            com = new SqlCommand(personquery, con);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            com = new SqlCommand(addressquery, con);
            com.Parameters.AddWithValue("@addressid", id);
            com.Parameters.AddWithValue("@StreetName", StreetName);
            com.Parameters.AddWithValue("@City", City);
            com.Parameters.AddWithValue("@Province", Province);
            com.Parameters.AddWithValue("@PostalCode", PostalCode);
            com.Parameters.AddWithValue("@Country", Country);
            com.Parameters.AddWithValue("@BuildingNumber", BuidingNumber);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            com = new SqlCommand(contactsquery, con);
            com.Parameters.AddWithValue("@contactID", id);
            com.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            com.Parameters.AddWithValue("@Email", Email);
            com.Parameters.AddWithValue("@FaxNumber", FaxNumber);
            com.Parameters.AddWithValue("@TelNumber", TelNumber);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();


            com = new SqlCommand(clientquery, con);
            com.Parameters.AddWithValue("@ClientId", id);
            com.Parameters.AddWithValue("@Status", Status);
            com.Parameters.AddWithValue("@personID", id);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            com = new SqlCommand(busclientquery, con);
            com.Parameters.AddWithValue("@ClientId", id);
            com.Parameters.AddWithValue("@BusClientID", id);
            com.Parameters.AddWithValue("@ManagerName", ManagerName);
            com.Parameters.AddWithValue("@ManagerNumber", ManagerPhone);
            com.Parameters.AddWithValue("@SupervisorName", SupervisorName);
            com.Parameters.AddWithValue("@SupervisorNumber", SupervisorPhone);
            com.Parameters.AddWithValue("@Company", CompanyName);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

            con.Close();
        }

        //Delete Business client
        public void DeleteBusinessClient(string CompanyName)
        {
            con.Open();
            com = new SqlCommand("DeleteBussiness", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@CompanyName", CompanyName);
            com.ExecuteScalar().ToString();
            con.Close();
        }

        //Update Business client
        public void UpdateBusinessClient(string CompanyName, string Status, string ManagerName, string SupervisorName, string ManagerPhone, string SupervisorPhone, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                com = new SqlCommand("UpdateBusinessClient", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@CompanyName", CompanyName);
                com.Parameters.AddWithValue("@ManagerName", ManagerName);
                com.Parameters.AddWithValue("@ManagerNum", ManagerPhone);
                com.Parameters.AddWithValue("@SupervisorName", SupervisorName);
                com.Parameters.AddWithValue("@SupervisorNum", SupervisorPhone);
                com.Parameters.AddWithValue("@StreetName", StreetName);
                com.Parameters.AddWithValue("@City", City);
                com.Parameters.AddWithValue("@Province", Province);
                com.Parameters.AddWithValue("@PostalCode", PostalCode);
                com.Parameters.AddWithValue("@Country", Country);
                com.Parameters.AddWithValue("@BuildingNumber", BuidingNumber);
                com.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@FaxNumber", FaxNumber);
                com.Parameters.AddWithValue("@TelNumber", TelNumber);
                reader = com.ExecuteReader();
            }
        }
 
        //****************************************USER**************************************************
        
        //Insert new user
        public void InsertUser(string username, string password, string Department, string name, string surname, DateTime DateOfBirth, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            //Generate ID
            Random rab = new Random();
            int idnum = rab.Next(1, 1000);
            string id = idnum.ToString();


            string addressquery = "INSERT INTO AddressTable([PK:AddressID],StreetName,City,Province,PostalCode,Country,BuildingNumber, [FK:PersonID]) VALUES(@addressid,@StreetName,@City,@Province,@PostalCode,@Country,@BuildingNumber, @personID)";
            string contactsquery = "INSERT INTO ContactsTable([PK:ContactID],PhoneNumber,Email,FaxNumber,TelNumber, [FK:PersonID]) VALUES(@contactID,@PhoneNumber,@Email,@FaxNumber,@TelNumber, @personID)";
            string personquery = "INSERT INTO PersonTable([PK:PersonID],Name,Surname,DateOBirth) VALUES(@personID,@name,@surname,@DateOBirth)";
            string employeequery = "INSERT INTO EmployeeTable([PK:EmployeeID],[FK:PersonID]) VALUES(@employeeID,@personID)";
            string userquery = "INSERT INTO UserTable([PK:UserID],Username,Password,Department,[FK:EmployeeID]) VALUES(@userID,@username,@password ,@Department,@employeeID)";

                con.Open();
                com = new SqlCommand(personquery, con);
                com.Parameters.AddWithValue("@personID", id);
                com.Parameters.AddWithValue("@name", name);
                com.Parameters.AddWithValue("@surname", surname);
                com.Parameters.AddWithValue("@DateOBirth", DateOfBirth);
                reader = com.ExecuteReader();
                com.Dispose();
                reader.Dispose();

            com = new SqlCommand(addressquery, con);
                com.Parameters.AddWithValue("@addressid", id);
                com.Parameters.AddWithValue("@StreetName", StreetName);
                com.Parameters.AddWithValue("@City", City);
                com.Parameters.AddWithValue("@Province", Province);
                com.Parameters.AddWithValue("@PostalCode", PostalCode);
                com.Parameters.AddWithValue("@Country", Country);
                com.Parameters.AddWithValue("@BuildingNumber", BuidingNumber);
                com.Parameters.AddWithValue("@personID", id);
                reader = com.ExecuteReader();
                com.Dispose();
                reader.Dispose();

                com = new SqlCommand(contactsquery, con);
                com.Parameters.AddWithValue("@contactID", id);
                com.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                com.Parameters.AddWithValue("@Email", Email);
                com.Parameters.AddWithValue("@FaxNumber", FaxNumber);
                com.Parameters.AddWithValue("@TelNumber", TelNumber);
                com.Parameters.AddWithValue("@personID", id);
                reader = com.ExecuteReader();
                com.Dispose();
                reader.Dispose();

                

                com = new SqlCommand(employeequery, con);
                com.Parameters.AddWithValue("@employeeID", id);
                com.Parameters.AddWithValue("@personID", id);
                reader = com.ExecuteReader();
                com.Dispose();
                reader.Dispose();

                com = new SqlCommand(userquery, con);
                com.Parameters.AddWithValue("@userID", id);
                com.Parameters.AddWithValue("@username", username);
                com.Parameters.AddWithValue("@password", password);
                com.Parameters.AddWithValue("@Department", Department);
                com.Parameters.AddWithValue("@employeeID", id);
                reader = com.ExecuteReader();
                com.Dispose();
                reader.Dispose();
                
                
                con.Close();
        }

        //Delete user
        public void DeleteUser(string username)
        {

            con.Open();
            com = new SqlCommand("DeleteUser", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@username", username);
            com.ExecuteScalar().ToString();
            con.Close();
        }

        //Update user
        public void UpdateUser(string username, string password, string Department, string name, string surname, DateTime DateOBirth, string StreetName, string PhoneNumber, string email, string faxNumber, string TelNumber, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
       
            con.Open();
            com = new SqlCommand("UpdateUser", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@name", name);
            com.Parameters.AddWithValue("@surname", surname);
            com.Parameters.AddWithValue("@DateOBirth", DateOBirth);
            com.Parameters.AddWithValue("@username", username);
            com.Parameters.AddWithValue("@password", password);
            com.Parameters.AddWithValue("@Department", Department);
            com.Parameters.AddWithValue("@StreetName", StreetName);
            com.Parameters.AddWithValue("@City", City);
            com.Parameters.AddWithValue("@Province", Province);
            com.Parameters.AddWithValue("@PostalCode", PostalCode);
            com.Parameters.AddWithValue("@Country", Country);
            com.Parameters.AddWithValue("@BuildingNumber", BuidingNumber);
            com.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            com.Parameters.AddWithValue("@Email", email);
            com.Parameters.AddWithValue("@FaxNumber", faxNumber);
            com.Parameters.AddWithValue("@TelNumber", TelNumber);
            reader = com.ExecuteReader();
            con.Close();
        }

        //****************************************SERVICES**************************************************

        //Insert service
        public void InsertService(string ServiceName, string ServiceDescriptionn, string Duration, string Priority)
        {
            //Generate ID
            Random rab = new Random();
            int idnum = rab.Next(1, 1000);
            string id = idnum.ToString();


            string query = "INSERT INTO ServiceTable([PK:ServiceID],ServiceName,ServiceDescription,Duration,Priority) VALUES(@id,@ServiceName,@ServiceDescriptionn,@Duration,@Priority)";

            con.Open();

            com = new SqlCommand(query, con);
            com.Parameters.AddWithValue("@id", id);
            com.Parameters.AddWithValue("@ServiceName", ServiceName);
            com.Parameters.AddWithValue("@ServiceDescriptionn", ServiceDescriptionn);
            com.Parameters.AddWithValue("@Duration", Duration);
            com.Parameters.AddWithValue("@Priority", Priority);
            reader = com.ExecuteReader();
            com.Dispose();
            reader.Dispose();

           con.Close();
        }

        //Delete service
        public void DeleteService(string ServiceName)
        {

            con.Open();
            com = new SqlCommand("DeleteService", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ServiceName", ServiceName);
            reader = com.ExecuteReader();
            con.Close();
        }


        //Update service
        public void UpdateService(string ServiceName, string ServiceDescription, string Duration, string Priority)
        {


            con.Open();
            com = new SqlCommand("UpdatService", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ServiceName", ServiceName);
            com.Parameters.AddWithValue("@ServiceDescription", ServiceDescription);
            com.Parameters.AddWithValue("@Duration", Duration);
            com.Parameters.AddWithValue("@Priority", Priority);
            reader = com.ExecuteReader();
            con.Close();
        }

        //****************************************PACKAGES*****************************************************

        //Insert package
        public void InsertPackage(string PackageName, string PackageLevel, string Service1, string Service2, string Service3, string Service4)
        {
            //Generate ID
            Random rab = new Random();
            int idnum = rab.Next(1, 1000);
            string id = idnum.ToString();

            con.Open();
            com = new SqlCommand("InsertPacket", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@id", id);
            com.Parameters.AddWithValue("@PackageName", PackageName);
            com.Parameters.AddWithValue("@PackageLevel", PackageLevel);
            com.Parameters.AddWithValue("@Service1", Service3);
            com.Parameters.AddWithValue("@Service2", Service2);
            com.Parameters.AddWithValue("@Service3", Service3);
            com.Parameters.AddWithValue("@Service4", Service4);
            reader = com.ExecuteReader();
            con.Close();
        }

        //****************************************CONTRACTS*****************************************************

        //+++++++++++++++++++++++++ INDIVIDUAL+++++++++++++++++++++++
        
        //Insert contract
        public void InsertContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string ClientName, string ClientLastName)
        {
            //Generate ID
            Random rab = new Random();
            int idnum = rab.Next(1, 1000);
            string id = idnum.ToString();

            con.Open();
            com = new SqlCommand("InsertContract", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ContractLevel", ContractLevel);
            com.Parameters.AddWithValue("@Package", Package);
            com.Parameters.AddWithValue("@StartDate", StartDate);
            com.Parameters.AddWithValue("@EndDate", EndDate);
            com.Parameters.AddWithValue("@ClientFirstName", ClientName);
            com.Parameters.AddWithValue("@ClientLastName", ClientLastName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //Update contract
        public void UpdateContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string ClientName, string ClientLastName)
        {
            //Generate ID
      
            con.Open();
            com = new SqlCommand("UpdateContract", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ContractLevel", ContractLevel);
            com.Parameters.AddWithValue("@Package", Package);
            com.Parameters.AddWithValue("@StartDate", StartDate);
            com.Parameters.AddWithValue("@EndDate", EndDate);
            com.Parameters.AddWithValue("@ClientFirstName", ClientName);
            com.Parameters.AddWithValue("@ClientLastName", ClientLastName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //Delete contract
        public void DeleteContract(string FirstName, string LastName)
        {
            con.Open();
            com = new SqlCommand("DeleteContract", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@FirstName", FirstName);
            com.Parameters.AddWithValue("@LastName", LastName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //+++++++++++++++++++++++++ BUSINESS+++++++++++++++++++++++
        //Insert business contract
        public void InsertbusinessContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string CompanyName)
        {
            //Generate ID
            Random rab = new Random();
            int idnum = rab.Next(1, 1000);
            string id = idnum.ToString();

            con.Open();
            com = new SqlCommand("InsertbusinessContract", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ContractLevel", ContractLevel);
            com.Parameters.AddWithValue("@Package", Package);
            com.Parameters.AddWithValue("@StartDate", StartDate);
            com.Parameters.AddWithValue("@EndDate", EndDate);
            com.Parameters.AddWithValue("@Company", CompanyName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //Update business contract
        public void UpdatebusinessContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string CompanyName)
        {
            //Generate ID

            con.Open();
            com = new SqlCommand("UpdatebusinessContract", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@ContractLevel", ContractLevel);
            com.Parameters.AddWithValue("@Package", Package);
            com.Parameters.AddWithValue("@StartDate", StartDate);
            com.Parameters.AddWithValue("@EndDate", EndDate);
            com.Parameters.AddWithValue("@CompanyName", CompanyName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //Delete business contract
        public void DeletebusinessContract(string CompanyName)
        {
            con.Open();
            com = new SqlCommand("DeletebusinessContract", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@CompanyName", CompanyName);
            reader = com.ExecuteReader();
            con.Close();
        }

        //****************************************CALL*****************************************************

        //Insert call from individual client
        public void InsertIndividualCall(DateTime Date, string Firstname, string Lastname)
        {

            con.Open();
            com = new SqlCommand("InsertIndividualCall", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Date", Date);
            com.Parameters.AddWithValue("@Firstname", Firstname);
            com.Parameters.AddWithValue("@Lastname", Lastname);
            reader = com.ExecuteReader();
            con.Close();
        }

        //Insert call from business client
        public void InsertIndividualCall(DateTime Date, string Company)
        {

            con.Open();
            com = new SqlCommand("InsertIndividualCall", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Date", Date);
            com.Parameters.AddWithValue("@Company", Company);
            reader = com.ExecuteReader();
            con.Close();
        }
        
        //****************************************GET METHODS**************************************************

        //+++++++++++++++++++++++++ USER GET METHODS+++++++++++++++++++++++

        //Access UserTable for login
        public DataTable Usertable()
        {
            datatable = new DataTable(); 

            using (SqlConnection con = new SqlConnection(constring))
            {
                adapter = new SqlDataAdapter("SELECT * FROM UserTable", con); 
                adapter.Fill(datatable);
                return datatable;
            }
        }

        //Get user details
        public Dictionary<string, string> UserDetails(string username)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetUserDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Username", username);
            con.Open();

            reader = com.ExecuteReader();
            
            while (reader.Read())
            {
                    Details.Clear();
                    Details.Add("Username", reader["Username"].ToString());
                    Details.Add("Password", reader["Password"].ToString());
                    Details.Add("Department", reader["Department"].ToString());
                    Details.Add("Name", reader["Name"].ToString());
                    Details.Add("Surname", reader["Surname"].ToString());
                    Details.Add("StreetName", reader["StreetName"].ToString());
                    Details.Add("DateOfBirth", Convert.ToString(reader["DateOfBirth"]));
                    Details.Add("City", reader["City"].ToString());
                    Details.Add("Province", reader["Province"].ToString());
                    Details.Add("PostalCode", reader["PostalCode"].ToString());
                    Details.Add("Country", reader["Country"].ToString());
                    Details.Add("BuildingNumber", reader["BuildingNumber"].ToString());
                    Details.Add("PhoneNumber", reader["PhoneNumber"].ToString());
                    Details.Add("Email", reader["Email"].ToString());
                    Details.Add("FaxNumber", reader["FaxNumber"].ToString());
                    Details.Add("TelNumber", reader["TelNumber"].ToString());

                    if (Details["Username"] == username)
                    {
                        break;
                    }
                    
            }

            con.Close();
                
            
            return Details;
        }

        //+++++++++++++++++++++++++ SERVICE GET METHODS+++++++++++++++++++++++
        
        //Get list of services
        public DataTable ServiceTable()
        {
            datatable = new DataTable();

            using (SqlConnection con = new SqlConnection(constring))
            {
                adapter = new SqlDataAdapter("SELECT * FROM ServiceTable", con); 
                adapter.Fill(datatable);
                return datatable;
            }
        }

        //Get service details
        public Dictionary<string, string> ServiceDetails(string servicename)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("SELECT * FROM ServiceTable", con);
            con.Open();

            reader = com.ExecuteReader();

            while (reader.Read())
            {
                Details.Clear();
                Details.Add("ServiceName", reader["ServiceName"].ToString());
                Details.Add("ServiceDescription", reader["ServiceDescription"].ToString());
                Details.Add("Duration", reader["Duration"].ToString());
                Details.Add("Priority", reader["Priority"].ToString());

                if (Details["ServiceName"] == servicename)
                {
                    break;
                }
            }
            con.Close();

            return Details;
        }

        

        //+++++++++++++++++++++++++ PACKAGE GET METHODS+++++++++++++++++++++++

        //Get list of packages
        public DataTable PackageTable()
        {
            datatable = new DataTable();

            using (SqlConnection con = new SqlConnection(constring))
            {
                adapter = new SqlDataAdapter("SELECT * FROM PackageTable", con);
                adapter.Fill(datatable);
                return datatable;
            }
        }

        //Get packages details
        public Dictionary<string, string> PackageDetails(string packagename)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("SELECT * FROM PackageTable", con);
            con.Open();

            reader = com.ExecuteReader();

            while (reader.Read())
            {
                Details.Clear();
                Details.Add("PackageName", reader["PackageName"].ToString());
                Details.Add("PackageLevel", reader["PackageLevel"].ToString());
                Details.Add("Service1", reader["FK:Service1"].ToString());
                Details.Add("Service2", reader["FK:Service2"].ToString());
                Details.Add("Service3", reader["FK:Service3"].ToString());
                Details.Add("Service4", reader["FK:Service4"].ToString());

                if (Details["PackageName"] == packagename)
                {
                    break;
                }
            }
            con.Close();

            return Details;
        }

        //+++++++++++++++++++++++++ INDIVIDUAL CLIENT GET METHODS+++++++++++++++++++++++

        //Get list of Individual Clients
        public DataTable IndividualTable()
        {
            datatable = new DataTable();

            con.Open();
            adapter = new SqlDataAdapter("GetListOfIndividualClients", con);
            adapter.Fill(datatable);
            con.Close();
            return datatable;
        }

        //get all individual client info
        public Dictionary<string, string> IndividualClientDetails(string FirstName, string LastName)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetIndividualClientDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@FirstName", FirstName);
            com.Parameters.AddWithValue("@LastName", LastName);
            con.Open();

            reader = com.ExecuteReader();

            while (reader.Read())
            {
                Details.Clear();
                Details.Add("Status", reader["Status"].ToString());
                Details.Add("Name", reader["Name"].ToString());
                Details.Add("Surname", reader["Surname"].ToString());
                Details.Add("StreetName", reader["StreetName"].ToString());
                Details.Add("DateOfBirth", Convert.ToString(reader["DateOfBirth"]));
                Details.Add("City", reader["City"].ToString());
                Details.Add("Province", reader["Province"].ToString());
                Details.Add("PostalCode", reader["PostalCode"].ToString());
                Details.Add("Country", reader["Country"].ToString());
                Details.Add("BuildingNumber", reader["BuildingNumber"].ToString());
                Details.Add("PhoneNumber", reader["PhoneNumber"].ToString());
                Details.Add("Email", reader["Email"].ToString());
                Details.Add("FaxNumber", reader["FaxNumber"].ToString());
                Details.Add("TelNumber", reader["TelNumber"].ToString());

                if (Details["Name"] == FirstName && Details["Surname"] == LastName)
                {
                    break;
                }

            }

            con.Close();


            return Details;
        }

        //get random individual client info
        public Dictionary<string, string> RandomIndividualClientDetails()
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetRandomIndividualClient", con);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();

            reader = com.ExecuteReader();

            while (reader.Read())
            {
                Details.Clear();
                Details.Add("Status", reader["Status"].ToString());
                Details.Add("Name", reader["Name"].ToString());
                Details.Add("Surname", reader["Surname"].ToString());
                Details.Add("StreetName", reader["StreetName"].ToString());
                Details.Add("DateOfBirth", Convert.ToString(reader["DateOfBirth"]));
                Details.Add("City", reader["City"].ToString());
                Details.Add("Province", reader["Province"].ToString());
                Details.Add("PostalCode", reader["PostalCode"].ToString());
                Details.Add("Country", reader["Country"].ToString());
                Details.Add("BuildingNumber", reader["BuildingNumber"].ToString());
                Details.Add("PhoneNumber", reader["PhoneNumber"].ToString());
                Details.Add("Email", reader["Email"].ToString());
                Details.Add("FaxNumber", reader["FaxNumber"].ToString());
                Details.Add("TelNumber", reader["TelNumber"].ToString());

            }

            con.Close();
            return Details;
        }

        //+++++++++++++++++++++++++ BUSINESS CLIENT GET METHODS+++++++++++++++++++++++
        //Get list of Business Clients
        public DataTable BusinessTable()
        {
            datatable = new DataTable();
            string query = "SELECT * FROM BusinessClientTable";
            con.Open();
            adapter = new SqlDataAdapter(query, con);
            adapter.Fill(datatable);
            con.Close();
            return datatable;
        }

        //get all business client info
        public Dictionary<string, string> IndividualBusinessClientDetails(string CompanyName)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetBusinessClientDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@CompanyName", CompanyName);
            con.Open();

            reader = com.ExecuteReader();

            while (reader.Read())
            {
                Details.Clear();
                Details.Add("Status", reader["Status"].ToString());
                Details.Add("CompanyName", reader["CompanyName"].ToString());
                Details.Add("ManagerName", reader["ManagerName"].ToString());
                Details.Add("ManagerNumber", reader["ManagerNumber"].ToString());
                Details.Add("SupervisorName", reader["SupervisorName"].ToString());
                Details.Add("SupervisorNumber", reader["SupervisorNumber"].ToString());
                Details.Add("StreetName", reader["StreetName"].ToString());
                Details.Add("City", reader["City"].ToString());
                Details.Add("Province", reader["Province"].ToString());
                Details.Add("PostalCode", reader["PostalCode"].ToString());
                Details.Add("Country", reader["Country"].ToString());
                Details.Add("BuildingNumber", reader["BuildingNumber"].ToString());
                Details.Add("PhoneNumber", reader["PhoneNumber"].ToString());
                Details.Add("Email", reader["Email"].ToString());
                Details.Add("FaxNumber", reader["FaxNumber"].ToString());
                Details.Add("TelNumber", reader["TelNumber"].ToString());

                if (Details["CompanyName"] == CompanyName)
                {
                    break;
                }

            }
            return Details;
        }

        //get random business client info
        public Dictionary<string, string> RandomBusinessClientDetails()
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetRandomBusinessClient", con);
            com.CommandType = CommandType.StoredProcedure;
            con.Open();

            reader = com.ExecuteReader();

            while (reader.Read())
            {
                Details.Clear();
                Details.Add("Status", reader["Status"].ToString());
                Details.Add("CompanyName", reader["CompanyName"].ToString());
                Details.Add("ManagerName", reader["ManagerName"].ToString());
                Details.Add("ManagerNumber", reader["ManagerNumber"].ToString());
                Details.Add("SupervisorName", reader["SupervisorName"].ToString());
                Details.Add("SupervisorNumber", reader["SupervisorNumber"].ToString());
                Details.Add("StreetName", reader["StreetName"].ToString());
                Details.Add("City", reader["City"].ToString());
                Details.Add("Province", reader["Province"].ToString());
                Details.Add("PostalCode", reader["PostalCode"].ToString());
                Details.Add("Country", reader["Country"].ToString());
                Details.Add("BuildingNumber", reader["BuildingNumber"].ToString());
                Details.Add("PhoneNumber", reader["PhoneNumber"].ToString());
                Details.Add("Email", reader["Email"].ToString());
                Details.Add("FaxNumber", reader["FaxNumber"].ToString());
                Details.Add("TelNumber", reader["TelNumber"].ToString());

            }

            con.Close();
            return Details;
        }

        //+++++++++++++++++++++++++ CONTRACT GET METHODS+++++++++++++++++++++++
        
        //Get contract details
        public Dictionary<string, string> ContractDetails(string FirstName, string LastName)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetContractDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@FirstName", FirstName);
            com.Parameters.AddWithValue("@LastName", LastName);
            con.Open();

            reader = com.ExecuteReader();


            while (reader.Read())
            {
                Details.Clear();
                Details.Add("ContractLevel", reader["ContractLevel"].ToString());
                Details.Add("Package", reader["Package"].ToString());

            }

            con.Close();

            return Details;
        }

        //Get contract details
        public Dictionary<string, string> ContractBusinessDetails(string CompanyName)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();

            com = new SqlCommand("GetContractDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@CompanyName", CompanyName);
            con.Open();

            reader = com.ExecuteReader();


            while (reader.Read())
            {
                Details.Clear();
                Details.Add("ContractLevel", reader["ContractLevel"].ToString());
                Details.Add("Package", reader["Package"].ToString());

            }

            con.Close();

            return Details;
        }

        //+++++++++++++++++++++++++ CALL HISTORY GET METHODS+++++++++++++++++++++++
        //Get indivudual Call History
        public DataTable IndividualCallTable(string Firstname, string Lastname)
        {
            datatable = new DataTable();

            con.Open();
            adapter = new SqlDataAdapter("IndividualCallTable", con);
            com.Parameters.AddWithValue("@Firstname", Firstname);
            com.Parameters.AddWithValue("@Lastname", Lastname);
            adapter.Fill(datatable);
            con.Close();
            return datatable;
        }

        //Get Business Call History
        public DataTable BusinessCallTable(string Company)
        {
            datatable = new DataTable();

            con.Open();
            adapter = new SqlDataAdapter("BusinessCallTable", con);
            com.Parameters.AddWithValue("@Company", Company);
            adapter.Fill(datatable);
            con.Close();
            return datatable;
        }

    }
}
