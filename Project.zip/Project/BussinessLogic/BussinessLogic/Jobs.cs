﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BussinessLogic
{
    class Jobs
    {
        private DateTime Date;

        public DateTime Date1
        {
            get { return Date; }
            set { Date = value; }
        }
        private string Status;

        public string Status1
        {
            get { return Status; }
            set { Status = value; }
        }
    }
}
