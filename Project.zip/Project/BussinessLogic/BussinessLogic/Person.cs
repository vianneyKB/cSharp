﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BussinessLogic
{
    public abstract class Person
    {
        //Personal information
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string surname;

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        private DateTime dateofbirth;

        public DateTime Dateofbirth
        {
            get { return dateofbirth; }
            set { dateofbirth = value; }
        }

        private string streetname;

        public string Streetname
        {
            get { return streetname; }
            set { streetname = value; }
        }

        private string city;

        public string City
        {
            get { return city; }
            set { city = value; }
        }
        private string province;

        public string Province
        {
            get { return province; }
            set { province = value; }
        }
        private string postalcode;

        public string Postalcode
        {
            get { return postalcode; }
            set { postalcode = value; }
        }
        private string country;

        public string Country
        {
            get { return country; }
            set { country = value; }
        }
        private string buildingnumber;

        public string Buildingnumber
        {
            get { return buildingnumber; }
            set { buildingnumber = value; }
        }
        private string phonenumber;

        public string Phonenumber
        {
            get { return phonenumber; }
            set { phonenumber = value; }
        }
        private string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        private string faxnumber;

        public string Faxnumber
        {
            get { return faxnumber; }
            set { faxnumber = value; }
        }
        private string telnumber;

        public string Telnumber
        {
            get { return telnumber; }
            set { telnumber = value; }
        }
        
        public Person()
        { }

        public Person(string FirstName, string LastName, DateTime DateOfBirth, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            name = FirstName;
            surname = LastName;
            dateofbirth = DateOfBirth;
            city = City;
            province = Province;
            postalcode = PostalCode;
            country = Country;
            buildingnumber = BuidingNumber;
            phonenumber = PhoneNumber;
            email = Email;
            faxnumber = FaxNumber;
            telnumber = TelNumber;
            streetname = StreetName;
        }

        public Person(string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            city = City;
            province = Province;
            postalcode = PostalCode;
            country = Country;
            buildingnumber = BuidingNumber;
            phonenumber = PhoneNumber;
            email = Email;
            faxnumber = FaxNumber;
            telnumber = TelNumber;
            streetname = StreetName;
        }

        public Person(string FirstName, string LastName)
        {
            name = FirstName;
            surname = LastName;
        }
    }
}
