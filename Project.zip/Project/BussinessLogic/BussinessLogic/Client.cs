﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public abstract class Client : Person
    {
        private string status;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public Client()
        {
 
        }


        public Client(string FirstName, string LastName, DateTime DateOfBirth, string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
            : base(FirstName, LastName, DateOfBirth, StreetName, City, Province, PostalCode, Country, BuidingNumber, PhoneNumber, Email, FaxNumber, TelNumber)
        {
            
        }

        public Client(string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
            : base(StreetName, City, Province, PostalCode, Country, BuidingNumber, PhoneNumber, Email, FaxNumber, TelNumber)
        {

        }

        public Client(string FirstName, string LastName)
            : base(FirstName, LastName)
        {

        }

    }
}
