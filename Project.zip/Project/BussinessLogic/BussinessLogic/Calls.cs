﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class Calls 
    {

        Access dataacess = new Access();

        private DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
        private string firstname;

        public string Firstname
        {
            get { return firstname; }
            set { firstname = value; }
        }
        private string lastname;

        public string Lastname
        {
            get { return lastname; }
            set { lastname = value; }
        }
        private string company;

        public string Company
        {
            get { return company; }
            set { company = value; }
        }

        public Calls()
        { 
        }

        public Calls(DateTime Date, string Firstname, string Lastname)
        {
            this.date = Date;
            this.firstname = Firstname;
            this.lastname = Lastname;
        }

        public Calls(DateTime Date, string Company)
        {
            this.date = Date;
            this.company = Company;
        }

        //individual Call table
        public DataTable IndividualCallTable(string Firstname, string Lastname)
        {
            DataTable calltable = dataacess.IndividualCallTable(Firstname, Lastname);
            return calltable;
        }

        //business Call table
        public DataTable BusinessCallTable(string Company)
        {
            DataTable calltable = dataacess.BusinessCallTable(Company);
            return calltable;
        }
    }
}
