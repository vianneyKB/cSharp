﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class IndividualClient : Client
    {
        DataTable listofIndividualClients;
        Access dataacess = new Access();

         public IndividualClient()
         {

         }

         public IndividualClient(string FirstName, string LastName, DateTime DateOfBirth, string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
             : base(FirstName, LastName, DateOfBirth, Status, StreetName, City, Province, PostalCode, Country, BuidingNumber, PhoneNumber, Email, FaxNumber, TelNumber)
        {

        }

        //Insert Individual client
        public  string InsertClient(string FirstName, string LastName, DateTime DateOfBirth, string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            string success;
            try
            {
                dataacess.InsertIndividualClient(FirstName, LastName, DateOfBirth, Status, PhoneNumber, Email, FaxNumber, TelNumber, StreetName, City, Province, PostalCode, Country, BuidingNumber);
                success = "Client added";
            }
            catch (Exception error)
            {

                success = "Failed to add client. Error:  " + error.ToString();
            }

            return success;
        }

        //Update individual client
        public string UpdateIndividualClient(string FirstName, string LastName, DateTime DateOfBirth, string Status, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            string success;
            try
            {
                dataacess.UpdateIndividualClient(FirstName, LastName, DateOfBirth, Status, PhoneNumber, Email, FaxNumber, TelNumber, StreetName, City, Province, PostalCode, Country, BuidingNumber);
                success = "Client updated";
            }
            catch (Exception error)
            {

                success = "Failed to update Client. Error:  " + error.ToString();
            }

            return success;

        }

        //Delete Individual Client
        public string DeleteIndividualClient(string FirstName, string LastName)
        {
            string success;
            try
            {
                dataacess.DeleteIndividualClient(FirstName, LastName);
                success = "Client deleted";
            }
            catch (Exception error)
            {

                success = "Failed to deleted Client. Error:  " + error.ToString();
            }

            return success;

        }

        //Check if Individual client already exist
        public  string Existence(string FirstName, string LastName)
        {
            string exists = "";

            //DataAccess getting user table from data access layer
            listofIndividualClients = dataacess.IndividualTable();


            //Loop through database
            foreach (DataRow row in listofIndividualClients.Rows)
            {
                //And search for Username and Pass that match
                if (row.ItemArray[1].Equals(FirstName) && row.ItemArray[2].Equals(FirstName))
                {
                    //If exists
                    exists = "true";
                    break;
                }
                else
                {
                    //If not does not exist
                    exists = "false";
                }
            }

            return exists;
        }

        //+++++++++++++++++++++++++     Individual client GET METHODS+++++++++++++++++++++++
        //Get list of individual client
        public  DataTable GetListOfclients()
        {
            DataTable ListOfClients = dataacess.IndividualTable();
            return ListOfClients;
        }

        //Get specific Individual client's details
        public  IndividualClient ReturnAllclientInfo(string FirstName, string LastName)
            {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.IndividualClientDetails(FirstName, LastName))
            {
                Details.Add(item.Key, item.Value);
            }

            string status = Details["Status"].ToString();
            string name = Details["Name"].ToString();
            string surname = Details["Surname"].ToString(); ;
            DateTime dateofbirth = Convert.ToDateTime(Details["DateOfBirth"]);
            string streetname = Details["StreetName"].ToString();
            string city = Details["City"].ToString();
            string province = Details["Province"].ToString();
            string postalcode = Details["PostalCode"].ToString();
            string country = Details["Country"].ToString();
            string buildingnumber = Details["BuildingNumber"].ToString();
            string phonenumber = Details["PhoneNumber"].ToString();
            string email = Details["Email"].ToString();
            string faxnumber = Details["FaxNumber"].ToString();
            string telnumber = Details["TelNumber"].ToString();

            IndividualClient ind = new IndividualClient(name, surname, dateofbirth, status, phonenumber, email, faxnumber, telnumber, streetname, city, province, postalcode, country, buildingnumber);
            return ind;
        }

        //Get random Individual client's details
        public IndividualClient RandomIndividualClientDetails()
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.RandomIndividualClientDetails())
            {
                Details.Add(item.Key, item.Value);
            }

            string status = Details["Status"].ToString();
            string name = Details["Name"].ToString();
            string surname = Details["Surname"].ToString(); ;
            DateTime dateofbirth = Convert.ToDateTime(Details["DateOfBirth"]);
            string streetname = Details["StreetName"].ToString();
            string city = Details["City"].ToString();
            string province = Details["Province"].ToString();
            string postalcode = Details["PostalCode"].ToString();
            string country = Details["Country"].ToString();
            string buildingnumber = Details["BuildingNumber"].ToString();
            string phonenumber = Details["PhoneNumber"].ToString();
            string email = Details["Email"].ToString();
            string faxnumber = Details["FaxNumber"].ToString();
            string telnumber = Details["TelNumber"].ToString();

            IndividualClient ind = new IndividualClient(name, surname, dateofbirth, status, phonenumber, email, faxnumber, telnumber, streetname, city, province, postalcode, country, buildingnumber);
            return ind;
        }
    }
}
