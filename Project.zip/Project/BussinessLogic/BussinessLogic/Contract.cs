﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class Contract : Client
    {
        DataTable listofIndividualClients;
        Access dataacess = new Access();

        private string contractlevel;

        public string ContractLevel
        {
            get { return contractlevel; }
            set { contractlevel = value; }
        }

        private string package;

        public string Package
        {
            get { return package; }
            set { package = value; }
        }
        private DateTime startdate;

        public DateTime Startdate
        {
            get { return startdate; }
            set { startdate = value; }
        }
        private DateTime enddate;

        public DateTime Enddate
        {
            get { return enddate; }
            set { enddate = value; }
        }

        public Contract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string ClientFirstName, string ClientLastName)
            :base(ClientFirstName, ClientLastName)
        {
            this.contractlevel = ContractLevel;
            this.package = Package;
            this.startdate = StartDate;
            this.enddate = EndDate;
        }

        public Contract(string ContractLevel, string Package)
        {
            this.contractlevel = ContractLevel;
            this.package = Package;
        }

        public Contract()
        {
 
        }

        //********************************************************INDIVIDUAL CLIENT*****************************************************

        //Insert Contract
        public string InsertContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string ClientFirstName, string ClientLastName)
        {
            string success;
            try
            {
                dataacess.InsertContract(ContractLevel, Package, StartDate, EndDate, ClientFirstName, ClientLastName);
                success = "Contract added";
            }
            catch (Exception error)
            {

                success = "Failed to add Contract. Error:  " + error.ToString();
            }

            return success;
        }

        //Update Contract
        public string UpdateContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string ClientFirstName, string ClientLastName)
        {
            string success;
            try
            {
                dataacess.UpdateContract(ContractLevel, Package, StartDate, EndDate, ClientFirstName, ClientLastName);
                success = "Contract updated";
            }
            catch (Exception error)
            {

                success = "Failed to udate Contract. Error:  " + error.ToString();
            }

            return success;
        }

        //Delete Contract
        public string DeleteContract(string FirstName, string LastName)
        {
            string success;
            try
            {
                dataacess.DeleteContract(FirstName, LastName);
                success = "Contract deleted";
            }
            catch (Exception error)
            {

                success = "Failed to udate Contract. Error:  " + error.ToString();
            }

            return success;
        }

        //Get specific Individual client's contract details
        public Contract ReturnAllContratInfo(string FirstName, string LastName)
            {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.ContractDetails(FirstName, LastName))
            {
                Details.Add(item.Key, item.Value);
            }

            string ContractLevel = Details["ContractLevel"].ToString();
            string Package = Details["Package"].ToString();
            Contract cont = new Contract(ContractLevel, Package);
            return cont;
        }

        //********************************************************BUSINESS CLIENT*****************************************************
        //Insert Business Contract
        public string InsertBusinessContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string Company)
        {
            string success;
            try
            {
                dataacess.InsertbusinessContract(ContractLevel, Package, StartDate, EndDate, Company);
                success = "Contract added";
            }
            catch (Exception error)
            {

                success = "Failed to add Contract. Error:  " + error.ToString();
            }

            return success;
        }

        //Update Business Contract
        public string UpdateBusinessContract(string ContractLevel, string Package, DateTime StartDate, DateTime EndDate, string Company)
        {
            string success;
            try
            {
                dataacess.InsertbusinessContract(ContractLevel, Package, StartDate, EndDate, Company);
                success = "Contract updated";
            }
            catch (Exception error)
            {

                success = "Failed to udate Contract. Error:  " + error.ToString();
            }

            return success;
        }

        //Delete Business Contract
        public string DeleteBusinessContract(string Company)
        {
            string success;
            try
            {
                dataacess.DeletebusinessContract(Company);
                success = "Contract deleted";
            }
            catch (Exception error)
            {

                success = "Failed to udate Contract. Error:  " + error.ToString();
            }

            return success;
        }

        //Get specific Business client's contract details
        public Contract ReturnAllBusinessContratInfo(string Company)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.ContractBusinessDetails(Company))
            {
                Details.Add(item.Key, item.Value);
            }

            string ContractLevel = Details["ContractLevel"].ToString();
            string Package = Details["Package"].ToString();
            Contract cont = new Contract(ContractLevel, Package);
            return cont;
        }
    }
}
