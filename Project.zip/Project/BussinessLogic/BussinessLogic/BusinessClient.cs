﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class BusinessClient : Client
    {
        Access dataacess = new Access();
        DataTable listofBusinessClients;
        private string managername;

        public string Managername
        {
            get { return managername; }
            set { managername = value; }
        }
        private string managerphone;

        public string Managerphone
        {
            get { return managerphone; }
            set { managerphone = value; }
        }
        private string supervisorname;

        public string Supervisorname
        {
            get { return supervisorname; }
            set { supervisorname = value; }
        }
        private string supervisorphonenumber;

        public string Supervisorphonenumber
        {
            get { return supervisorphonenumber; }
            set { supervisorphonenumber = value; }
        }

        string companyname;

        public string Companyname
        {
            get { return companyname; }
            set { companyname = value; }
        }

        public BusinessClient()
        {
 
        }

        public BusinessClient(string CompanyName, string Status, string ManagerName, string SupervisorName, string ManagerPhone, string SupervisorPhone, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
            : base(Status, StreetName, City, Province, PostalCode, Country, BuidingNumber, PhoneNumber, Email, FaxNumber, TelNumber)
        {
            this.companyname = CompanyName;
            this.managername = ManagerName;
            this.managerphone = ManagerPhone;
            this.supervisorname = SupervisorName;
            this.supervisorphonenumber = SupervisorPhone;
        }

        //Insert business client
        public string InsertBusinessClient(string CompanyName, string Status, string ManagerName, string SupervisorName, string ManagerPhone, string SupervisorPhone, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            string success;
            try
            {
                dataacess.InsertBusinessClient(CompanyName, Status, ManagerName, ManagerPhone, SupervisorName, SupervisorPhone, PhoneNumber, Email, FaxNumber, TelNumber, StreetName, City, Province, PostalCode, Country, BuidingNumber);
                success = "Client added";
            }
            catch (Exception error)
            {

                success = "Failed to add client. Error:  " + error.ToString();
            }

            return success;
        }

        //Update business client
        public string UpdateBusinessClient(string CompanyName, string Status, string ManagerName, string SupervisorName, string ManagerPhone, string SupervisorPhone, string PhoneNumber, string Email, string FaxNumber, string TelNumber, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber)
        {
            string success;
            try
            {
                dataacess.UpdateBusinessClient(CompanyName, Status, ManagerName, SupervisorName, ManagerPhone, SupervisorPhone, PhoneNumber, Email, FaxNumber, TelNumber, StreetName, City, Province, PostalCode, Country, BuidingNumber);
                success = "Client updated";
            }
            catch (Exception error)
            {

                success = "Failed to update client. Error:  " + error.ToString();
            }

            return success;
        }

        //Delete Business client
        public string DeleteBusinessClient(string CompanyName)
        {
            string success;
            try
            {
                dataacess.DeleteUser(CompanyName);
                success = "Client deleted";
            }
            catch (Exception error)
            {

                success = "Failed to delete client. Error:  " + error.ToString();
            }

            return success;
        }

        //Check if Individual client already exist
        public string Existence(string Company)
        {
            string exists = "";

            //DataAccess getting user table from data access layer
            listofBusinessClients = dataacess.BusinessTable();


            //Loop through database
            foreach (DataRow row in listofBusinessClients.Rows)
            {
                //And search for Username and Pass that match
                if (row.ItemArray[2].Equals(Company))
                {
                    //If exists
                    exists = "true";
                    break;
                }
                else
                {
                    //If not does not exist
                    exists = "false";
                }
            }

            return exists;
        }


        //+++++++++++++++++++++++++ GET METHODS+++++++++++++++++++++++
        //Get list of clients
        public DataTable GetListOfBusinessclients()
        {
            DataTable ListOfClients = dataacess.BusinessTable();
            return ListOfClients;
        }

        //Get specific client's details
        public BusinessClient ReturnAllBusinessclientInfo(string CompanyName)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.IndividualBusinessClientDetails(CompanyName))
            {
                Details.Add(item.Key, item.Value);
            }

            string status = Details["Status"].ToString();
            string comname = Details["CompanyName"].ToString();
            string managernam = Details["ManagerName"].ToString();
            string managernum = Details["ManagerNumber"].ToString();
            string supervisornam = Details["SupervisorName"].ToString();
            string supervisornum = Details["SupervisorNumber"].ToString();
            DateTime dateofbirth = Convert.ToDateTime(Details["DateOfBirth"]);
            string streetname = Details["StreetName"].ToString();
            string city = Details["City"].ToString();
            string province = Details["Province"].ToString();
            string postalcode = Details["PostalCode"].ToString();
            string country = Details["Country"].ToString();
            string buildingnumber = Details["BuildingNumber"].ToString();
            string phonenumber = Details["PhoneNumber"].ToString();
            string email = Details["Email"].ToString();
            string faxnumber = Details["FaxNumber"].ToString();
            string telnumber = Details["TelNumber"].ToString();

            BusinessClient bus = new BusinessClient(comname, status, managernam, supervisornam, managernum, supervisornum, phonenumber, email, faxnumber, telnumber, streetname, city, province, postalcode, country, buildingnumber);

            return bus;
        }

        //Get random Individual client's details
        public BusinessClient RandomBusinessClientDetails()
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.RandomBusinessClientDetails())
            {
                Details.Add(item.Key, item.Value);
            }

            string status = Details["Status"].ToString();
            string comname = Details["CompanyName"].ToString();
            string managernam = Details["ManagerName"].ToString();
            string managernum = Details["ManagerNumber"].ToString();
            string supervisornam = Details["SupervisorName"].ToString();
            string supervisornum = Details["SupervisorNumber"].ToString();
            string streetname = Details["StreetName"].ToString();
            string city = Details["City"].ToString();
            string province = Details["Province"].ToString();
            string postalcode = Details["PostalCode"].ToString();
            string country = Details["Country"].ToString();
            string buildingnumber = Details["BuildingNumber"].ToString();
            string phonenumber = Details["PhoneNumber"].ToString();
            string email = Details["Email"].ToString();
            string faxnumber = Details["FaxNumber"].ToString();
            string telnumber = Details["TelNumber"].ToString();

            BusinessClient bus = new BusinessClient(comname, status, managernam, supervisornam, managernum, supervisornum, phonenumber, email, faxnumber, telnumber, streetname, city, province, postalcode, country, buildingnumber);

            return bus;
        }

    }
}
