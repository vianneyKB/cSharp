﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class Package
    {
        DataTable listofservice;
        Access dataacess = new Access();

        private string packagetname;

        public string Packagename
        {
            get { return packagetname; }
            set { packagetname = value; }
        }
        private string packagelevel;

        public string Packagelevel
        {
            get { return packagelevel; }
            set { packagelevel = value; }
        }
        private string service1;

        public string Service1
        {
            get { return service1; }
            set { service1 = value; }
        }
        private string service2;

        public string Service2
        {
            get { return service2; }
            set { service2 = value; }
        }
        private string service3;

        public string Service3
        {
            get { return service3; }
            set { service3 = value; }
        }
        private string service4;

        public string Service4
        {
            get { return service4; }
            set { service4 = value; }
        }

        public Package(string Packagename, string Packagelevel, string Service1, string Service2, string Service3, string Service4)
        {
            this.Packagename = Packagename;
            this.packagelevel = Packagelevel;
            this.service1 = Service1;
            this.service2 = Service2;
            this.service3 = Service3;
            this.service4 = Service4;
        }

        public Package()
        {

        }

        //Insert Package
        public string InsertPackage(string PackageName, string PackageLevel, string Service1, string Service2, string Service3, string Service4)
        {
            string success;
            try
            {
                dataacess.InsertPackage(PackageName, PackageLevel, Service1, Service2, Service3, Service4);
                success = "Package added";
            }
            catch (Exception error)
            {

                success = "Failed to add package. Error:  " + error.ToString();
            }

            return success;
        }

        //Check if package already exist
        public string Existence(string packagename)
        {
            string exists = "";

            //DataAccess getting user table from data access layer
            listofservice = dataacess.PackageTable();


            //Loop through database
            foreach (DataRow row in listofservice.Rows)
            {
                //And search for Username and Pass that match
                if (row.ItemArray[1].Equals(packagename))
                {
                    //If exists
                    exists = "true";
                    break;
                }
                else
                {
                    //If not does not exist
                    exists = "false";
                }
            }

            return exists;
        }

        //+++++++++++++++++++++++++     PACKAGE GET METHODS+++++++++++++++++++++++
        //Get list of packages
        public DataTable GetListOPackages()
        {
            DataTable ListOfServices = dataacess.PackageTable();
            return ListOfServices;
        }

        //Get specific package's details
        public Package ReturnAllPackageInfo(string packagename)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.PackageDetails(packagename))
            {
                Details.Add(item.Key, item.Value);
            }

            string PackageName = Details["PackageName"].ToString();
            string PackageLevel = Details["PackageLevel"].ToString();
            string Service1 = Details["Service1"].ToString();
            string Service2 = Details["Service2"].ToString();
            string Service3 = Details["Service3"].ToString();
            string Service4 = Details["Service4"].ToString();

            Package package = new Package(PackageName, PackageLevel, Service1, Service2, Service3, Service4);
            return package;
        }
    }
}
