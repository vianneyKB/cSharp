﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BussinessLogic
{
    class Technician : Person
    {
        private double Salary;
        private string availability;


        public void PerformService()
        {
 
        }
    }
}
