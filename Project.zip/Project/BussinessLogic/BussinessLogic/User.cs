﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class User : Person
    {
        public DataTable login;
        Access dataacess = new Access();
        public bool validated;
        public bool exists;


        private string username;

        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        private string department;

        public string Department
        {
            get { return department; }
            set { department = value; }
        }

        public User(string un, string pass, string dep, string n, string sn, DateTime d, string stn, string c, string p, string pc, string cou, string bn, string pn, string e, string faxn, string telnum)
            : base(n, sn, d, stn, c, p, pc, cou, bn, pn, e, faxn, telnum)
        {
            username = un;
            password = pass;
            department = dep;
        }

        public User(string un, string pass)
        {
            username = un;
            password = pass;
        }
        public User()
        {

        }

        //****************************************USER**************************************************

        //Add user
        public string AddUser(string username, string password, string Department, string name, string surname, DateTime DateOBirth, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber, string phoneNumber, string email, string faxNumber, string TelNumber)
        {
            string success;
            try
            {
                dataacess.InsertUser(username, password, Department, name, surname, DateOBirth, phoneNumber, email, faxNumber, TelNumber, StreetName, City, Province, PostalCode, Country, BuidingNumber);
                success = "User added";
            }
            catch (Exception error)
            {

                success = "Failed to add user. Error:  " + error.ToString();
            }

            return success;

        }

        //Delete user
        public string DeletUser(string username)
        {
            string success;
            try
            {
                dataacess.DeleteUser(username);
                success = "User deleted";
            }
            catch (Exception error)
            {

                success = "Failed to delete user. Error:  " + error.ToString();
            }

            return success;

        }

        //Update user
        public string UpdateUser(string username, string password, string Department, string name, string surname, DateTime DateOBirth, string StreetName, string City, string Province, string PostalCode, string Country, string BuidingNumber, string phoneNumber, string email, string faxNumber, string TelNumber)
        {
            string success;
            try
            {
                dataacess.UpdateUser(username, password, Department, name, surname, DateOBirth, StreetName, email, faxNumber, TelNumber, StreetName, City, Province, PostalCode, Country, BuidingNumber);
                success = "User updated";
            }
            catch (Exception error)
            {

                success = "Failed to update user user. Error:  " + error.ToString();
            }

            return success;

        }

        //Validate user for login
        public void Validation(string username, string password)
        {
            //DataAccess getting user table from data access layer
            login = dataacess.Usertable();

            //Loop through database
            foreach (DataRow row in login.Rows)
            {
                //And search for Username and Pass that match
                if (row.ItemArray[1].Equals(username) && row.ItemArray[2].Equals(password))
                {
                    //If approved
                    validated = true;
                }
                else
                {
                    //If not approved
                    validated = false;
                }

            }
        }

        //Check if user already exist
        public void Existence(string username)
        {
            //DataAccess getting user table from data access layer
            login = dataacess.Usertable();

            //Loop through database
            foreach (DataRow row in login.Rows)
            {
                //And search for Username and Pass that match
                if (row.ItemArray[1].Equals(username))
                {
                    //If user exists
                    exists = true;
                }
                else
                {
                    //If user does not exist
                    exists = false;
                }

            }
        }

        //****************************************GET METHODS**************************************************
        //Get list of users
        public DataTable GetListOfUsers()
        {
            DataTable ListOfUsers = dataacess.Usertable();
            return ListOfUsers;
        }

        //Get specific user's details
        public User ReturnAllUserInfo(string username)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.UserDetails(username))
            {
                Details.Add(item.Key, item.Value);
            }

            string usernam = Details["Username"];
            string password = Details["Password"].ToString();
            string department = Details["Department"].ToString();
            string name = Details["Name"].ToString();
            string surname = Details["Surname"].ToString(); ;
            DateTime dateofbirth = Convert.ToDateTime(Details["DateOfBirth"]);
            string streetname = Details["StreetName"].ToString();
            string city = Details["City"].ToString();
            string province = Details["Province"].ToString();
            string postalcode = Details["PostalCode"].ToString();
            string country = Details["Country"].ToString();
            string buildingnumber = Details["BuildingNumber"].ToString();
            string phonenumber = Details["PhoneNumber"].ToString();
            string email = Details["Email"].ToString();
            string faxnumber = Details["FaxNumber"].ToString();
            string telnumber = Details["TelNumber"].ToString();

            User userd = new User(usernam, password, department, name, surname, dateofbirth, streetname, city, province, postalcode, country, buildingnumber, phonenumber, email, faxnumber, telnumber);
            return userd;
        }

    }
}
