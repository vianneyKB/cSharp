﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using DataAcess;

namespace BussinessLogic
{
    public class ServicesProvided
    {
        DataTable listofservice;
        Access dataacess = new Access();
        
        private string ServiceName;

        public string servicename
        {
            get { return ServiceName; }
            set { ServiceName = value; }
        }

        private string serviceDescription;

        public string ServiceDescription
        {
            get { return serviceDescription; }
            set { serviceDescription = value; }
        }
        private string duration;

        public string Duration
        {
            get { return duration; }
            set { duration = value; }
        }
        private string priority;

        public string Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public ServicesProvided()
        {
        }

        public ServicesProvided(string ServiceName, string ServiceDescription, string Duration, string Priority)
        {
            this.servicename = ServiceName;
            this.serviceDescription = ServiceDescription;
            this.duration = Duration;
            this.priority = Priority;
        }

        //Insert service
        public string AddService(string ServiceName, string ServiceDescriptionn, string Duration, string Priority)
        {
            string success;
            try
            {
                dataacess.InsertService(ServiceName, ServiceDescriptionn, Duration, Priority);
                success = "Service added";
            }
            catch (Exception error)
            {

                success = "Failed to add service. Error:  " + error.ToString();
            }

            return success;

        }

        //Update service
        public string UpdateService(string ServiceName, string ServiceDescriptionn, string Duration, string Priority)
        {
            string success;
            try
            {
                dataacess.UpdateService(ServiceName, ServiceDescriptionn, Duration, Priority);
                success = "Service Updated";
            }
            catch (Exception error)
            {

                success = "Failed to update user service. Error:  " + error.ToString();
            }

            return success;

        }

        //Delete service
        public string DeletService(string ServiceName)
        {
            string success;
            try
            {
                dataacess.DeleteService(ServiceName);
                success = "Service deleted";
            }
            catch (Exception error)
            {

                success = "Failed to delete service. Error:  " + error.ToString();
            }

            return success;

        }

        //Check if service already exist
        public string Existence(string ServiceName)
        {
            string exists = "";

            //DataAccess getting user table from data access layer
            listofservice = dataacess.ServiceTable();


            //Loop through database
            foreach (DataRow row in listofservice.Rows)
            {
                //And search for Username and Pass that match
                if (row.ItemArray[1].Equals(ServiceName))
                {
                    //If exists
                    exists = "true";
                    break;
                }
                else
                {
                    //If not does not exist
                    exists = "false";
                }
            }

            return exists;
        }

        //+++++++++++++++++++++++++ SERVICES GET METHODS+++++++++++++++++++++++
        //Get list of service
        public DataTable GetListOfServices()
        {
            DataTable ListOfServices = dataacess.ServiceTable();
            return ListOfServices;
        }

        //Get specific service's details
        public ServicesProvided ReturnAllServiceInfo(string servicename)
        {
            Dictionary<string, string> Details = new Dictionary<string, string>();
            foreach (KeyValuePair<string, string> item in dataacess.ServiceDetails(servicename))
            {
                Details.Add(item.Key, item.Value);
            }

            string ServiceName = Details["ServiceName"].ToString();
            string ServiceDescription = Details["ServiceDescription"].ToString();
            string Duration = Details["Duration"].ToString();
            string Priority = Details["Priority"].ToString();

            ServicesProvided serv = new ServicesProvided(ServiceName, ServiceDescription, Duration, Priority);
            return serv;
        }
    }
}
